# 🛡️ LuaShield PHP — обфускатор Lua 5.1 / LuaJIT с веб-админкой

Полностью самодостаточная PHP-версия: **движок на чистом PHP** (никакого Python/node на сервере не нужно), админка в **чёрных тонах**, база **MySQL/MariaDB**, готовый аккаунт админа.

Целевая среда скриптов: **Lua 5.1 / LuaJIT** (а также 5.2–5.4 и Roblox/Luau).
Wrap-проход использует `loadstring`, который в Lua 5.1/LuaJIT есть из коробки — можно включать смело.

---

## 🚀 Быстрый старт

### Вариант A. Shared-хостинг (phpMyAdmin — Beget, Timeweb, reg.ru…)

1. **В панели хостинга** создайте базу данных (имя вида `l43087cr_luashield`)
   — базы на shared-хостинге создаются только в панели, не через SQL!
2. Откройте **phpMyAdmin** → выберите эту базу слева → вкладка **«Импорт»**
   → загрузите **`database.sql`** (он БЕЗ `CREATE DATABASE`).
3. Залейте файлы на сайт, укажите доступы в `config.php`.
4. Done: аккаунт `admin` / `LuaShield@2026`.

### Вариант B. VPS / свой MySQL

```bash
mysql -u root -p < install.sql     # полный файл: сам создаст базу luashield
```

| Логин | Пароль |
|---|---|
| `admin` | `LuaShield@2026` |

> ⚠️ **Сразу после первого входа смените пароль** в разделе «Профиль»!
> Рекомендуется также создать отдельного MySQL-пользователя (готовый код
> в конце `install.sql`, закомментирован).

### 3. Пропишите доступ к БД в `config.php`

```php
define('LS_DB_HOST', '127.0.0.1');
define('LS_DB_NAME', 'luashield');
define('LS_DB_USER', 'luashield');        // или root
define('LS_DB_PASS', 'ваш_пароль');
```

### 4. Права на папку результатов

```bash
chmod -R 750 storage
chown -R www-data:www-data storage    # пользователь вашего PHP
```

### 5. Запуск

**Apache:** просто укажите DocumentRoot на папку `/var/www/luashield`
(прилагаемые `.htaccess` уже закрывают доступ к `config.php`, движку,
`install.sql`, `inc/` и `storage/` напрямую).

**Nginx + php-fpm:**

```nginx
server {
    listen 80;
    server_name obf.example.com;
    root /var/www/luashield;
    index login.php;

    client_max_body_size 8m;

    location / {
        try_files $uri $uri/ =404;
    }
    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
    # закрыть служебные пути
    location ~* ^/(config\.php|obfuscator\.php|inc/|storage/)|\.sql$ {
        deny all;
    }
}
```

> 📌 Настоятельно рекомендуется HTTPS (certbot): пароль и скрипты не должны
> идти по сети открытым текстом.

**Быстрый локальный запуск (для теста):**

```bash
php -S 127.0.0.1:8080
# открыть http://127.0.0.1:8080/login.php
```

---

## ⚙️ Что умеет движок

| Проход | Описание |
|---|---|
| 🔐 Шифрование строк | Все строки → зашифрованный blob + рантайм-декриптор. Аддитивный шифр (без `bit`-библиотек) — работает на чистом **Lua 5.1/LuaJIT** |
| 🔀 Переименование локалов | Настоящий парсер (рекурсивный спуск): области видимости, shadowing, upvalues, `repeat...until`, методы и `self`, ключи таблиц |
| 🔢 Обфускация чисел | `42` → `(0x9A3F41C-0x9A3F3FA)` |
| 🗑️ Мусорный код | 0–10 случайных мёртвых блоков |
| ✂️ Минификация | Удаление комментариев и пробелов (лексически безопасно) |
| 📦 Wrap | Весь чанк → зашифрованный `loadstring/load`-загрузчик |
| 🔁 Многослойность | Вывод можно обфусцировать повторно |

Каждый запуск — новые имена переменных и новые ключи шифрования.

## 🖥️ Админка (чёрная тема)

- Вход с защитой от перебора: **5 попыток → бан на 60 секунд** (таблица `login_guard`)
- CSRF-токены на всех POST-запросах, HTTPOnly + SameSite куки
- Полупрозрачный glass-интерфейс (красно-чёрная тема, blur), drag&drop загрузка `.lua` с ПК, профили Lua 5.1 / Lua 5.2–5.4 / Roblox
- Статистика: размеры, коэффициент, строк/чисел/локалов, время
- Просмотр результата, копирование, скачивание `.obf.lua`
- История обфускаций (MySQL), удаление записей
- Смена пароля в «Профиле»

## 🖧 CLI (без браузера)

```bash
php obfuscator.php script.lua -o script.obf.lua          # все проходы без wrap
php obfuscator.php script.lua --wrap                     # + полная упаковка (5.1/JIT ✓)
php obfuscator.php script.lua --no-rename --junk 8
php obfuscator.php script.lua --seed 42                  # детерминированный вывод
```

## 📁 Структура

```
luashield-php/
├── database.sql        # ⭐ дамп для phpMyAdmin (импорт в выбранную базу, 1 клик)
├── install.sql         # полная установка с CREATE DATABASE (для VPS/своего MySQL)
├── config.php          # настройки (БД, лимиты)
├── obfuscator.php      # ДВИЖОК обфускации (PHP-библиотека + CLI)
├── inc/                # db.php · auth.php · ui.php (закрыты .htaccess)
├── login.php  logout.php  profile.php
├── index.php           # админ-панель
├── obfuscate.php       # API обфускации (POST)
├── jobs.php            # API истории (GET)
├── delete_job.php      # API удаления (POST)
├── download.php        # выдача результата
├── sample.php          # демо-скрипт
├── assets/             # style.css (чёрная тема), app.js
├── storage/out/        # результаты (закрыто от веба; выдача только через download.php)
├── example.lua
└── test_engine_php.py / test_web_php.py   # dev-тесты (на сервер не нужны)
```

## ✅ Проверено

- **30 тестов движка**: оригинал и обфусцированный код исполняются реальным Lua-рантаймом — вывод идентичен (кложуры, метатаблицы, goto, varargs, методы, sugar…)
- **13 E2E-проверок админки**: вход, CSRF, загрузка→скачивание→исполнение, история, удаление, смена пароля
- Антибрутфорс: 5 неудачных входов → блокировка IP на 60 сек

## ⚠️ Ограничения и заметки по средам

- **🎮 gamesense (CS:GO):** выбирайте профиль «gamesense» — движок специально адаптирован:
  - дешифратор строк и мусорный код обёрнуты в `do...end` и **не расходуют top-level локалы** (лимит Lua(LuaJIT) — 200/область; в старых сборках большие gs-скрипты падали с «too many local variables»)
  - данные кодируются в **hex (рост x2 вместо x4)** — меньше риск упёреться в лимит размера скрипта; в админке есть предупреждение при выходе > ~520 КБ
  - профиль автоматически выключает мусор и wrap; wrap при желании можно включить — `loadstring` в gs работает
- **Roblox:** не включайте *wrap* (нет `loadstring`); остальные проходы работают
- **Luau:** обычные type-аннотации (`local x: number?`) — ок; интерполяция `` `...{x}...` `` — не поддерживается (замените на `..`)
- Скрипты, читающие имена локалов через `debug.getlocal`, — используйте без прохода переименования
