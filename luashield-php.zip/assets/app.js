/* LuaShield admin panel (PHP) */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const CSRF = document.querySelector('meta[name="csrf"]').content;
  const IS_ADMIN = (document.querySelector('meta[name="is-admin"]') || {}).content === "1";
  const GUEST_LIMIT = Number((document.querySelector('meta[name="guest-limit"]') || {}).content || 20);
  const dropZone = $("drop-zone");
  const fileInput = $("file-input");
  const fileName = $("file-name");
  const form = $("obf-form");
  const submitBtn = $("submit-btn");
  const progress = $("progress");
  const formError = $("form-error");
  const junk = $("junk");
  const junkOut = $("junk-out");
  const target = $("target");
  const optWrap = $("opt-wrap");
  let lastOutput = null;

  // слайдер «мусорный код»: волна на ползунке + прокрутка цифры + подсветка меток
  const junkTicks = document.querySelectorAll(".slider-scale i");
  function setJunk(v) {
    junk.value = v;
    junkOut.textContent = v;
    junk.style.setProperty("--p", (Number(v) / 10) * 100 + "%");
    junkOut.classList.remove("roll");
    void junkOut.offsetWidth;          // рестарт CSS-анимации
    junkOut.classList.add("roll");
    junk.classList.remove("burst");
    void junk.offsetWidth;
    junk.classList.add("burst");
    junkTicks.forEach((el) => el.classList.toggle("on", Number(v) >= Number(el.textContent)));
  }
  junk.addEventListener("input", () => setJunk(junk.value));
  setJunk(junk.value);

  // кастомный select «Целевая среда»: синхронизирован со скрытым нативным #target
  (function () {
    const cs = $("target-cs");
    if (!cs) return;
    const btn = cs.querySelector(".cselect-btn");
    const label = cs.querySelector(".cs-label");
    const close = () => { cs.classList.remove("open"); btn.setAttribute("aria-expanded", "false"); };
    btn.addEventListener("click", () => {
      const open = cs.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
    cs.querySelectorAll(".cs-item").forEach((item) => {
      item.addEventListener("click", () => {
        cs.querySelectorAll(".cs-item").forEach((i) => i.classList.remove("on"));
        item.classList.add("on");
        label.textContent = item.dataset.label;
        target.value = item.dataset.value;
        close();
        target.dispatchEvent(new Event("change"));   // шлём старую логику профилей
      });
    });
    document.addEventListener("click", (e) => { if (!cs.contains(e.target)) close(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  })();

  const GS_LIMIT = 520 * 1024; // ориентировочный лимит размера скрипта gamesense

  // ---------- подсветка синтаксиса (палитра Visual Studio Code · Dark+) ----------
  const tkSpan = (cls, tok) => '<span class="' + cls + '">' + escHtml(tok) + "</span>";

  const LUA_KW = new Set(("and break do else elseif end false for function goto if in local " +
    "nil not or repeat return then true until while").split(" "));
  const LUA_FN = new Set(("assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile " +
    "loadstring module next pairs pcall print rawequal rawget rawset require select setfenv " +
    "setmetatable tonumber tostring type unpack xpcall " +
    "cdef").split(" "));   // cdef — FFI LuaJIT, подсветка как функция (как в VS Code)
  const LUA_LIBS = new Set(("coroutine debug io math os package string table bit ffi jit " +
    "client entity ui renderer database globals panorama plist materialsys cvar vector").split(" "));
  const LUA_RE = /(--\[\[[\s\S]*?\]\])|(--[^\n]*)|(\[\[[\s\S]*?\]\])|("(?:\\[\s\S]|[^"\\])*")|('(?:\\[\s\S]|[^'\\])*')|(\b0x[\da-fA-F]+\b|\b\d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?\d+)?\b|\.\d+(?:[eE][+-]?\d+)?\b)|([A-Za-z_]\w*)/g;

  function escHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // строка как в VS Code: сама оранжевая, а \n \x41 \65 → золотые (#D7BA7D)
  const ESC_RE = /(\\u\{[^}]+\})|(\\x[0-9a-fA-F]{2})|(\\\d{1,3})|(\\[\s\S])/g;
  function emitStr(tok) {
    let inner = "", last = 0, m;
    ESC_RE.lastIndex = 0;
    while ((m = ESC_RE.exec(tok)) !== null) {
      inner += escHtml(tok.slice(last, m.index)) + tkSpan("tk-esc", m[0]);
      last = m.index + m[0].length;
    }
    inner += escHtml(tok.slice(last));
    return '<span class="tk-str">' + inner + "</span>";
  }

  function highlightLua(code) {
    let out = "", last = 0, m;
    LUA_RE.lastIndex = 0;
    while ((m = LUA_RE.exec(code)) !== null) {
      out += escHtml(code.slice(last, m.index));
      const tok = m[0];
      if (m[1] || m[2]) out += tkSpan("tk-com", tok);
      else if (m[3]) out += tkSpan("tk-str", tok);            // [[long]] — без escape
      else if (m[4] || m[5]) out += emitStr(tok);             // "..." '...' — с escape
      else if (m[6]) out += tkSpan("tk-num", tok);
      else if (m[7]) {
        let cls = LUA_KW.has(tok) ? "tk-kw"
          : (LUA_LIBS.has(tok) ? "tk-lib" : (LUA_FN.has(tok) ? "tk-bl" : null));
        // вызов функции/метода перед ( — жёлтый, как в VS Code
        if (cls === null && /^\s*\(/.test(code.slice(m.index + tok.length, m.index + tok.length + 24)))
          cls = "tk-bl";
        out += cls ? tkSpan(cls, tok) : escHtml(tok);
      }
      last = m.index + tok.length;
    }
    out += escHtml(code.slice(last));
    return out;
  }

  // ---------- C : ключевые слова и токенизатор ----------
  const C_KW = new Set(("auto break case char const continue default do double else enum extern float " +
    "for goto if inline int long register restrict return short signed sizeof static struct switch " +
    "typedef union unsigned void volatile while " +
    "_Alignas _Alignof _Atomic _Bool _Complex _Generic _Imaginary _Noreturn _Static_assert _Thread_local " +
    "alignas alignof bool constexpr false nullptr static_assert thread_local true typeof typeof_unqual").split(" "));
  const C_FN = new Set(("printf fprintf sprintf snprintf vprintf scanf sscanf fscanf fopen fclose freopen " +
    "fread fwrite fseek ftell rewind fflush fgets fputs fgetc fputc getchar putchar puts ungetc perror " +
    "remove rename malloc calloc realloc free memcpy memmove memset memcmp strlen strcpy strncpy strcat " +
    "strncat strcmp strncmp strcasecmp strchr strrchr strstr strdup strtol strtoul strtod atoi atol atof " +
    "exit abort atexit qsort bsearch abs labs time clock difftime signal raise assert rand srand " +
    "isalpha isdigit isalnum isspace isupper islower tolower toupper").split(" "));
  const C_TYPES = new Set(("size_t ssize_t ptrdiff_t uintptr_t intptr_t intmax_t uintmax_t " +
    "int8_t int16_t int32_t int64_t uint8_t uint16_t uint32_t uint64_t time_t clock_t va_list wchar_t FILE").split(" "));
  const C_CONST = new Set(("NULL EOF errno stdin stdout stderr").split(" "));
  const C_RE = /(\/\/[^\n]*)|(\/\*[\s\S]*?\*\/)|(^\s*#[^\n]*)|("(?:\\[\s\S]|[^"\\])*")|('(?:\\[\s\S]|[^'\\])*')|(\b0[xX][\da-fA-F']+[uUlL]*\b|\b\d[\d']*(?:\.\d[\d']*)?(?:[eE][+-]?\d+)?[fFlLuU]*\b|\.\d+(?:[eE][+-]?\d+)?[fFlL]*\b)|([A-Za-z_]\w*)/gm;

  function highlightC(code) {
    let out = "", last = 0, m;
    C_RE.lastIndex = 0;
    while ((m = C_RE.exec(code)) !== null) {
      out += escHtml(code.slice(last, m.index));
      const tok = m[0];
      if (m[1] || m[2]) out += tkSpan("tk-com", tok);
      else if (m[3]) {
        // препроцессор как в VS Code: #директива фиолетовая, путь <...> / "..." — строка
        const dm = tok.match(/^(\s*)(#\w*)([\s\S]*)$/);
        out += escHtml(dm[1]) + tkSpan("tk-pre", dm[2]);
        for (const p of dm[3].split(/(<[^>\n]*>|"[^"\n]*")/)) {
          if (p === "") continue;
          out += (p[0] === "<" || p[0] === '"') ? tkSpan("tk-str", p) : escHtml(p);
        }
      }
      else if (m[4] || m[5]) out += emitStr(tok);             // "..." 'x' — с escape
      else if (m[6]) out += tkSpan("tk-num", tok);
      else if (m[7]) {
        let cls = C_KW.has(tok) ? "tk-kw"
          : (C_CONST.has(tok) ? "tk-const"
          : (C_TYPES.has(tok) ? "tk-lib" : (C_FN.has(tok) ? "tk-bl" : null)));
        // вызов/объявление функции перед ( — жёлтый, как в VS Code
        if (cls === null && /^\s*\(/.test(code.slice(m.index + tok.length, m.index + tok.length + 24)))
          cls = "tk-bl";
        out += cls ? tkSpan(cls, tok) : escHtml(tok);
      }
      last = m.index + tok.length;
    }
    out += escHtml(code.slice(last));
    return out;
  }

  // определение языка: по расширению файла, иначе по признакам C в тексте
  function detectLang(name, code) {
    if (/\.(c|h)$/i.test(name || "")) return "c";
    if (/\.(lua|luau)$/i.test(name || "")) return "lua";
    const head = code.slice(0, 4000);
    if (/^\s*#\s*(include|define|pragma|ifndef|ifdef)\b/m.test(head) ||
        /\bint\s+main\s*\(/.test(head)) return "c";
    return "lua";
  }

  // рендер кода в просмотр: подсветка до 600 КБ, дальше — просто текст (не душим DOM)
  function renderCode(cv, text, lang) {
    if (text.length > 600000) { cv.textContent = text; return; }
    cv.innerHTML = (lang === "c" ? highlightC : highlightLua)(text);
  }

  // устойчивый JSON: показывает реальную ошибку сервера вместо "Unexpected end of JSON"
  async function fetchJSON(url, opts) {
    const r = await fetch(url, opts);
    const text = await r.text();
    let j;
    try {
      j = JSON.parse(text);
    } catch (e) {
      const hint = text.trim() === ""
        ? "Пустой ответ сервера — вероятно фатальная ошибка PHP (проверьте diag.php и логи хостинга)"
        : text.slice(0, 250);
      throw new Error("Сервер вернул не-JSON (HTTP " + r.status + "): " + hint);
    }
    return j;
  }

  function showHint(text, isOk) {
    formError.classList.remove("hidden");
    formError.textContent = text;
    formError.classList.toggle("ok", !!isOk);
    if (isOk) setTimeout(() => { formError.classList.add("hidden"); formError.classList.remove("ok"); }, 3000);
  }

  target.addEventListener("change", () => {
    if (target.value === "gamesense") {
      setJunk(0);
      optWrap.checked = false;
      showHint("🎮 Профиль gamesense: мусорный код выключен, wrap выключен. Ограничение Lua на 200 локалов уже учтено движком (все служебные локалы — в do-блоках).", true);
    } else if (target.value === "roblox" && optWrap.checked) {
      showHint("⚠ На Roblox loadstring выключен — wrap не сработает. На Lua 5.1/LuaJIT/gamesense wrap работает.");
    } else if ((target.value === "lua51" || target.value === "lua") && optWrap.checked) {
      showHint("✓ Wrap будет использовать loadstring/load — всё ок.", true);
    } else {
      formError.classList.add("hidden");
    }
  });

  // ---------- drag & drop ----------
  ["dragover", "dragenter"].forEach((ev) =>
    dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropZone.classList.add("drag");
    })
  );
  ["dragleave", "drop"].forEach((ev) =>
    dropZone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropZone.classList.remove("drag");
    })
  );
  dropZone.addEventListener("drop", (e) => {
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      showFile();
    }
  });
  fileInput.addEventListener("change", showFile);
  function showFile() {
    const f = fileInput.files[0];
    fileName.textContent = f ? "📦 " + f.name + " (" + fmtSize(f.size) + ")" : "";
    if (f) previewOriginal(f);
  }

  // сразу после выбора файла показываем его ИСХОДНЫЙ код (листается скроллом)
  async function previewOriginal(f) {
    let text;
    try {
      text = await f.text();
    } catch (e) {
      return;
    }
    $("result-empty").classList.add("hidden");
    $("result-body").classList.remove("hidden");
    $("stats").classList.add("hidden");
    $("dl-btn").classList.add("hidden");
    const lang = detectLang(f.name, text);
    $("code-caption").textContent = "📄 Исходный код · " +
      (lang === "c" ? "C" : "Lua") + " — ещё не обфусцирован";
    lastOutput = text;
    renderCode($("code-view"), text, lang);
  }

  // ---------- submit ----------
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    formError.classList.add("hidden");
    if (!fileInput.files || !fileInput.files.length) {
      showHint("⚠ Сначала выберите или перетащите .lua файл");
      return;
    }
    submitBtn.disabled = true;
    progress.classList.remove("hidden");

    const fd = new FormData(form);
    fd.set("junk", junk.value);

    try {
      const j = await fetchJSON("obfuscate.php", {
        method: "POST",
        headers: { "X-CSRF-Token": CSRF },
        body: fd,
      });
      if (!j.ok) {
        if (j.limit) onLimitHit(j);
        throw new Error(j.error || "Ошибка сервера");
      }
      showResult(j);
      if (j.guest_remaining !== undefined) updateGuestLeft(j.guest_remaining);
      if (IS_ADMIN) loadJobs();
    } catch (err) {
      formError.textContent = err.message;
      formError.classList.remove("hidden");
    } finally {
      submitBtn.disabled = false;
      progress.classList.add("hidden");
    }
  });

  function updateGuestLeft(n) {
    const el = $("guest-left");
    if (el) el.textContent = n;
    const bar = $("limit-bar");
    if (bar) bar.style.width = Math.round(100 * n / GUEST_LIMIT) + "%";
  }

  function onLimitHit() {
    updateGuestLeft(0);
    submitBtn.disabled = true;
    submitBtn.textContent = "⛔ Лимит гостя исчерпан (сброс в 00:00 МСК)";
  }

  function showResult(j) {
    $("result-empty").classList.add("hidden");
    $("result-body").classList.remove("hidden");
    $("stats").classList.remove("hidden");
    $("dl-btn").classList.remove("hidden");
    $("code-caption").textContent = "🔒 Обфусцированный код";
    const s = j.stats;
    const ratio = s.size_in ? s.size_out / s.size_in : 0;
    $("stats").innerHTML = [
      ["Исходный", fmtSize(s.size_in), ""],
      ["Обфусцирован", fmtSize(s.size_out), "good"],
      ["Коэффициент", "×" + ratio.toFixed(2), ""],
      ["Строк зашифр.", s.strings_encrypted, "good"],
      ["Чисел замен.", s.numbers_obfuscated, ""],
      ["Локалов переимен.", s.locals_renamed, "good"],
      ["Коммент. удалено", s.comments_removed, ""],
      ["Время", s.time_ms + " мс", ""],
    ]
      .map(([k, v, c]) => `<div class="stat ${c}"><b>${v}</b>${k}</div>`)
      .join("");
    $("dl-btn").href = j.download;
    fillCode(j.output, j.download);
    if (target.value === "gamesense" && s.size_out > GS_LIMIT) {
      showHint("⚠ Результат " + fmtSize(s.size_out) + " может превышать лимит размера скрипта gamesense. Совет: отключите «числа» и «мусор», не включайте wrap.");
    }
  }

  // код показываем всегда и целиком (скролл в .code-view);
  // если сервер не прислал output (очень большой файл) — подгружаем через view=1
  async function fillCode(output, downloadUrl) {
    const cv = $("code-view");
    if (output !== null && output !== undefined) {
      lastOutput = output;
      renderCode(cv, output, "lua");
      return;
    }
    lastOutput = null;
    cv.textContent = "⏳ Загружаю код…";
    try {
      const r = await fetch(downloadUrl + "&view=1");
      if (!r.ok) throw new Error("HTTP " + r.status);
      const t = await r.text();
      lastOutput = t;
      renderCode(cv, t, "lua");
    } catch (e) {
      cv.textContent = "⚠ Не удалось загрузить код для просмотра — файл доступен по кнопке «Скачать». Ошибка: " + e.message;
    }
  }

  // копирование: clipboard API только на HTTPS/localhost,
  // на обычном HTTP-хостинге — fallback через скрытый textarea + execCommand
  async function copyText(t) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(t);
        return;
      } catch (e) { /* уйдём в fallback */ }
    }
    const ta = document.createElement("textarea");
    ta.value = t;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;top:0;left:0;width:2px;height:2px;opacity:0;";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, ta.value.length);
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    if (!ok) throw new Error("браузер запретил копирование");
  }

  $("copy-btn").addEventListener("click", async () => {
    const btn = $("copy-btn");
    if (lastOutput === null || lastOutput === undefined || lastOutput === "") {
      btn.textContent = "⚠ Нечего копировать";
      setTimeout(() => (btn.textContent = "📋 Копировать"), 1500);
      return;
    }
    try {
      await copyText(lastOutput);
      btn.textContent = "✅ Скопировано";
    } catch (e) {
      btn.textContent = "⚠ Не удалось";
    }
    setTimeout(() => (btn.textContent = "📋 Копировать"), 1500);
  });

  // ---------- history ----------
  async function loadJobs() {
    const tb = document.querySelector("#jobs-table tbody");
    let j;
    try {
      j = await fetchJSON("jobs.php");
    } catch (e) {
      tb.innerHTML = '<tr><td colspan="9" class="err">⚠ ' + esc(e.message) + "</td></tr>";
      return;
    }
    if (!j.jobs || !j.jobs.length) {
      tb.innerHTML = '<tr><td colspan="9" class="muted center">Пока нет обфускаций</td></tr>';
      return;
    }
    tb.innerHTML = "";
    for (const job of j.jobs) {
      const tr = document.createElement("tr");
      const d = new Date(Number(job.ts) * 1000);
      if (job.status === "error") {
        tr.innerHTML = `<td>${d.toLocaleString("ru-RU")}</td>
          <td>${esc(job.filename)}</td>
          <td colspan="6" class="err">⚠ ${esc(job.error || "ошибка")}</td>
          <td><button class="link" data-del="${job.id}">×</button></td>`;
      } else {
        const ratio = Number(job.size_in) ? (Number(job.size_out) / Number(job.size_in)).toFixed(2) : "—";
        tr.innerHTML = `<td>${d.toLocaleString("ru-RU")}</td>
          <td><a class="link" href="download.php?id=${job.id}">${esc(job.filename)}</a></td>
          <td>${fmtSize(job.size_in)} → ${fmtSize(job.size_out)}</td>
          <td>${ratio}</td><td>${job.strings}</td><td>${job.numbers}</td>
          <td>${job.locals}</td><td>${job.ms}</td>
          <td><button class="link" data-del="${job.id}">×</button></td>`;
      }
      tb.appendChild(tr);
    }
    tb.querySelectorAll("[data-del]").forEach((b) =>
      b.addEventListener("click", async () => {
        const fd = new FormData();
        fd.set("id", b.dataset.del);
        try {
          await fetchJSON("delete_job.php", {
            method: "POST",
            headers: { "X-CSRF-Token": CSRF },
            body: fd,
          });
        } catch (e) { /* запись уже могла удалиться */ }
        loadJobs();
      })
    );
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"]/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])
    );
  }

  function fmtSize(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + " Б";
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " КБ";
    return (n / 1024 / 1024).toFixed(2) + " МБ";
  }

  if (IS_ADMIN) {
    loadJobs();
  } else if (Number((document.querySelector('meta[name="guest-remaining"]') || {}).content) === 0) {
    onLimitHit();
  }
})();
