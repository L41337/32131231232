<?php
/**
 * LuaShield — конфигурация. Отредактируйте под свой сервер.
 * Любое значение можно переопределить переменными окружения LS_*.
 */
declare(strict_types=1);

// ---- Проверка версии PHP: понятная ошибка вместо "Unexpected end of JSON" ----
if (version_compare(PHP_VERSION, '7.4', '<')) {
    http_response_code(500);
    $m = 'LuaShield требует PHP 7.4 или новее (у вас PHP ' . PHP_VERSION
       . '). Смените версию PHP в панели хостинга (раздел «Сайты» / «Версия PHP»).';
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $m . "\n");
    } else {
        echo $m;
    }
    exit(1);
}

// ---- Полифиллы PHP 8 -> для PHP 7.4 (совместимость с хостингами) ----
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool {
        return $needle === '' || substr_compare($haystack, $needle, -strlen($needle)) === 0;
    }
}

// ---- База данных MySQL ----
// На shared-хостинге имя БД и пользователя обычно с префиксом аккаунта,
// например: LS_DB_NAME 'l43087cr_luashield', LS_DB_USER 'l43087cr_1337'.
// База создаётся в ПАНЕЛИ хостинга, таблицы — импортом install_hosting.sql
// через phpMyAdmin в эту базу.
define('LS_DB_HOST', getenv('LS_DB_HOST') ?: 'localhost');
define('LS_DB_PORT', getenv('LS_DB_PORT') ?: '3306');
define('LS_DB_NAME', getenv('LS_DB_NAME') ?: 'luashield');
define('LS_DB_USER', getenv('LS_DB_USER') ?: 'root');
define('LS_DB_PASS', getenv('LS_DB_PASS') ?: '');

// ---- Приложение ----
define('LS_VERSION', '1.4.9');
define('LS_MAX_MB', (int)(getenv('LS_MAX_MB') ?: 4));   // макс. размер .lua
define('LS_GUEST_LIMIT', (int)(getenv('LS_GUEST_LIMIT') ?: 20)); // обфускаций/день для гостей
define('LS_STORAGE', __DIR__ . '/storage');             // папка результатов
define('LS_SESSION_NAME', 'LUSESSID');

date_default_timezone_set(getenv('LS_TZ') ?: 'Europe/Moscow');
