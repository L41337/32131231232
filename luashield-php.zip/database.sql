-- =============================================================
--  phpMyAdmin SQL Dump — LuaShield
--  Версия: 1.1.0 · Дата: 2026-07-21
--
--  ⚡ ЛЁГКИЙ ИМПОРТ (shared-хостинг: Beget, Timeweb, reg.ru …):
--    1) В панели хостинга создайте базу данных (имя вида l43087cr_...)
--    2) phpMyAdmin → выберите эту базу СЛЕВА → вкладка «Импорт»
--    3) Выберите файл database.sql → кнопка «Вперёд» → ГОТОВО
--
--  ⚡ VPS / локальный сервер: можно раскомментировать 2 строки ниже —
--     база создастся сама:
--
--  CREATE DATABASE IF NOT EXISTS `luashield` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
--  USE `luashield`;
--
--  Готовый аккаунт админа:   логин `admin` / пароль `LuaShield@2026`
--  (смените пароль в «Профиле» после первого входа!)
-- =============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET FOREIGN_KEY_CHECKS = 0;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- -------------------------------------------------------------

--
-- Структура таблицы `users` — аккаунты админ-панели
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(64)  NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------

--
-- Структура таблицы `jobs` — история обфускаций
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id`         CHAR(16)      NOT NULL,
  `user_id`    INT UNSIGNED  NULL,
  `filename`   VARCHAR(190)  NOT NULL DEFAULT 'paste.lua',
  `options`    TEXT          NULL,
  `size_in`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `size_out`   INT UNSIGNED  NOT NULL DEFAULT 0,
  `strings`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `numbers`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `locals`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `comments`   INT UNSIGNED  NOT NULL DEFAULT 0,
  `ms`         INT UNSIGNED  NOT NULL DEFAULT 0,
  `status`     ENUM('ok','error') NOT NULL DEFAULT 'ok',
  `error`      TEXT          NULL,
  `created_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------

--
-- Структура таблицы `login_guard` — защита от перебора пароля
--

DROP TABLE IF EXISTS `login_guard`;
CREATE TABLE `login_guard` (
  `ip`           VARCHAR(45)     NOT NULL,
  `fails`        INT UNSIGNED    NOT NULL DEFAULT 0,
  `banned_until` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------

--
-- Структура таблицы `guest_usage` — дневной лимит гостей (20/день)
--

DROP TABLE IF EXISTS `guest_usage`;
CREATE TABLE `guest_usage` (
  `ip`  VARCHAR(45)  NOT NULL,
  `day` DATE         NOT NULL,
  `cnt` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`ip`, `day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------

--
-- ДАННЫЕ: готовый аккаунт администратора
--      логин:  admin
--      пароль: LuaShield@2026
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `created_at`) VALUES
(1, 'admin', '$2y$12$XJaFQk7AIUG9BFu18W23r.ZL9wsc/sPH3wMT2.OxxRlGRrAq5tO42', NOW());

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- -----------------------------------------------------
--  Проверка после импорта: запрос ниже должен вернуть 1 строку.
--  В phpMyAdmin вкладка SQL: SELECT COUNT(*) FROM users;
-- -----------------------------------------------------
