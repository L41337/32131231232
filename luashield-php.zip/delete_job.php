<?php
/** API: POST — удалить запись истории и файл результата. */
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';

$user = ls_require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') ls_json(['ok' => false], 405);
if (!ls_csrf_check()) ls_json(['ok' => false, 'error' => 'CSRF'], 403);

$id = (string)($_POST['id'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $id)) ls_json(['ok' => false, 'error' => 'bad id'], 400);

ls_pdo()->prepare('DELETE FROM jobs WHERE id = ?')->execute([$id]);
$path = LS_STORAGE . '/out/' . $id . '.lua';
if (is_file($path)) unlink($path);
ls_json(['ok' => true]);
