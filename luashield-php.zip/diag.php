<?php
/**
 * LuaShield — диагностика сервера.
 * Откройте в браузере:  http://ваш-сайт/diag.php
 * Если всё работает — УДАЛИТЕ этот файл с сервера.
 */
declare(strict_types=1);

require_once __DIR__ . '/config.php';

header('Content-Type: text/plain; charset=utf-8');

echo "=== LuaShield diagnostics ===\n\n";
echo 'PHP version      : ' . PHP_VERSION . (version_compare(PHP_VERSION, '7.4', '>=') ? "  OK\n" : "  НУЖНО >= 7.4!\n");
echo 'PHP SAPI         : ' . PHP_SAPI . "\n";
echo 'pdo_mysql        : ' . (extension_loaded('pdo_mysql') ? "OK\n" : "НЕТ РАСШИРЕНИЯ!\n");
echo 'upload_max_filesize: ' . ini_get('upload_max_filesize') . "\n";
echo 'post_max_size      : ' . ini_get('post_max_size') . "\n";
echo 'memory_limit       : ' . ini_get('memory_limit') . "\n";
echo 'max_execution_time : ' . ini_get('max_execution_time') . "s\n";

// storage
$outDir = LS_STORAGE . '/out';
if (!is_dir($outDir)) @mkdir($outDir, 0750, true);
$testFile = $outDir . '/.wtest';
$w = @file_put_contents($testFile, 'ok');
echo 'storage writable : ' . ($w !== false ? "OK\n" : "НЕТ ПРАВ НА ЗАПИСЬ! (chmod 750 storage)\n");
if ($w !== false) @unlink($testFile);

// engine
try {
    require_once __DIR__ . '/obfuscator.php';
    [$out, $st] = ls_obfuscate('local a = 1 print("diag", a)');
    echo 'engine           : OK (v' . LS_VERSION . "), " . strlen($out) . " байт\n";
} catch (Throwable $e) {
    echo 'engine           : ОШИБКА: ' . $e->getMessage() . "\n";
}

// DB
try {
    require_once __DIR__ . '/inc/db.php';
    $v = ls_pdo()->query('SELECT VERSION()')->fetchColumn();
    echo 'MySQL connect    : OK (' . $v . ")\n";
    $t = ls_pdo()->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    sort($t);
    echo 'tables           : ' . implode(', ', $t) . "\n";
    $need = ['users', 'jobs', 'login_guard'];
    $missing = array_diff($need, $t);
    echo 'schema           : ' . (empty($missing) ? "OK\n" : 'НЕТ ТАБЛИЦ: ' . implode(', ', $missing) . " — импортируйте database.sql\n");
    if (empty($missing)) {
        $cnt = ls_pdo()->query('SELECT COUNT(*) FROM users')->fetchColumn();
        echo 'admin user rows  : ' . $cnt . ($cnt >= 1 ? "  OK\n" : "  ПУСТО — импортируйте database.sql\n");
    }
} catch (Throwable $e) {
    echo 'MySQL connect    : ОШИБКА: ' . $e->getMessage() . "\n";
}

echo "\nЕсли всё OK — удалите diag.php с сервера.\n";
