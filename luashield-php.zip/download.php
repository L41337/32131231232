<?php
/** Скачивание обфусцированного файла (публично: id — случайный, неугадать). */
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';

$id = (string)($_GET['id'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $id)) { http_response_code(400); exit('bad id'); }

$st = ls_pdo()->prepare('SELECT filename FROM jobs WHERE id = ? LIMIT 1');
$st->execute([$id]);
$row = $st->fetch();

$path = LS_STORAGE . '/out/' . $id . '.lua';
if (!$row || !is_file($path)) { http_response_code(404); exit('not found'); }

$data = file_get_contents($path);

$view = ($_GET['view'] ?? '') === '1';   // ?view=1 — показать код в браузере (для предпросмотра)

ls_security_headers();
header('Content-Type: text/plain; charset=utf-8');
if (!$view) {
    header('Content-Type: text/x-lua; charset=utf-8');
    header('Content-Disposition: attachment; filename="obfuscated.lua"');
}
header('Content-Length: ' . strlen($data));
echo $data;
exit;
