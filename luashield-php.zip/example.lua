-- LuaShield demo script
-- Попробуйте обфусцировать: строки, числа и локалы будут скрыты.

local SECRET_KEY = "sk_live_51N8xQzP0wErTy"
local VERSION = "2.4.1"

local Player = {}
Player.__index = Player

function Player.new(name, level)
  local self = setmetatable({}, Player)
  self.name = name
  self.level = level or 1
  self.inventory = { "sword", "potion" }
  return self
end

function Player:addItem(item)
  self.inventory[#self.inventory + 1] = item
end

function Player:describe()
  return ("[%s] lvl=%d items=%d"):format(self.name, self.level, #self.inventory)
end

local function hashKey(key, salt)
  local h, m = 5381, 33
  for i = 1, #key do
    h = (h * m + key:byte(i) + salt) % 2 ^ 24
  end
  return ("0x%X"):format(h)
end

local p = Player.new("Shadow", 42)
p:addItem("scroll")
p:addItem("gem")

local checks = 0
for i = 1, 100000 do
  if hashKey(SECRET_KEY, i % 7) == "0xDEAD" then
    checks = checks + 1
  end
end

print(p:describe())
print("key hash:", hashKey(SECRET_KEY, 1337))
print("version:", VERSION, "checks:", checks)
