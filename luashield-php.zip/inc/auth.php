<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/db.php';

function ls_session_start(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name(LS_SESSION_NAME);
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
}

function ls_user(): ?array {
    ls_session_start();
    return $_SESSION['user'] ?? null;
}

/** Редирект на login для страниц, 401 JSON для API. */
function ls_require_login(): array {
    $u = ls_user();
    if ($u !== null) return $u;
    $isApi = str_contains($_SERVER['SCRIPT_NAME'] ?? '', 'obfuscate')
          || str_contains($_SERVER['SCRIPT_NAME'] ?? '', 'jobs')
          || str_contains($_SERVER['SCRIPT_NAME'] ?? '', 'delete')
          || (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch');
    if ($isApi) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Требуется вход']);
    } else {
        header('Location: login.php');
    }
    exit;
}

// ------------------ CSRF ------------------

function ls_csrf_token(): string {
    ls_session_start();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function ls_csrf_check(): bool {
    ls_session_start();
    $tok = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
    return is_string($tok) && !empty($_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $tok);
}

// ------------------ гостевой лимит (дневной, по IP) ------------------

function ls_guest_used_today(string $ip): int {
    $st = ls_pdo()->prepare('SELECT cnt FROM guest_usage WHERE ip = ? AND day = ?');
    $st->execute([$ip, date('Y-m-d')]);   // 00:00 по TZ из config.php (Europe/Moscow)
    $v = $st->fetchColumn();
    return $v === false ? 0 : (int)$v;
}

function ls_guest_bump(string $ip): void {
    ls_pdo()->prepare(
        'INSERT INTO guest_usage (ip, day, cnt) VALUES (?, ?, 1)
         ON DUPLICATE KEY UPDATE cnt = cnt + 1'
    )->execute([$ip, date('Y-m-d')]);
}

/** Секунд до сброса лимита (00:00 следующего дня). */
function ls_guest_reset_sec(): int {
    return strtotime('tomorrow') - time();
}

// ------------------ антибрутфорс ------------------

function ls_login_ban_remaining(string $ip): int {
    $st = ls_pdo()->prepare('SELECT fails, banned_until FROM login_guard WHERE ip = ?');
    $st->execute([$ip]);
    $row = $st->fetch();
    if (!$row) return 0;
    $left = (int)$row['banned_until'] - time();
    return max(0, $left);
}

function ls_login_fail(string $ip): void {
    $pdo = ls_pdo();
    $pdo->prepare(
        'INSERT INTO login_guard (ip, fails, banned_until) VALUES (?, 1, 0)
         ON DUPLICATE KEY UPDATE fails = fails + 1'
    )->execute([$ip]);
    $st = $pdo->prepare('SELECT fails FROM login_guard WHERE ip = ?');
    $st->execute([$ip]);
    if ((int)$st->fetchColumn() >= 5) {
        $pdo->prepare('UPDATE login_guard SET fails = 0, banned_until = ? WHERE ip = ?')
            ->execute([time() + 60, $ip]);
    }
}

function ls_login_ok(string $ip): void {
    ls_pdo()->prepare('DELETE FROM login_guard WHERE ip = ?')->execute([$ip]);
}

// ------------------ helpers ------------------

function ls_json(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function ls_security_headers(): void {
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
}

function ls_ip(): string {
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}
