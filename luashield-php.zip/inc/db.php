<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config.php';

function ls_pdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                       LS_DB_HOST, LS_DB_PORT, LS_DB_NAME);
        $pdo = new PDO($dsn, LS_DB_USER, LS_DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}
