<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';

/** SVG-щит логотипа (эмодзи 🛡️ пропадает из-за бага backdrop-filter+color emoji) */
function ls_shield_svg(int $size): string {
    static $n = 0;
    $n++;
    $g = 'shg' . $n;
    return '<svg class="shield-ic" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" aria-hidden="true">'
        . '<defs><linearGradient id="' . $g . '" x1="0" y1="0" x2="1" y2="1">'
        . '<stop offset="0" stop-color="#ff5f72"/><stop offset="1" stop-color="#d31230"/>'
        . '</linearGradient></defs>'
        . '<path d="M12 2l8 3v6c0 5-3.4 9.4-8 11-4.6-1.6-8-6-8-11V5l8-3z" fill="url(#' . $g . ')" stroke="rgba(255,255,255,.35)" stroke-width="1"/>'
        . '<path d="M8.4 12.1l2.4 2.4 4.8-4.9" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>'
        . '</svg>';
}

function ls_head(string $title, ?array $user = null): void {
    ls_security_headers();
    $v = LS_VERSION;
    if ($user !== null) {
        $name = htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8');
        $userHtml = <<<HTML
        <span class="mode-pill admin">ADMIN</span>
        <span class="user-badge">👤 $name</span>
        <a class="btn btn-ghost" href="profile.php">Профиль</a>
        <a class="btn btn-ghost" href="logout.php">Выйти</a>
        HTML;
    } else {
        $userHtml = <<<HTML
        <span class="mode-pill guest">GUEST</span>
        <a class="btn btn-ghost btn-sm" href="login.php">Вход</a>
        HTML;
    }
    $titleEsc = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $shield = ls_shield_svg(22);
    echo <<<HTML
    <!DOCTYPE html>
    <html lang="ru">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>$titleEsc · LuaShield</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='80' font-size='80'>🛡️</text></svg>">
    </head>
    <body>
    <header class="topbar">
      <div class="topbar-inner">
        <div class="logo">$shield <span>Lua</span>Shield</div>
        <div class="top-right">$userHtml</div>
      </div>
    </header>
    <main class="page">
    HTML;
}

function ls_foot(): void {
    $v = LS_VERSION;
    $shield = ls_shield_svg(14);
    echo <<<HTML
    </main>
    <footer class="footer">$shield LuaShield v$v · движок: чистый PHP · совместимость Lua 5.1 / LuaJIT / 5.2–5.4 / Luau</footer>
    </body>
    </html>
    HTML;
}
