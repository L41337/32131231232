<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';
require_once __DIR__ . '/inc/ui.php';

$user = ls_user();                 // null => гость
$isAdmin = $user !== null;
$usedToday = $isAdmin ? 0 : ls_guest_used_today(ls_ip());
$remaining = $isAdmin ? PHP_INT_MAX : max(0, LS_GUEST_LIMIT - $usedToday);

ls_head('Обфускатор Lua', $user);
?>
<meta name="csrf" content="<?= ls_csrf_token() ?>">
<meta name="is-admin" content="<?= $isAdmin ? 1 : 0 ?>">
<meta name="guest-remaining" content="<?= $isAdmin ? -1 : $remaining ?>">
<meta name="guest-limit" content="<?= LS_GUEST_LIMIT ?>">

<?php if (!$isAdmin): ?>
<div class="guest-banner card">
  <div class="gb-left">
    <span class="mode-pill guest">GUEST</span>
    <div>
      <b>Гостевой доступ</b> — обфускация без входа.
      <span class="muted">Осталось сегодня: <b id="guest-left"><?= $remaining ?></b> из <?= LS_GUEST_LIMIT ?>
      · сброс в 00:00 МСК</span>
    </div>
  </div>
  <div class="gb-right">
    <div class="limit-meter"><div id="limit-bar" style="width:<?= (int)(100 * $remaining / max(1, LS_GUEST_LIMIT)) ?>%"></div></div>
  </div>
</div>
<?php endif; ?>

<div class="grid">

  <!-- ===== ЗАГРУЗКА ===== -->
  <section class="card">
    <h2>1 · Загрузите скрипт</h2>
    <form id="obf-form" enctype="multipart/form-data">
      <div id="drop-zone" class="drop-zone">
        <div class="dz-icon">📄</div>
        <div class="dz-text">Перетащите <b>.lua</b> файл сюда<br><span class="muted">или</span></div>
        <label class="btn btn-ghost">
          Выбрать файл с ПК
          <input type="file" id="file-input" name="file" accept=".lua,.luau,.txt,.c,.h" hidden>
        </label>
        <div id="file-name" class="file-name"></div>
      </div>

      <h2>2 · Настройте защиту</h2>
      <div class="opts">
        <label class="opt"><input type="checkbox" name="strings" checked>
          <span><b>Шифрование строк</b><i>строки → зашифрованный blob + рантайм-декриптор</i></span></label>
        <label class="opt"><input type="checkbox" name="rename" checked>
          <span><b>Переименование переменных</b><i>локалы и параметры с анализом scope</i></span></label>
        <label class="opt"><input type="checkbox" name="numbers" checked>
          <span><b>Обфускация чисел</b><i>числа → арифметические выражения в hex</i></span></label>
        <label class="opt"><input type="checkbox" name="wrap" id="opt-wrap">
          <span><b>Полная упаковка (wrap)</b><i>весь чанк → loadstring-загрузчик</i></span></label>
      </div>
      <div class="row">
        <label class="range-label">Мусорный код
          <span class="slider-wrap">
            <input type="range" name="junk" id="junk" min="0" max="10" value="3">
            <span class="slider-scale"><i>0</i><i>5</i><i>10</i></span>
          </span>
          <output id="junk-out" class="range-val">3</output>
        </label>
        <div class="range-label rl-target"><span class="rl-title">Целевая среда</span>
          <select id="target" hidden>
            <option value="gamesense" selected>🎮 gamesense (CS:GO)</option>
            <option value="lua51">Lua 5.1 / LuaJIT</option>
            <option value="lua">Lua 5.2–5.4</option>
            <option value="roblox">Roblox / Luau</option>
          </select>
          <div class="cselect" id="target-cs">
            <button type="button" class="cselect-btn" aria-haspopup="listbox" aria-expanded="false">
              <span class="cs-label">🎯 gamesense (CS:GO)</span>
              <svg class="cs-arrow" viewBox="0 0 10 6" width="11" height="7" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
            <ul class="cselect-list" role="listbox">
              <li class="cs-item on" role="option" data-value="gamesense" data-label="🎯 gamesense (CS:GO)">
                <span class="cs-ic"><svg class="cs-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><circle cx="12" cy="12" r="7.2"/><circle cx="12" cy="12" r="2.6" fill="currentColor" stroke="none"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3"/></svg></span>
                <span class="cs-txt"><b>gamesense (CS:GO)</b><i>LuaJIT · самый безопасный профиль</i></span>
                <span class="cs-check">✓</span>
              </li>
              <li class="cs-item" role="option" data-value="lua51" data-label="Lua 5.1 / LuaJIT">
                <span class="cs-ic"><svg class="cs-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M20.4 13.2A8.4 8.4 0 1 1 10.8 3.6a6.6 6.6 0 0 0 9.6 9.6z"/></svg></span>
                <span class="cs-txt"><b>Lua 5.1 / LuaJIT</b><i>wrap через loadstring работает</i></span>
                <span class="cs-check">✓</span>
              </li>
              <li class="cs-item" role="option" data-value="lua" data-label="Lua 5.2–5.4">
                <span class="cs-ic"><svg class="cs-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a1.6 1.6 0 0 0-1.6 1.6v14.8A1.6 1.6 0 0 0 7 21h10a1.6 1.6 0 0 0 1.6-1.6V8L14 3z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 16.5h6"/></svg></span>
                <span class="cs-txt"><b>Lua 5.2–5.4</b><i>wrap через load работает</i></span>
                <span class="cs-check">✓</span>
              </li>
              <li class="cs-item" role="option" data-value="roblox" data-label="Roblox / Luau">
                <span class="cs-ic"><svg class="cs-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.6l8 4.4v9.6l-8 4.8-8-4.8V7l8-4.4z"/><path d="M12 12.2 20 7.4M12 12.2 4 7.4M12 12.2v8.9"/></svg></span>
                <span class="cs-txt"><b>Roblox / Luau</b><i>wrap недоступен — нет loadstring</i></span>
                <span class="cs-check">✓</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <button class="btn btn-primary btn-block btn-lg" id="submit-btn" type="submit">⚡ Обфусцировать</button>
      <div id="progress" class="progress hidden"><div class="progress-bar"></div></div>
      <div id="form-error" class="alert hidden"></div>
    </form>
  </section>

  <!-- ===== РЕЗУЛЬТАТ ===== -->
  <section class="card" id="result-card">
    <h2>3 · Результат</h2>
    <div id="result-empty" class="muted center">Пока пусто — загрузите скрипт и нажмите «Обфусцировать»</div>
    <div id="result-body" class="hidden">
      <div class="stats" id="stats"></div>
      <div class="row">
        <a class="btn btn-primary" id="dl-btn" href="#">⬇ Скачать obfuscated.lua</a>
        <button class="btn btn-ghost" id="copy-btn">📋 Копировать</button>
      </div>
      <div id="code-caption" class="code-caption muted"></div>
      <pre class="code-view" id="code-view"></pre>
    </div>
  </section>
</div>

<?php if ($isAdmin): ?>
<!-- ===== ИСТОРИЯ (только админ) ===== -->
<section class="card">
  <h2>История обфускаций</h2>
  <div class="table-wrap">
    <table id="jobs-table">
      <thead><tr>
        <th>Время</th><th>Файл</th><th>Размер</th><th>×</th>
        <th>Строки</th><th>Числа</th><th>Локалы</th><th>мс</th><th></th>
      </tr></thead>
      <tbody><tr><td colspan="9" class="muted center">Загрузка…</td></tr></tbody>
    </table>
  </div>
</section>
<?php else: ?>
<section class="card guest-note">
  <h2>Для гостей</h2>
  <p class="muted">✅ До <?= LS_GUEST_LIMIT ?> обфускаций в день бесплатно и без регистрации.<br>
  🔒 История и безлимит — только для администратора.<br>
  🎮 Для gamesense выберите профиль в настройках — скрипты не сломаются (лимит 200 локалов учтён).</p>
</section>
<?php endif; ?>

<script src="assets/app.js"></script>
<?php ls_foot(); ?>
