-- =============================================================
--  LuaShield — схема базы данных MySQL / MariaDB
--  Импорт:  mysql -u root -p < install.sql
-- =============================================================

CREATE DATABASE IF NOT EXISTS `luashield`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `luashield`;

-- -------------------------------------------------------------
--  Пользователи админ-панели
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`      VARCHAR(64)  NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
--  История обфускаций
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `jobs` (
  `id`         CHAR(16)      NOT NULL,
  `user_id`    INT UNSIGNED  NULL,
  `filename`   VARCHAR(190)  NOT NULL DEFAULT 'paste.lua',
  `options`    TEXT          NULL,
  `size_in`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `size_out`   INT UNSIGNED  NOT NULL DEFAULT 0,
  `strings`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `numbers`    INT UNSIGNED  NOT NULL DEFAULT 0,
  `locals`     INT UNSIGNED  NOT NULL DEFAULT 0,
  `comments`   INT UNSIGNED  NOT NULL DEFAULT 0,
  `ms`         INT UNSIGNED  NOT NULL DEFAULT 0,
  `status`     ENUM('ok','error') NOT NULL DEFAULT 'ok',
  `error`      TEXT          NULL,
  `created_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_jobs_user` FOREIGN KEY (`user_id`)
      REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
--  Антибрутфорс входа
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_guard` (
  `ip`           VARCHAR(45)     NOT NULL,
  `fails`        INT UNSIGNED    NOT NULL DEFAULT 0,
  `banned_until` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
--  ГОТОВЫЙ АККАУНТ АДМИНИСТРАТОРА
--    логин:  admin
--    пароль: LuaShield@2026
--  ⚠ СРАЗУ смените пароль в разделе «Профиль» после первого входа!
-- -------------------------------------------------------------
INSERT INTO `users` (`username`, `password_hash`)
VALUES ('admin', '$2y$12$XJaFQk7AIUG9BFu18W23r.ZL9wsc/sPH3wMT2.OxxRlGRrAq5tO42')
ON DUPLICATE KEY UPDATE `id` = `id`;

-- -------------------------------------------------------------
--  (опционально) отдельный пользователь MySQL для приложения:
--  CREATE USER IF NOT EXISTS 'luashield'@'localhost'
--      IDENTIFIED BY 'СМЕНИТЕ_ЭТОТ_ПАРОЛЬ';
--  GRANT SELECT, INSERT, UPDATE, DELETE ON `luashield`.* TO 'luashield'@'localhost';
--  FLUSH PRIVILEGES;
--  и пропишите его в config.php
-- -------------------------------------------------------------
