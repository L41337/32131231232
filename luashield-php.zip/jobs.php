<?php
/** API: GET — история обфускаций. */
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';

$user = ls_require_login();

$st = ls_pdo()->query(
    'SELECT j.id, j.filename, j.size_in, j.size_out, j.strings, j.numbers,
            j.locals, j.comments, j.ms, j.status, j.error,
            UNIX_TIMESTAMP(j.created_at) AS ts, u.username
     FROM jobs j LEFT JOIN users u ON u.id = j.user_id
     ORDER BY j.created_at DESC LIMIT 30'
);
ls_json(['ok' => true, 'jobs' => $st->fetchAll()]);
