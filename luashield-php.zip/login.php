<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';
require_once __DIR__ . '/inc/ui.php';

ls_session_start();
if (ls_user() !== null) { header('Location: index.php'); exit; }

$error = null;
$ip = ls_ip();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!ls_csrf_check()) {
        $error = 'Сессия устарела — обновите страницу';
    } else {
        $ban = ls_login_ban_remaining($ip);
        if ($ban > 0) {
            $error = "Слишком много попыток. Подождите {$ban} сек.";
        } else {
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $st = ls_pdo()->prepare('SELECT id, username, password_hash FROM users WHERE username = ? LIMIT 1');
            $st->execute([$username]);
            $row = $st->fetch();
            if ($row && password_verify($password, $row['password_hash'])) {
                ls_login_ok($ip);
                session_regenerate_id(true);
                $_SESSION['user'] = ['id' => (int)$row['id'], 'username' => $row['username']];
                header('Location: index.php');
                exit;
            }
            ls_login_fail($ip);
            $error = 'Неверный логин или пароль';
        }
    }
}

ls_head('Вход');
?>
<div class="login-wrap">
  <form class="card login-card" method="post" autocomplete="off">
    <div class="login-logo login-logo-full"><?= ls_shield_svg(36) ?><span class="ll-word"><span>Lua</span>Shield</span></div>
    <h1>Вход</h1>
    <p class="muted">Обфускатор Lua-скриптов</p>
    <?php if ($error): ?>
      <div class="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>
    <input type="hidden" name="csrf" value="<?= ls_csrf_token() ?>">
    <label>Логин
      <input type="text" name="username" required autofocus>
    </label>
    <label>Пароль
      <input type="password" name="password" required>
    </label>
    <button class="btn btn-primary btn-block" type="submit">Войти</button>
    <a class="btn btn-ghost btn-block guest-link" href="index.php">🆓 Продолжить как гость — <?= LS_GUEST_LIMIT ?> обфускаций/день</a>
  </form>
</div>
<?php ls_foot(); ?>
