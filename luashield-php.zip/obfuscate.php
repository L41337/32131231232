<?php
/**
 * API: POST обфускация (только multipart-файл «file»).
 * Ответ: {ok, id, stats, download, output}
 */
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';
require_once __DIR__ . '/obfuscator.php';

$user = ls_user();                 // null => гость
$isGuest = ($user === null);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ls_json(['ok' => false, 'error' => 'Только POST'], 405);
}
if (!ls_csrf_check()) {
    ls_json(['ok' => false, 'error' => 'CSRF-проверка не пройдена — обновите страницу'], 403);
}

// гостевой дневной лимит
if ($isGuest) {
    $used = ls_guest_used_today(ls_ip());
    if ($used >= LS_GUEST_LIMIT) {
        $h = (int)ceil(ls_guest_reset_sec() / 3600);
        ls_json([
            'ok' => false,
            'error' => sprintf('Лимит гостя исчерпан: %d обфускаций в день. Сброс через ~%d ч. (в 00:00 МСК)',
                               LS_GUEST_LIMIT, $h),
            'limit' => true,
            'remaining' => 0,
        ], 429);
    }
}

// ---------- входные данные (только файл) ----------
$maxBytes = LS_MAX_MB * 1024 * 1024;

if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
    ls_json(['ok' => false, 'error' => 'Нет данных: загрузите .lua файл'], 400);
}
if (($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    ls_json(['ok' => false, 'error' => 'Ошибка загрузки файла (код ' . (int)$_FILES['file']['error'] . ')'], 400);
}
if ($_FILES['file']['size'] <= 0) {
    ls_json(['ok' => false, 'error' => 'Файл пустой'], 400);
}
if ($_FILES['file']['size'] > $maxBytes) {
    ls_json(['ok' => false, 'error' => 'Файл больше ' . LS_MAX_MB . ' МБ'], 400);
}
$filename = substr(basename((string)$_FILES['file']['name']), 0, 120) ?: 'file.lua';
$source = file_get_contents($_FILES['file']['tmp_name']);
if (!is_string($source) || $source === false) {
    ls_json(['ok' => false, 'error' => 'Не удалось прочитать файл'], 400);
}

// ---------- опции ----------
$on = fn(string $name): bool => in_array($_POST[$name] ?? null, ['on', 'true', '1', 'yes'], true);
$junk = 3;
if (isset($_POST['junk']) && is_numeric($_POST['junk'])) {
    $junk = max(0, min((int)$_POST['junk'], 10));
}
$seed = trim((string)($_POST['seed'] ?? ''));
if ($seed !== '' && ctype_digit($seed)) {
    mt_srand((int)$seed);
    srand((int)$seed);
}
$options = [
    'strings' => $on('strings'),
    'numbers' => $on('numbers'),
    'rename'  => $on('rename'),
    'wrap'    => $on('wrap'),
    'junk'    => $junk,
];

// ---------- обфускация ----------
$jobId = substr(bin2hex(random_bytes(8)), 0, 16);
$pdo = ls_pdo();

$userId = $user['id'] ?? null;
try {
    [$out, $stats] = ls_obfuscate($source, $options);
} catch (ObfuscatorException $e) {
    $pdo->prepare('INSERT INTO jobs (id, user_id, filename, options, size_in, size_out,
        strings, numbers, locals, comments, ms, status, error)
        VALUES (?,?,?,?,?,0,0,0,0,0,0,?,?)')
        ->execute([$jobId, $userId, $filename, json_encode($options),
                   strlen($source), 'error', $e->getMessage()]);
    ls_json(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('LuaShield obfuscate: ' . $e);
    ls_json(['ok' => false, 'error' => 'Внутренняя ошибка движка'], 500);
}

// успех: засчитать гостевую попытку
if ($isGuest) ls_guest_bump(ls_ip());

$outDir = LS_STORAGE . '/out';
if (!is_dir($outDir)) mkdir($outDir, 0750, true);
file_put_contents($outDir . '/' . $jobId . '.lua', $out);

$pdo->prepare('INSERT INTO jobs (id, user_id, filename, options, size_in, size_out,
    strings, numbers, locals, comments, ms, status, error)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL)')
    ->execute([$jobId, $userId, $filename, json_encode($options),
               $stats['size_in'], $stats['size_out'], $stats['strings_encrypted'],
               $stats['numbers_obfuscated'], $stats['locals_renamed'],
               $stats['comments_removed'], $stats['time_ms'], 'ok']);

$resp = [
    'ok'       => true,
    'id'       => $jobId,
    'stats'    => $stats,
    'download' => 'download.php?id=' . $jobId,
    'output'   => strlen($out) <= 300000 ? $out : null,
];
if ($isGuest) {
    $resp['guest_remaining'] = max(0, LS_GUEST_LIMIT - ls_guest_used_today(ls_ip()));
}
ls_json($resp);
