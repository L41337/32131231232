<?php
/**
 * LuaShield — движок обфускации Lua (чистый PHP, без внешних зависимостей).
 *
 * Проходы:
 *  1. Удаление комментариев
 *  2. Шифрование строк (blob + рантайм-декриптор; аддитивный шифр — работает
 *     на Lua 5.1 / LuaJIT / 5.2 / 5.3 / 5.4 / Luau, bit-библиотеки не нужны)
 *  3. Мусорный (мёртвый) код
 *  4. Переименование локальных переменных с анализом областей видимости
 *     (рекурсивный спуск: shadowing, upvalues, repeat-until, методы, ключи)
 *  5. Обфускация чисел (арифметические выражения в hex)
 *  6. Минификация
 *  7. Wrap — вся программа в зашифрованный loadstring/load-загрузчик
 *
 * CLI:  php obfuscator.php input.lua -o out.lua --wrap
 */

declare(strict_types=1);

if (!defined('LS_VERSION')) define('LS_VERSION', '1.4.9');

const LS_KEYWORDS = [
    'and' => 1, 'break' => 1, 'do' => 1, 'else' => 1, 'elseif' => 1,
    'end' => 1, 'false' => 1, 'for' => 1, 'function' => 1, 'goto' => 1,
    'if' => 1, 'in' => 1, 'local' => 1, 'nil' => 1, 'not' => 1, 'or' => 1,
    'repeat' => 1, 'return' => 1, 'then' => 1, 'true' => 1, 'until' => 1,
    'while' => 1, 'continue' => 1,
];

class ObfuscatorException extends Exception {}
class LexError extends ObfuscatorException {}
class LSParseError extends ObfuscatorException {}

/* ====================================================================
 *  ЛЕКСЕР
 * ==================================================================*/

function ls_is_name_start(string $c): bool {
    $o = ord($c);
    return ($o >= 97 && $o <= 122) || ($o >= 65 && $o <= 90) || $o === 95;
}

function ls_is_name_char(string $c): bool {
    $o = ord($c);
    return ($o >= 97 && $o <= 122) || ($o >= 65 && $o <= 90) || $o === 95
        || ($o >= 48 && $o <= 57);
}

function ls_long_bracket(string $src, int $i, string $ch): ?array {
    $n = strlen($src);
    if ($i >= $n || $src[$i] !== $ch) return null;
    $j = $i + 1;
    while ($j < $n && $src[$j] === '=') $j++;
    if ($j < $n && $src[$j] === $ch) return [$j - $i - 1, $j + 1];
    return null;
}

/** @return array{0: array, 1: int} [tokens, comments_count]; token: [type, text, line] */
function ls_lex(string $src): array {
    static $SYMS = ['...', '::', '<<', '>>', '//', '==', '~=', '<=', '>=',
                    '+=', '-=', '*=', '/=', '%=', '^=', '..'];
    static $SINGLE = '+-*/%^#&~|<>=(){}[];:,.?';
    static $NUM = '/\G(?:0[xX][0-9a-fA-F]+(?:\.[0-9a-fA-F]*)?(?:[pP][+-]?\d+)?|\d+(?:\.\d*)?(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?)/';

    global $LS_COMMENT_COUNT;
    $toks = [];
    $comments = 0;
    $i = 0; $n = strlen($src); $line = 1;
    while ($i < $n) {
        $c = $src[$i];
        if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\f" || $c === "\v") { $i++; continue; }
        if ($c === "\n") { $line++; $i++; continue; }

        // комментарии
        if ($c === '-' && $i + 1 < $n && $src[$i + 1] === '-') {
            $i += 2;
            $lb = ls_long_bracket($src, $i, '[');
            if ($lb !== null) {
                [$level, $start] = $lb;
                $close = ']' . str_repeat('=', $level) . ']';
                $end = strpos($src, $close, $start);
                if ($end === false) throw new LexError("незакрытый длинный комментарий (строка $line)");
                $line += substr_count($src, "\n", $start, $end - $start);
                $i = $end + strlen($close);
            } else {
                $j = strpos($src, "\n", $i);
                $i = ($j === false) ? $n : $j;
            }
            $comments++;
            continue;
        }

        // интерполированные строки Luau — небезопасны для rename
        if ($c === '`') {
            throw new LexError("интерполированные строки Luau (`...{x}...`) не поддерживаются (строка $line) — используйте конкатенацию ..");
        }

        // короткие строки
        if ($c === '"' || $c === "'") {
            $q = $c; $j = $i + 1; $ok = false;
            while ($j < $n) {
                $ch = $src[$j];
                if ($ch === '\\') {
                    $j++;
                    if ($j < $n && $src[$j] === "\n") $line++;
                    $j++;
                    continue;
                }
                if ($ch === "\n") break;
                if ($ch === $q) { $ok = true; $j++; break; }
                $j++;
            }
            if (!$ok) throw new LexError("незакрытая строка (строка $line)");
            $toks[] = ['str', substr($src, $i, $j - $i), $line];
            $i = $j;
            continue;
        }

        // длинные строки
        if ($c === '[') {
            $lb = ls_long_bracket($src, $i, '[');
            if ($lb !== null) {
                [$level, $start] = $lb;
                $close = ']' . str_repeat('=', $level) . ']';
                $end = strpos($src, $close, $start);
                if ($end === false) throw new LexError("незакрытая длинная строка (строка $line)");
                $toks[] = ['str', substr($src, $i, $end + strlen($close) - $i), $line];
                $line += substr_count($src, "\n", $i, $end - $i);
                $i = $end + strlen($close);
                continue;
            }
        }

        // числа
        $co = ord($c);
        if (($co >= 48 && $co <= 57) || ($c === '.' && $i + 1 < $n && ord($src[$i + 1]) >= 48 && ord($src[$i + 1]) <= 57)) {
            if (!preg_match($NUM, $src, $m, 0, $i)) {
                throw new LexError("ошибка лексера числа (строка $line)");
            }
            $text = $m[0];
            $j = $i + strlen($text);
            // "1..2" -> '1' '..' '2'
            if (substr($text, -1) === '.' && $j < $n && $src[$j] === '.') {
                $text = substr($text, 0, -1);
                $j--;
            }
            $toks[] = ['num', $text, $line];
            $i = $j;
            continue;
        }

        // имена / ключевые слова
        if (ls_is_name_start($c)) {
            $j = $i + 1;
            while ($j < $n && ls_is_name_char($src[$j])) $j++;
            $word = substr($src, $i, $j - $i);
            $toks[] = [isset(LS_KEYWORDS[$word]) ? 'kw' : 'name', $word, $line];
            $i = $j;
            continue;
        }

        // символы
        $matched = false;
        foreach ($SYMS as $s) {
            if (substr($src, $i, strlen($s)) === $s) {
                $toks[] = ['sym', $s, $line];
                $i += strlen($s);
                $matched = true;
                break;
            }
        }
        if ($matched) continue;
        if (strpos($SINGLE, $c) !== false) {
            $toks[] = ['sym', $c, $line];
            $i++;
            continue;
        }
        throw new LexError("неожиданный символ " . json_encode($c) . " (строка $line)");
    }
    return [$toks, $comments];
}

/* ====================================================================
 *  ДЕКОДИРОВАНИЕ СТРОКОВЫХ ЛИТЕРАЛОВ
 * ==================================================================*/

function ls_utf8_encode(int $cp): string {
    if ($cp < 0x80) return chr($cp);
    if ($cp < 0x800) return chr(0xC0 | ($cp >> 6)) . chr(0x80 | ($cp & 0x3F));
    if ($cp < 0x10000) return chr(0xE0 | ($cp >> 12)) . chr(0x80 | (($cp >> 6) & 0x3F)) . chr(0x80 | ($cp & 0x3F));
    return chr(0xF0 | ($cp >> 18)) . chr(0x80 | (($cp >> 12) & 0x3F)) . chr(0x80 | (($cp >> 6) & 0x3F)) . chr(0x80 | ($cp & 0x3F));
}

function ls_decode_string(string $raw): string {
    static $ESC = ['a' => 7, 'b' => 8, 'f' => 12, 'n' => 10, 'r' => 13,
                   't' => 9, 'v' => 11, '\\' => 92, '"' => 34, "'" => 39, "\n" => 10];
    if ($raw[0] === '[') {
        [$level, $start] = ls_long_bracket($raw, 0, '[');
        $body = substr($raw, $start, strlen($raw) - $start - ($level + 2));
        if (substr($body, 0, 2) === "\r\n") $body = substr($body, 2);
        elseif ($body !== '' && ($body[0] === "\n" || $body[0] === "\r")) $body = substr($body, 1);
        return $body;
    }
    $q = $raw[0];
    $out = '';
    $i = 1; $n = strlen($raw) - 1;
    while ($i < $n) {
        $c = $raw[$i];
        if ($c === $q) break;
        if ($c !== '\\') { $out .= $c; $i++; continue; }
        $i++;
        if ($i >= $n) break;
        $e = $raw[$i];
        $eo = ord($e);
        if ($eo >= 48 && $eo <= 57) {
            $j = $i;
            while ($j < $n && $j < $i + 3 && ord($raw[$j]) >= 48 && ord($raw[$j]) <= 57) $j++;
            $out .= chr(((int)substr($raw, $i, $j - $i)) & 0xFF);
            $i = $j;
            continue;
        }
        if ($e === 'x') { $out .= chr(hexdec(substr($raw, $i + 1, 2)) & 0xFF); $i += 3; continue; }
        if ($e === 'z') {
            $i++;
            while ($i < $n && strpos(" \t\r\n\f\v", $raw[$i]) !== false) $i++;
            continue;
        }
        if ($e === 'u') { // \u{XXX} (5.3+) -> UTF-8 байты
            $j = strpos($raw, '}', $i);
            $cp = hexdec(substr($raw, $i + 2, $j - $i - 2));
            $out .= ls_utf8_encode($cp);
            $i = $j + 1;
            continue;
        }
        $out .= isset($ESC[$e]) ? chr($ESC[$e]) : $e;
        $i++;
    }
    return $out;
}

function ls_esc_bytes(string $bs): string {
    $out = '';
    $n = strlen($bs);
    for ($i = 0; $i < $n; $i++) $out .= sprintf('\\%03d', ord($bs[$i]));
    return $out;
}

/** Байты -> hex-строка (только печатные символы, рост ровно x2). */
function ls_hex(string $bs): string {
    return bin2hex($bs);
}

/* ====================================================================
 *  ГЕНЕРАТОР ИМЁН
 * ==================================================================*/

class LSNameGen {
    public array $avoid = [];
    public int $c;
    public string $prefix;

    public function __construct(iterable $names) {
        foreach ($names as $nm) $this->avoid[$nm] = true;
        foreach (array_keys(LS_KEYWORDS) as $kw) $this->avoid[$kw] = true;
        $this->avoid[''] = true;
        $this->c = random_int(0, 999);
        $this->prefix = '';
        for ($i = 0; $i < 4; $i++) $this->prefix .= chr(random_int(97, 122));
    }

    public function newName(): string {
        while (true) {
            $this->c++;
            $nm = '_' . $this->prefix . $this->c;
            if (!isset($this->avoid[$nm])) {
                $this->avoid[$nm] = true;
                return $nm;
            }
        }
    }
}

/* ====================================================================
 *  МУСОРНЫЙ КОД
 * ==================================================================*/

function ls_gen_junk(LSNameGen $gen, int $count): string {
    // каждый блок в do...end — мусор НЕ создаёт локалов на верхнем уровне
    // (важно для LuaJIT-окружений с лимитом 200 локалов, напр. gamesense)
    $parts = [];
    for ($k = 0; $k < $count; $k++) {
        $v = $gen->newName();
        $parts[] = "do local $v=" . random_int(1000, 1000000000) . '%' . random_int(3, 997);
        $f = $gen->newName(); $p = $gen->newName(); $q = $gen->newName();
        $parts[] = "local function $f($p,$q) return ($p*" . random_int(2, 999)
                 . "+$q*" . random_int(2, 999) . ")%" . random_int(2, 997) . " end";
        $w = $gen->newName();
        $parts[] = "local $w=$f(" . random_int(1, 9999) . ',' . random_int(1, 9999) . ') end';
    }
    return implode("\n", $parts);
}

/* ====================================================================
 *  ПАРСЕР ОБЛАСТЕЙ ВИДИМОСТИ + ПЕРЕИМЕНОВАНИЕ ЛОКАЛОВ
 * ==================================================================*/

class LSScope {
    public ?LSScope $parent;
    public array $decls = [];   // name => [newname|null, visible_from_pos]

    public function __construct(?LSScope $parent) { $this->parent = $parent; }

    public function resolve(string $name, int $pos): ?string {
        $s = $this;
        while ($s !== null) {
            if (isset($s->decls[$name])) {
                $e = $s->decls[$name];
                if ($pos >= $e[1]) return $e[0];   // null => self, без переименования
            }
            $s = $s->parent;
        }
        return null;
    }
}

class LSRenamer {
    private array $t;
    private int $i = 0;
    private LSNameGen $gen;
    public array $renames = [];  // token_index => newname
    public int $ndecls = 0;

    private const BINP = [
        'or' => [1, 1], 'and' => [2, 2],
        '<' => [3, 3], '>' => [3, 3], '<=' => [3, 3], '>=' => [3, 3],
        '~=' => [3, 3], '==' => [3, 3],
        '|' => [4, 4], '~' => [5, 5], '&' => [6, 6],
        '<<' => [7, 7], '>>' => [7, 7],
        '..' => [9, 8],
        '+' => [10, 10], '-' => [10, 10],
        '*' => [11, 11], '/' => [11, 11], '//' => [11, 11], '%' => [11, 11],
        '^' => [14, 13],
    ];
    private const UNARY_PREC = 12;
    private const ASSIGN = ['=' => 1, '+=' => 1, '-=' => 1, '*=' => 1, '/=' => 1, '%=' => 1, '^=' => 1];
    private const BLOCK_END = ['end' => 1, 'else' => 1, 'elseif' => 1, 'until' => 1];

    public function __construct(array $toks, LSNameGen $gen) {
        $this->t = $toks;
        $this->gen = $gen;
    }

    private function peek(int $k = 0): array {
        $j = $this->i + $k;
        if ($j < count($this->t)) return $this->t[$j];
        $line = count($this->t) ? $this->t[count($this->t) - 1][2] : 1;
        return [null, null, $line];
    }

    private function eof(): bool { return $this->i >= count($this->t); }

    private function adv(): array { return $this->t[$this->i++]; }

    private function at_kw(string $v): bool {
        $t = $this->peek();
        return $t[0] === 'kw' && $t[1] === $v;
    }

    private function at_sym(string $v): bool {
        $t = $this->peek();
        return $t[0] === 'sym' && $t[1] === $v;
    }

    private function expect_kw(string $v): array {
        if (!$this->at_kw($v)) {
            $t = $this->peek();
            throw new LSParseError("ожидалось '$v', найдено '" . ($t[1] ?? 'EOF') . "' (строка {$t[2]})");
        }
        return $this->adv();
    }

    private function expect_sym(string $v): array {
        if (!$this->at_sym($v)) {
            $t = $this->peek();
            throw new LSParseError("ожидался символ '$v', найдено '" . ($t[1] ?? 'EOF') . "' (строка {$t[2]})");
        }
        return $this->adv();
    }

    private function declare(LSScope $scope, int $nameTokIdx): void {
        $name = $this->t[$nameTokIdx][1];
        $new = $this->gen->newName();
        $scope->decls[$name] = [$new, $this->i];
        $this->renames[$nameTokIdx] = $new;
        $this->ndecls++;
    }

    private function ref(LSScope $scope, int $nameTokIdx): void {
        $name = $this->t[$nameTokIdx][1];
        $new = $scope->resolve($name, $nameTokIdx);
        if ($new !== null) $this->renames[$nameTokIdx] = $new;
    }

    private function skip_type_ann(): void {
        if ($this->at_sym('<') && $this->peek(1)[0] === 'name' && $this->peek(2)[1] === '>') {
            $this->adv(); $this->adv(); $this->adv();
            return;
        }
        if (!$this->at_sym(':') || $this->peek(1)[1] === ':') return;
        $t1 = $this->peek(1);
        if ($t1[0] !== 'name' && !in_array($t1[1], ['(', '{', '...'], true)) return;
        $this->adv(); // ':'
        $depth = 0;
        while (!$this->eof()) {
            $t = $this->peek();
            if ($depth === 0 && (in_array($t[1], [',', '=', ')', 'do', 'then', ';'], true)
                || ($t[0] === 'kw' && $t[1] === 'in'))) return;
            if (in_array($t[1], ['<', '(', '{'], true)) $depth++;
            elseif (in_array($t[1], ['>', ')', '}'], true)) {
                if ($depth === 0) return;
                $depth--;
            }
            $this->adv();
        }
    }

    public function parse(): void {
        $scope = new LSScope(null);
        $this->parse_block($scope, []);
        if (!$this->eof()) {
            $t = $this->peek();
            throw new LSParseError("мусор в конце чанка около '" . ($t[1] ?? '') . "' (строка {$t[2]})");
        }
    }

    private function parse_block(LSScope $scope, array $stops): void {
        while (!$this->eof()) {
            $t = $this->peek();
            if ($t[0] === 'kw' && in_array($t[1], $stops, true)) return;
            $this->parse_statement($scope);
        }
    }

    private function parse_statement(LSScope $s): void {
        $t = $this->peek();
        if ($t[0] === 'sym') {
            if ($t[1] === ';') { $this->adv(); return; }
            if ($t[1] === '::') { $this->adv(); $this->adv(); $this->expect_sym('::'); return; }
            if ($t[1] === '(') { $this->parse_suffixed($s); $this->maybe_assignment($s); return; }
            throw new LSParseError("неожиданный символ '{$t[1]}' в начале оператора (строка {$t[2]})");
        }
        if ($t[0] === 'name') {
            $this->parse_suffixed($s);
            $this->maybe_assignment($s);
            return;
        }
        if ($t[0] !== 'kw') {
            throw new LSParseError("неожиданный токен '" . ($t[1] ?? 'EOF') . "' (строка {$t[2]})");
        }

        $kw = $t[1];
        switch ($kw) {
        case 'local':
            $this->adv();
            if ($this->at_kw('function')) {
                $this->adv();
                $nameIdx = $this->i;
                if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя (строка {$this->peek()[2]})");
                $this->adv();
                $this->declare($s, $nameIdx);
                $this->parse_funcbody($s, false);
            } else {
                $nameIdxs = [];
                while (true) {
                    if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя после local (строка {$this->peek()[2]})");
                    $nameIdxs[] = $this->i;
                    $this->adv();
                    $this->skip_type_ann();
                    if ($this->at_sym(',')) { $this->adv(); continue; }
                    break;
                }
                if ($this->at_sym('=')) {
                    $this->adv();
                    $this->parse_explist($s);   // RHS видит только внешние имена
                }
                foreach ($nameIdxs as $idx) $this->declare($s, $idx);
            }
            return;

        case 'function':
            $this->adv();
            if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя после function (строка {$this->peek()[2]})");
            $this->ref($s, $this->i);
            $this->adv();
            $method = false;
            while ($this->at_sym('.')) {
                $this->adv();
                if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя после '.' (строка {$this->peek()[2]})");
                $this->adv();
            }
            if ($this->at_sym(':')) { $this->adv(); $this->adv(); $method = true; }
            $this->parse_funcbody($s, $method);
            return;

        case 'if':
            $this->adv();
            $this->parse_expr($s);
            $this->expect_kw('then');
            $this->parse_block(new LSScope($s), ['elseif', 'else', 'end']);
            while ($this->at_kw('elseif')) {
                $this->adv();
                $this->parse_expr($s);
                $this->expect_kw('then');
                $this->parse_block(new LSScope($s), ['elseif', 'else', 'end']);
            }
            if ($this->at_kw('else')) {
                $this->adv();
                $this->parse_block(new LSScope($s), ['end']);
            }
            $this->expect_kw('end');
            return;

        case 'while':
            $this->adv();
            $this->parse_expr($s);
            $this->expect_kw('do');
            $this->parse_block(new LSScope($s), ['end']);
            $this->expect_kw('end');
            return;

        case 'do':
            $this->adv();
            $this->parse_block(new LSScope($s), ['end']);
            $this->expect_kw('end');
            return;

        case 'for':
            $this->adv();
            $nameIdxs = [];
            while (true) {
                if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя переменной цикла (строка {$this->peek()[2]})");
                $nameIdxs[] = $this->i;
                $this->adv();
                $this->skip_type_ann();
                if ($this->at_sym(',')) { $this->adv(); continue; }
                break;
            }
            if ($this->at_sym('=')) { $this->adv(); $this->parse_explist($s); }
            else { $this->expect_kw('in'); $this->parse_explist($s); }
            $this->expect_kw('do');
            $body = new LSScope($s);
            foreach ($nameIdxs as $idx) $this->declare($body, $idx);
            $this->parse_block($body, ['end']);
            $this->expect_kw('end');
            return;

        case 'repeat':
            $this->adv();
            $body = new LSScope($s);
            $this->parse_block($body, ['until']);
            $this->expect_kw('until');
            $this->parse_expr($body);   // until видит локалы repeat-блока!
            return;

        case 'return':
            $this->adv();
            $nt = $this->peek();
            if (!($this->eof() || ($nt[0] === 'kw' && isset(self::BLOCK_END[$nt[1] ?? ''])) || $nt[1] === ';')) {
                $this->parse_explist($s);
            }
            if ($this->at_sym(';')) $this->adv();
            return;

        case 'break':
        case 'continue':
            $this->adv();
            return;

        case 'goto':
            $this->adv();
            $this->adv();   // имя метки — не переменная
            return;
        }
        throw new LSParseError("неожиданное ключевое слово '$kw' (строка {$t[2]})");
    }

    private function maybe_assignment(LSScope $s): void {
        while ($this->at_sym(',')) { $this->adv(); $this->parse_suffixed($s); }
        $t = $this->peek();
        if ($t[0] === 'sym' && isset(self::ASSIGN[$t[1] ?? ''])) {
            $this->adv();
            $this->parse_explist($s);
        }
    }

    private function parse_explist(LSScope $s): void {
        $this->parse_expr($s);
        while ($this->at_sym(',')) { $this->adv(); $this->parse_expr($s); }
    }

    private function parse_expr(LSScope $s, int $mp = 0): void {
        $t = $this->peek();
        if (($t[0] === 'kw' && $t[1] === 'not')
            || ($t[0] === 'sym' && ($t[1] === '-' || $t[1] === '#' || $t[1] === '~'))) {
            $this->adv();
            $this->parse_expr($s, self::UNARY_PREC);
        } else {
            $this->parse_primary($s);
        }
        while (true) {
            $t = $this->peek();
            $op = null;
            if ($t[0] === 'kw' && ($t[1] === 'and' || $t[1] === 'or')) $op = $t[1];
            elseif ($t[0] === 'sym' && isset(self::BINP[$t[1] ?? ''])) $op = $t[1];
            if ($op === null || self::BINP[$op][0] <= $mp) return;
            $this->adv();
            $this->parse_expr($s, self::BINP[$op][1]);
        }
    }

    private function parse_primary(LSScope $s): void {
        $t = $this->peek();
        if ($t[0] === 'num' || $t[0] === 'str') { $this->adv(); return; }
        if ($t[0] === 'kw') {
            if ($t[1] === 'nil' || $t[1] === 'true' || $t[1] === 'false') { $this->adv(); return; }
            if ($t[1] === 'function') { $this->adv(); $this->parse_funcbody($s, false); return; }
            throw new LSParseError("неожиданное слово '{$t[1]}' в выражении (строка {$t[2]})");
        }
        if ($t[0] === 'sym') {
            if ($t[1] === '...') { $this->adv(); return; }
            if ($t[1] === '{') { $this->parse_tablector($s); return; }
        }
        $this->parse_suffixed($s);
    }

    private function parse_suffixed(LSScope $s): void {
        $t = $this->peek();
        if ($this->at_sym('(')) {
            $this->adv();
            $this->parse_expr($s);
            $this->expect_sym(')');
        } elseif ($t[0] === 'name') {
            $this->ref($s, $this->i);
            $this->adv();
        } else {
            throw new LSParseError("ожидалось выражение, найдено '" . ($t[1] ?? 'EOF') . "' (строка {$t[2]})");
        }
        while (!$this->eof()) {
            $t = $this->peek();
            if (($t[1] ?? null) === '.') {
                $this->adv();
                if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя поля (строка {$this->peek()[2]})");
                $this->adv();
            } elseif (($t[1] ?? null) === '[') {
                $this->adv();
                $this->parse_expr($s);
                $this->expect_sym(']');
            } elseif (($t[1] ?? null) === ':') {
                $this->adv();
                if ($this->peek()[0] !== 'name') throw new LSParseError("ожидалось имя метода (строка {$this->peek()[2]})");
                $this->adv();
                $this->parse_call_args($s);
            } elseif (($t[1] ?? null) === '(' || ($t[1] ?? null) === '{' || $t[0] === 'str') {
                $this->parse_call_args($s);
            } else {
                return;
            }
        }
    }

    private function parse_call_args(LSScope $s): void {
        $t = $this->peek();
        if (($t[1] ?? null) === '(') {
            $this->adv();
            if (!$this->at_sym(')')) $this->parse_explist($s);
            $this->expect_sym(')');
        } elseif (($t[1] ?? null) === '{') {
            $this->parse_tablector($s);
        } elseif ($t[0] === 'str') {
            $this->adv();
        } else {
            throw new LSParseError("неверные аргументы вызова (строка {$t[2]})");
        }
    }

    private function parse_tablector(LSScope $s): void {
        $this->expect_sym('{');
        while (!$this->eof() && !$this->at_sym('}')) {
            $t = $this->peek();
            if ($this->at_sym('[')) {
                $this->adv();
                $this->parse_expr($s);
                $this->expect_sym(']');
                $this->expect_sym('=');
                $this->parse_expr($s);
            } elseif ($t[0] === 'name' && $this->peek(1)[1] === '=') {
                $this->adv(); $this->adv();
                $this->parse_expr($s);
            } else {
                $this->parse_expr($s);
            }
            if ($this->at_sym(',') || $this->at_sym(';')) $this->adv();
            else break;
        }
        $this->expect_sym('}');
    }

    private function parse_funcbody(LSScope $s, bool $method): void {
        $this->expect_sym('(');
        $body = new LSScope($s);
        $declared = [];
        if ($method) {
            // неявный self: переименовывать нельзя (токена нет), но внешние
            // локалы с именем self он экранирует (null-запись)
            $body->decls['self'] = [null, $this->i];
        }
        while (!$this->eof() && !$this->at_sym(')')) {
            $t = $this->peek();
            if (($t[1] ?? null) === '...') {
                $this->adv();
                if ($this->at_sym(',')) throw new LSParseError("'...' должно быть последним параметром (строка {$t[2]})");
                break;
            }
            if ($t[0] !== 'name') throw new LSParseError("ожидалось имя параметра (строка {$t[2]})");
            $declared[] = $this->i;
            $this->adv();
            $this->skip_type_ann();
            if ($this->at_sym(',')) { $this->adv(); continue; }
            break;
        }
        $this->expect_sym(')');
        foreach ($declared as $idx) $this->declare($body, $idx);
        $this->parse_block($body, ['end']);
        $this->expect_kw('end');
    }
}

/* ====================================================================
 *  ПРОХОДЫ
 * ==================================================================*/


/** Ключ из 24 печатных байтов (35..126, без кавычки и бэкслеша) —
 *  встраивается в Lua-строку raw, без эскейпов. */
function ls_printable_key(): string {
    $k = '';
    while (strlen($k) < 24) {
        $b = random_int(35, 126);
        if ($b === 34 || $b === 92) continue;
        $k .= chr($b);
    }
    return $k;
}

function ls_cipher(string $data, string $key): string {
    $kl = strlen($key);
    $n = strlen($data);
    $out = '';
    for ($i = 0; $i < $n; $i++) {
        $out .= chr((ord($data[$i]) + ord($key[$i % $kl])) % 256);
    }
    return $out;
}

/** @return array [tokens, prelude_len, total, unique] */
function ls_strings_pass(array $toks, LSNameGen $gen): array {
    $values = [];
    $indexOf = [];
    $total = 0;
    foreach ($toks as $tok) {
        if ($tok[0] !== 'str') continue;
        $v = ls_decode_string($tok[1]);
        $total++;
        if (!array_key_exists($v, $indexOf)) {
            $indexOf[$v] = count($values);
            $values[] = $v;
        }
    }
    if ($total === 0) return [$toks, 0, 0, 0];

    $A = $gen->newName();
    $newToks = [];
    foreach ($toks as $tok) {
        if ($tok[0] === 'str') {
            $idx = $indexOf[ls_decode_string($tok[1])] + 1;   // 1-based
            $newToks[] = ['sym', '(', $tok[2]];
            $newToks[] = ['name', $A, $tok[2]];
            $newToks[] = ['sym', '[', $tok[2]];
            $newToks[] = ['num', (string)$idx, $tok[2]];
            $newToks[] = ['sym', ']', $tok[2]];
            $newToks[] = ['sym', ')', $tok[2]];
        } else {
            $newToks[] = $tok;
        }
    }

    // blob: 4 байта длины (big endian) + данные
    $blob = '';
    foreach ($values as $v) $blob .= pack('N', strlen($v)) . $v;

    $key = ls_printable_key();
    $enc = ls_cipher($blob, $key);

    $K = $gen->newName(); $D = $gen->newName(); $T = $gen->newName();
    $I = $gen->newName(); $B = $gen->newName(); $ARR = $A; $P = $gen->newName();
    $a = $gen->newName(); $b = $gen->newName(); $c = $gen->newName();
    $d = $gen->newName(); $l = $gen->newName(); $N = $gen->newName();

    $kraw = $key;
    $dhex = ls_hex($enc);
    // Дешифратор в do...end: на верхнем уровне остаётся РОВНО ОДИН локал ($ARR).
    // Это критично для LuaJIT окружений (gamesense): лимит 200 локалов
    // на область видимости, наши внутренние переменные их не расходуют.
    $prelude =
        "local $ARR do "
        . "local $K=\"$kraw\" local $D=\"$dhex\" local $T={} local $N=#$D*0.5 "
        . "for $I=1,$N do $T"."[$I]=string.char((tonumber($D:sub($I*2-1,$I*2),16)-$K:byte(($I-1)%#$K+1))%256) end "
        . "local $B=table.concat($T) $ARR={} local $P=1 "
        . "while $P<=#$B do "
        . "local $a,$b,$c,$d=$B:byte($P,$P+3) "
        . "local $l=$a*16777216+$b*65536+$c*256+$d "
        . "$P=$P+4 $ARR"."[#$ARR+1]=$B:sub($P,$P+$l-1) $P=$P+$l "
        . "end end";
    [$preludeToks] = ls_lex($prelude);
    $preludeLen = count($preludeToks);
    return [array_merge($preludeToks, $newToks), $preludeLen, $total, count($values)];
}

function ls_number_expr(string $text): ?string {
    if (preg_match('/^\d+$/', $text)) {
        if (strlen($text) > 10) return null;
        $val = (int)$text;
    } elseif (preg_match('/^0[xX][0-9a-fA-F]+$/', $text)) {
        if (strlen($text) > 10) return null;
        $val = (int)hexdec(substr($text, 2));
    } else {
        return null;
    }
    if ($val > 2147483647) return null;
    $a = random_int(0, 268435456);
    $b = $val - $a;
    if ($b >= 0) {
        return random_int(0, 1)
            ? sprintf('(0x%X+0x%X)', $b, $a)
            : sprintf('(0x%X+0x%X)', $a, $b);
    }
    return sprintf('(0x%X-0x%X)', $a, -$b);
}

function ls_needs_space(string $a, string $b): bool {
    if ($a === '' || $b === '') return false;
    $ca = $a[strlen($a) - 1];
    $cb = $b[0];
    if (ls_is_name_char($ca) && ls_is_name_char($cb)) return true;
    if ($ca === '-' && $cb === '-') return true;
    if ($ca === '.' && ($cb === '.' || $cb === '0' || ($cb >= '1' && $cb <= '9'))) return true;
    if ($ca >= '0' && $ca <= '9' && $cb === '.') return true;
    if ($ca === ':' && $cb === ':') return true;
    if ($ca === '=' && $cb === '=') return true;
    if (($ca === '<' && $cb === '<') || ($ca === '>' && $cb === '>')) return true;
    if ($ca === '/' && $cb === '/') return true;
    if ($ca === '~' && $cb === '=') return true;
    return false;
}

/** @return array [text, numbers_count] */
function ls_minify(array $toks, array $renames, bool $doNumbers): array {
    $out = '';
    $prev = '';
    $numbers = 0;
    foreach ($toks as $idx => $tok) {
        [$ttype, $text] = $tok;
        if ($ttype === 'sym' && $text === ';') continue;  // разделители не нужны
        if (isset($renames[$idx])) {
            $text = $renames[$idx];
        } elseif ($ttype === 'num' && $doNumbers) {
            $ne = ls_number_expr($text);
            if ($ne !== null) { $text = $ne; $numbers++; }
        }
        if (ls_needs_space($prev, $text)) $out .= ' ';
        $out .= $text;
        $prev = $text;
    }
    return [$out, $numbers];
}

function ls_wrap_pass(string $source): string {
    static $used = [];
    $used = [];
    $rn = function () use (&$used) {
        while (true) {
            $len = random_int(5, 9);
            $nm = '';
            for ($i = 0; $i < $len; $i++) $nm .= chr(random_int(97, 122));
            if (!isset($used[$nm]) && !isset(LS_KEYWORDS[$nm])) {
                $used[$nm] = true;
                return $nm;
            }
        }
    };
    $key = ls_printable_key();
    $enc = ls_cipher($source, $key);

    $K = $rn(); $D = $rn(); $T = $rn(); $I = $rn(); $C = $rn(); $F = $rn(); $N = $rn();
    $kraw = $key;
    $dhex = ls_hex($enc);
    // hex-кодировка: рост x2 вместо x4 — важно для лимита размера скриптов gamesense
    $loader =
        "local $K=\"$kraw\" local $D=\"$dhex\" local $T={} "
        . "local $N=#$D*0.5 "
        . "for $I=1,$N do $T"."[$I]=string.char((tonumber($D:sub($I*2-1,$I*2),16)-$K:byte(($I-1)%#$K+1))%256) end "
        . "local $C=table.concat($T) "
        . "local $F=((loadstring)or(load))($C,\"=LuaShield\") "
        . "return $F(...)";
    [$toks] = ls_lex($loader);
    [$text] = ls_minify($toks, [], false);
    return $text;
}

/* ====================================================================
 *  ОСНОВНАЯ ФУНКЦИЯ
 * ==================================================================*/

const LS_DEFAULT_OPTIONS = [
    'strings' => true,
    'numbers' => true,
    'rename'  => true,
    'junk'    => 3,
    'wrap'    => false,
];

/** @return array [output, stats] */
function ls_obfuscate(string $source, array $options = []): array {
    $opts = array_merge(LS_DEFAULT_OPTIONS, $options);
    $t0 = microtime(true);

    // BOM / shebang (источник — сырые байты)
    if (substr($source, 0, 3) === "\xEF\xBB\xBF") $source = substr($source, 3);
    if (substr($source, 0, 2) === '#!') {
        $nl = strpos($source, "\n");
        $source = ($nl === false) ? '' : substr($source, $nl + 1);
    }

    [$toks, $ncomments] = ls_lex($source);
    $names = [];
    foreach ($toks as $tok) if ($tok[0] === 'name') $names[] = $tok[1];
    $gen = new LSNameGen($names);

    // 1. строки
    $strTotal = 0; $strUniq = 0; $preludeLen = 0;
    if ($opts['strings']) {
        [$toks, $preludeLen, $strTotal, $strUniq] = ls_strings_pass($toks, $gen);
    }

    // 2. мусор — сразу после прелюда строк
    $junkN = max(0, min((int)$opts['junk'], 10));
    if ($junkN > 0) {
        [$junkToks] = ls_lex(ls_gen_junk($gen, $junkN));
        array_splice($toks, $preludeLen, 0, $junkToks);
    }

    // 3. переименование
    $renames = [];
    $ndecls = 0;
    if ($opts['rename']) {
        $r = new LSRenamer($toks, $gen);
        $r->parse();
        $renames = $r->renames;
        $ndecls = $r->ndecls;
    }

    // 4+5. числа + минификация
    [$text, $numbersN] = ls_minify($toks, $renames, (bool)$opts['numbers']);

    // 6. wrap
    if ($opts['wrap']) $text = ls_wrap_pass($text);

    $stats = [
        'comments_removed'  => $ncomments,
        'strings_encrypted' => $strTotal,
        'strings_unique'    => $strUniq,
        'numbers_obfuscated'=> $numbersN,
        'locals_renamed'    => $ndecls,
        'size_in'           => strlen($source),
        'size_out'          => strlen($text),
        'time_ms'           => (int)round((microtime(true) - $t0) * 1000),
        'options'           => array_intersect_key($opts, LS_DEFAULT_OPTIONS),
    ];
    return [$text, $stats];
}

/* ====================================================================
 *  CLI
 * ==================================================================*/

if (PHP_SAPI === 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    // ручной разбор аргументов (getopt() не любит опции ПОСЛЕ позиционного файла)
    $opts = [];
    $input = null;
    $args = array_slice($GLOBALS['argv'], 1);
    for ($i = 0; $i < count($args); $i++) {
        $a = $args[$i];
        switch ($a) {
            case '-o': case '--output':
                $opts['output'] = $args[++$i] ?? null; break;
            case '--junk':
                $opts['junk'] = $args[++$i] ?? null; break;
            case '--seed':
                $opts['seed'] = $args[++$i] ?? null; break;
            case '--all': $opts['all'] = true; break;
            case '--no-strings': $opts['no-strings'] = true; break;
            case '--no-numbers': $opts['no-numbers'] = true; break;
            case '--no-rename':  $opts['no-rename'] = true; break;
            case '--wrap': $opts['wrap'] = true; break;
            case '--help': case '-h': $opts['help'] = true; break;
            default:
                if ($a !== '' && $a[0] !== '-' && $input === null) $input = $a;
                elseif ($a !== '' && $a[0] === '-') {
                    fwrite(STDERR, "Неизвестная опция: $a\n");
                    exit(1);
                }
        }
    }
    if (isset($opts['help']) || !$input) {
        fwrite(STDERR, "LuaShield v" . LS_VERSION . " — обфускатор Lua
Использование: php obfuscator.php input.lua [опции]
  -o, --output FILE   куда писать (по умолч. <input>.obf.lua)
  --all               все проходы + wrap
  --no-strings        не шифровать строки
  --no-numbers        не трогать числа
  --no-rename         не переименовывать локалы
  --junk N            мусорный код 0-10 (по умолч. 3)
  --wrap              упаковать весь чанк (loadstring/load)
  --seed N            фиксированный seed
");
        exit($input ? 0 : 1);
    }
    if (isset($opts['seed'])) { mt_srand((int)$opts['seed']); srand((int)$opts['seed']); }
    $source = file_get_contents($input);
    if ($source === false) { fwrite(STDERR, "Не читается файл: $input\n"); exit(2); }

    $o = [];
    if (isset($opts['no-strings'])) $o['strings'] = false;
    if (isset($opts['no-numbers'])) $o['numbers'] = false;
    if (isset($opts['no-rename']))  $o['rename'] = false;
    if (isset($opts['junk']))       $o['junk'] = (int)$opts['junk'];
    if (isset($opts['wrap']) || isset($opts['all'])) $o['wrap'] = true;

    try {
        [$out, $stats] = ls_obfuscate($source, $o);
    } catch (ObfuscatorException $e) {
        fwrite(STDERR, 'Ошибка: ' . $e->getMessage() . "\n");
        exit(2);
    }
    $outPath = $opts['output'] ?? ($input . '.obf.lua');
    file_put_contents($outPath, $out);

    echo "OK: $input -> $outPath\n";
    printf("  размер: %d -> %d байт (x%.2f)\n", $stats['size_in'], $stats['size_out'],
           $stats['size_out'] / max(1, $stats['size_in']));
    printf("  строк: %d (уник. %d), чисел: %d, локалов: %d, коммент.: %d, %d мс\n",
           $stats['strings_encrypted'], $stats['strings_unique'],
           $stats['numbers_obfuscated'], $stats['locals_renamed'],
           $stats['comments_removed'], $stats['time_ms']);
    exit(0);
}
