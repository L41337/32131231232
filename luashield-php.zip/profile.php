<?php
declare(strict_types=1);

require_once __DIR__ . '/inc/auth.php';
require_once __DIR__ . '/inc/ui.php';

$user = ls_require_login();
$msg = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!ls_csrf_check()) {
        $error = 'Сессия устарела — обновите страницу';
    } else {
        $cur = (string)($_POST['current'] ?? '');
        $new = (string)($_POST['new'] ?? '');
        $new2 = (string)($_POST['new2'] ?? '');
        $st = ls_pdo()->prepare('SELECT password_hash FROM users WHERE id = ? LIMIT 1');
        $st->execute([$user['id']]);
        $hash = (string)$st->fetchColumn();
        if (!password_verify($cur, $hash)) {
            $error = 'Текущий пароль неверен';
        } elseif (strlen($new) < 8) {
            $error = 'Новый пароль — минимум 8 символов';
        } elseif ($new !== $new2) {
            $error = 'Пароли не совпадают';
        } else {
            ls_pdo()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_BCRYPT), $user['id']]);
            $msg = 'Пароль успешно изменён';
        }
    }
}

ls_head('Профиль', $user);
?>
<div class="login-wrap">
  <form class="card login-card" method="post">
    <div class="login-logo">⚙️</div>
    <h1>Смена пароля</h1>
    <p class="muted"><?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8') ?> ·
      <a class="link" href="index.php">← назад в панель</a></p>
    <?php if ($error): ?><div class="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if ($msg): ?><div class="alert ok"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <input type="hidden" name="csrf" value="<?= ls_csrf_token() ?>">
    <label>Текущий пароль <input type="password" name="current" required></label>
    <label>Новый пароль <input type="password" name="new" required minlength="8"></label>
    <label>Новый пароль ещё раз <input type="password" name="new2" required minlength="8"></label>
    <button class="btn btn-primary btn-block" type="submit">Сменить пароль</button>
  </form>
</div>
<?php ls_foot(); ?>
