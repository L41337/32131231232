<?php
/** API: GET — демо-скрипт для кнопки «Загрузить пример» (публично). */
declare(strict_types=1);
require_once __DIR__ . '/inc/auth.php';

$code = file_get_contents(__DIR__ . '/example.lua');
ls_json(['ok' => true, 'code' => $code]);
