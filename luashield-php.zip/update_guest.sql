-- =============================================================
--  МИНИ-ОБНОВЛЕНИЕ: добавляет гостевой режим (таблица guest_usage)
--  Для тех, у кого УЖЕ стоит предыдущая версия LuaShield.
--  Импорт: phpMyAdmin → выбрать вашу базу → Импорт → этот файл.
--  Данные (admin, история) НЕ удаляются!
-- =============================================================

CREATE TABLE IF NOT EXISTS `guest_usage` (
  `ip`  VARCHAR(45)  NOT NULL,
  `day` DATE         NOT NULL,
  `cnt` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`ip`, `day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'guest_usage ready' AS status;
