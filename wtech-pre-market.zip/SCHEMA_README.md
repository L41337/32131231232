# +W.TECH FORUM — database schema

`schema.sql` creates every MySQL table the PHP code touches (users, categories,
threads, posts, attachments, chat, online, typing, conversations, pm, tickets,
ticket_replies) with the correct columns, character set (utf8mb4) and indexes.

## Import

### Option A — phpMyAdmin (Beget panel)
1. Open the DB `l43087cr_1337` in phpMyAdmin.
2. Tab **Import** → choose `schema.sql` → **Go**.

### Option B — command line
```bash
mysql -u l43087cr_1337 -p l43087cr_1337 < schema.sql
```

The script uses `CREATE TABLE IF NOT EXISTS` and `INSERT IGNORE`, so re-running
it is safe — nothing existing will be dropped or overwritten.

## What the seed gives you

* Four starter categories: **announcements**, **general**, **support**, **showcase**.
* One owner account:

  | field    | value                |
  |----------|----------------------|
  | username | `owner`              |
  | password | `ChangeMe123!`       |
  | email    | `owner@example.com`  |
  | role     | `owner`              |

**Log in as `owner` and change the password + email immediately** from the profile
page (or delete that INSERT before importing if you'd rather register the owner
through the site's normal sign-up flow).

## Runtime data folders

The PHP code creates these on demand (they are already denied to the web by
`data/.htaccess`, no schema needed):

* `data/pending/`   — sign-up email-confirmation records (6-digit code).
* `data/reset/`     — password-reset tokens.
* `data/throttle/`  — per-IP rate-limit counters.
