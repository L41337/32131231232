<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/security.php';   // centralized hardening layer

// Stricter session settings — must run BEFORE session_start().
sec_session_harden();

// Secure session cookie.
// NOTE: do NOT pass an empty 'domain' — an empty Domain= makes the Set-Cookie
// invalid and the browser drops the session. Beget's default session.save_path
// already works, so we keep it (no custom save_path).
session_set_cookie_params([
    'lifetime' => 60 * 60 * 24 * 7,
    'path'     => '/',
    'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

// Never cache API responses (otherwise /me and chat polling can be served stale)
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// Apply the security layer: hardened headers, request firewall and the
// CSRF check (requires the X-Requested-With header on mutating requests —
// the SPA sends it on every API call; see app.js).
sec_bootstrap_api();

// Get-or-create a 1:1 conversation between two user ids (ordered lo/hi).
function get_or_create_conversation($a, $b) {
    $lo = min($a, $b); $hi = max($a, $b);
    $c = db_row('SELECT * FROM conversations WHERE user1_id=? AND user2_id=?', [$lo, $hi]);
    if ($c) return $c;
    $now = time();
    db()->prepare('INSERT INTO conversations (user1_id,user2_id,created_at,updated_at) VALUES (?,?,?,?)')
        ->execute([$lo, $hi, $now, $now]);
    return db_row('SELECT * FROM conversations WHERE id=?', [db()->lastInsertId()]);
}

// Validate + normalize client-supplied attachment descriptors for a post.
// A client may only reference files it ACTUALLY uploaded: server-generated
// upload names always look like "/assets/uploads/<uid>_<20hex>.<ext>", so
// anything else is dropped silently (matching the previous lenient behaviour
// for malformed entries — legit clients see no difference).
function clean_attachments($atts, $uid) {
    $out = [];
    if (!is_array($atts)) return $out;
    $prefix = '/assets/uploads/' . (int)$uid . '_';
    foreach ($atts as $a) {
        if (count($out) >= 10) break;                       // sane cap per post
        if (!is_array($a)) continue;
        $url = trim((string)($a['url'] ?? ''));
        if ($url === '' || strpos($url, $prefix) !== 0) continue;      // only OUR uploads, only OUR files
        if (!preg_match('#^/assets/uploads/\\d+_[a-f0-9]{16,40}\\.[a-z0-9]{2,5}$#i', $url)) continue;
        $name = utf8_limit(trim(str_replace(["\0", "\r", "\n"], '', (string)($a['name'] ?? ''))), 255);
        $mime = trim((string)($a['mime'] ?? ''));
        if (!preg_match('#^[a-z0-9][a-z0-9!#$&^_.+\\-]{0,60}/[a-z0-9][a-z0-9!#$&^_.+\\-]{0,60}$#i', $mime)) $mime = 'application/octet-stream';
        $size = (int)($a['size'] ?? 0);
        if ($size < 0 || $size > 15 * 1024 * 1024) $size = 0;         // display-only value, keep it sane
        $out[] = ['url' => $url, 'name' => $name, 'mime' => $mime, 'size' => $size];
    }
    return $out;
}

try {
    // The action name and the read/write method gate don't need the database,
    // so they run before the connection is opened.
    $action = strtolower(param('action') ?: '');

    // Writes must arrive via POST (see security.php 6b): blocks CSRF-by-link
    // (SameSite=Lax sends the session cookie on top-level GET navigations, so
    // state-changing actions over GET were abusable). Every legit SPA write
    // already uses POST, so this changes nothing for real users.
    sec_require_method_for_action($action);

    $pdo  = db();
    $user = current_user();

    // Banned accounts are locked out of the entire API except reading their own
    // status (so the client can render the ban screen with the reason) and
    // logging out. This enforces the ban server-side, not only in the UI.
    if ($user && !empty($user['banned']) && !in_array($action, ['me', 'logout'], true)) {
        // Include the fresh user record so the client can show the ban reason
        // immediately (the client's cached state.user was loaded before the ban
        // and has an empty banReason).
        json_out(['error' => 'Your account is banned.', 'banned' => 1, 'user' => public_user($user)], 403);
    }

    switch ($action) {

    /* ---------------- Auth ---------------- */
    case 'me':
        // unreadNotif — для колокольчика уведомлений: me дергается часто,
        // поэтому бейдж обновляется без отдельных запросов.
        json_out(['user' => $user ? public_user($user) : null, 'unreadNotif' => $user ? notif_unread_count($user['id']) : 0]);
        break;

    case 'login':
        $username = param('username');
        $password = param('password');
        // Brute-force protection (per IP + username).
        $throttle = sec_auth_check($username);
        if ($throttle) json_out(['error' => $throttle], 429);
        sec_auth_record($username);
        $u = db_row('SELECT * FROM users WHERE username=?', [$username]);
        if (!$u || !password_verify((string)$password, $u['password_hash'])) json_out(['error' => 'Invalid username or password'], 401);
        // NOTE: banned users ARE allowed to log in — they get a valid session but
        // the global guard below locks them to `me`/`logout` only, and the client
        // shows the full-screen ban screen (with the reason) so they can read why
        // they were banned and log out. We no longer hard-block login here.
        sec_auth_reset($username);          // success — clear the attempt counter
        session_regenerate_id(true);        // prevent session fixation
        $_SESSION['user_id'] = $u['id'];
        if (!empty(param('remember'))) {
            // Persistent "Remember me" token — survives logout so the user can
            // one-click quick-login later. Stored hashed; cookie is httpOnly.
            $token = bin2hex(random_bytes(32));
            db()->prepare('UPDATE users SET remember_token=? WHERE id=?')->execute([hash('sha256', $token), $u['id']]);
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            setcookie('wtech_remember', $u['id'] . ':' . $token, ['expires' => time() + 30 * 86400, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
        }
        json_out(['user' => public_user($u)]);
        break;

    case 'register':
        // Step 1 of 2: validate the requested credentials, save them into a
        // short-lived pending signup record and email a 6-digit confirmation
        // code. The DB user row is only created after the code is verified
        // by the register_verify action below.
        $username = trim((string)param('username'));
        $password = (string)param('password');
        $email    = trim((string)(param('email') ?? ''));
        // Email is REQUIRED now — the code has to be delivered somewhere.
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120) {
            json_out(['error' => 'Please enter a valid email address (we need it to send the confirmation code).'], 400);
        }
        // Throttle mass account creation (per IP + username).
        $throttle = sec_auth_check('register:' . $username);
        if ($throttle) json_out(['error' => $throttle], 429);
        sec_auth_record('register:' . $username);
        // Mass-registration guard: total per-IP bucket (file-based, so it also
        // works for clients that drop cookies). Generous — stops bot floods,
        // not people.
        $ipReg = sec_ip_throttle('register-ip', 30, 3600);
        if ($ipReg) json_out(['error' => $ipReg], 429);
        if (!$username || !$password) json_out(['error' => 'Username and password required'], 400);
        if (!preg_match('/^[a-zA-Z0-9_.\-]{3,20}$/', $username)) json_out(['error' => 'Username must be 3-20 chars (letters, numbers, _ . -)'], 400);
        if (strlen($password) < 6) json_out(['error' => 'Password must be at least 6 characters'], 400);
        if (db_row('SELECT id FROM users WHERE username=?', [$username])) json_out(['error' => 'Username already taken'], 409);
        // Prevent someone else grabbing an email that already belongs to a
        // real account (would also break the reset flow).
        if (db_row('SELECT id FROM users WHERE email=?', [$email])) json_out(['error' => 'This email is already in use.'], 409);

        // Stash the pending signup and email the code.
        $hash = password_hash($password, PASSWORD_BCRYPT);
        [$token, $code] = pending_save($username, $email, $hash, 900);
        $mail = build_signup_code_email($username, $code);
        pending_gc();
        $sent = sec_send_mail($email, 'Your +W.TECH FORUM confirmation code', $mail['html'], $mail['text']);
        if (!$sent) {
            // If mail() rejected the address outright, roll the pending record
            // back and tell the user — otherwise the sign-up dialog would hang.
            pending_consume($token);
            json_out(['error' => 'We could not send the confirmation email. Please double-check the address and try again.'], 500);
        }
        json_out([
            'pending'    => true,
            'token'      => $token,
            'email_mask' => mask_email($email),
            'ttl'        => 900,
            'message'    => 'We sent a 6-digit confirmation code to ' . mask_email($email) . '. Enter it to finish creating your account.',
        ]);
        break;

    case 'register_verify':
        // Step 2 of 2: user submits the code we emailed. If it matches,
        // create the actual account and log them in.
        $token = (string)param('token');
        $code  = preg_replace('/\D+/', '', (string)param('code'));
        // Per-IP throttle so a code can't be brute-forced from many angles.
        $ipErr = sec_ip_throttle('register-verify', 30, 900);
        if ($ipErr) json_out(['error' => $ipErr], 429);
        if (strlen($code) !== 6) json_out(['error' => 'Enter the 6-digit code from the email.'], 400);
        $j = pending_load($token);
        if (!$j) json_out(['error' => 'This confirmation has expired. Please sign up again.'], 400);
        // Per-token attempt cap (defence in depth on top of the IP throttle).
        $attempts = (int)($j['attempts'] ?? 0);
        if ($attempts >= 8) {
            pending_consume($token);
            json_out(['error' => 'Too many wrong codes. Please sign up again.'], 429);
        }
        if (!hash_equals((string)$j['code_hash'], hash('sha256', $code))) {
            $j['attempts'] = $attempts + 1;
            pending_write($token, $j);
            json_out(['error' => 'Wrong code. Please try again.'], 400);
        }
        // Race check: did someone claim this username while we were waiting?
        if (db_row('SELECT id FROM users WHERE username=?', [$j['username']])) {
            pending_consume($token);
            json_out(['error' => 'That username was just taken. Please sign up again with a different one.'], 409);
        }
        if (db_row('SELECT id FROM users WHERE email=?', [$j['email']])) {
            pending_consume($token);
            json_out(['error' => 'That email was just used to register another account.'], 409);
        }
        $colors = ['#ff3232','#ff7a45','#ffb020','#46d39a','#5b8cff','#a06bff','#ff5fa2','#3ad0d0'];
        $color  = $colors[array_rand($colors)];
        // HWID is gone from the site: accounts are identified by username/email
        // only. Run db_migration_drop_hwid.sql to drop the column completely.
        try {
            db()->prepare('INSERT INTO users (username,email,role,password_hash,joined_at,bio,color) VALUES (?,?,?,?,?,?,?)')
                ->execute([$j['username'], $j['email'], 'member', $j['password_hash'], time(), '', $color]);
        } catch (Throwable $e) {
            // Fallback for databases that still have the legacy NOT NULL hwid
            // column (run db_migration_drop_hwid.sql to remove it): insert an
            // empty placeholder so registration keeps working.
            db()->prepare('INSERT INTO users (username,email,role,password_hash,hwid,joined_at,bio,color) VALUES (?,?,?,?,\'\',?,?,?)')
                ->execute([$j['username'], $j['email'], 'member', $j['password_hash'], time(), '', $color]);
        }
        $id = $pdo->lastInsertId();
        pending_consume($token);
        session_regenerate_id(true);   // prevent session fixation
        $_SESSION['user_id'] = $id;
        $u = db_row('SELECT * FROM users WHERE id=?', [$id]);
        json_out(['user' => public_user($u)]);
        break;

    case 'register_resend':
        // Ask for a fresh 6-digit code for the same pending signup.
        $token = (string)param('token');
        // Rate-limit resend requests hard — one every 30s per IP is plenty.
        $ipErr = sec_ip_throttle('register-resend', 6, 900);
        if ($ipErr) json_out(['error' => $ipErr], 429);
        $j = pending_load($token);
        if (!$j) json_out(['error' => 'This confirmation has expired. Please sign up again.'], 400);
        // Additional per-token cool-down.
        if (time() - (int)($j['last_sent_at'] ?? 0) < 30) {
            json_out(['error' => 'Please wait a few seconds before requesting another code.'], 429);
        }
        $code = pending_new_code($token);
        if (!$code) json_out(['error' => 'This confirmation has expired. Please sign up again.'], 400);
        $mail = build_signup_code_email($j['username'], $code);
        sec_send_mail($j['email'], 'Your +W.TECH FORUM confirmation code', $mail['html'], $mail['text']);
        json_out(['ok' => true, 'email_mask' => mask_email($j['email'])]);
        break;

    case 'logout':
        sec_logout_harden();   // Clear-Site-Data + expire session/remember/csrf cookies
        session_destroy();
        json_out(['ok' => true]);
        break;

    /* ---------------- Quick login (passwordless, from Remember-me token) ---------------- */
    case 'quick_login_info':
        // Display-only: tells the UI which account (if any) can be quick-logged-in.
        // Does NOT authenticate.
        $u = quick_user_from_cookie();
        json_out(['user' => $u ? public_user($u) : null]);
        break;

    case 'quick_login':
        $u = quick_user_from_cookie();
        if (!$u) json_out(['error' => 'Session expired, please log in again'], 401);
        session_regenerate_id(true);   // prevent session fixation (same as password login)
        $_SESSION['user_id'] = $u['id'];
        // Rotate the token after each use (re-auth).
        $token = bin2hex(random_bytes(32));
        db()->prepare('UPDATE users SET remember_token=? WHERE id=?')->execute([hash('sha256', $token), $u['id']]);
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        setcookie('wtech_remember', $u['id'] . ':' . $token, ['expires' => time() + 30 * 86400, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
        json_out(['user' => public_user($u)]);
        break;

    case 'quick_forget':
        // Forget this device: clear the stored token + expire the cookie.
        if (!empty($_COOKIE['wtech_remember'])) {
            $parts = explode(':', (string)$_COOKIE['wtech_remember'], 2);
            if (count($parts) === 2) {
                $u = db_row('SELECT * FROM users WHERE id=?', [(int)$parts[0]]);
                if ($u) db()->prepare('UPDATE users SET remember_token="" WHERE id=?')->execute([$u['id']]);
            }
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            setcookie('wtech_remember', '', ['expires' => 1, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
        }
        json_out(['ok' => true]);
        break;

    /* ---------------- Categories / threads ---------------- */
    case 'categories':
        $cats = db_all('SELECT * FROM categories ORDER BY ord ASC');
        $out = [];
        foreach ($cats as $c) {
            $tc = (int)db_val('SELECT COUNT(*) FROM threads WHERE category_id=?', [$c['id']]);
            $pc = (int)db_val('SELECT COUNT(*) FROM posts p JOIN threads t ON t.id=p.thread_id WHERE t.category_id=?', [$c['id']]);
            $last = db_row('SELECT title,updated_at FROM threads WHERE category_id=? ORDER BY updated_at DESC LIMIT 1', [$c['id']]);
            $out[] = [
                'id' => $c['id'], 'name' => $c['name'], 'description' => $c['description'], 'icon' => $c['icon'],
                'threadCount' => $tc, 'postCount' => $pc,
                'last' => $last ? ['title' => $last['title'], 'at' => (int)$last['updated_at']] : null,
            ];
        }
        json_out(['categories' => $out]);
        break;

    /* ---- Admin: create / delete categories ---- */
    case 'category_create':
        if (!is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $name = utf8_limit(trim((string)param('name')), 64);
        $desc = utf8_limit(trim((string)param('description')), 255);
        $icon = utf8_limit(trim((string)param('icon')), 8);
        if ($name === '') json_out(['error' => 'Category name is required'], 400);
        $id  = make_category_slug($name);
        $ord = (param('ord') !== null && param('ord') !== '')
             ? (int)param('ord')
             : ((int)db_val('SELECT COALESCE(MAX(ord),0) FROM categories') + 1);
        db()->prepare('INSERT INTO categories (id,name,description,icon,ord) VALUES (?,?,?,?,?)')
            ->execute([$id, $name, $desc, $icon, $ord]);
        json_out(['category' => [
            'id' => $id, 'name' => $name, 'description' => $desc, 'icon' => $icon, 'ord' => $ord,
            'threadCount' => 0, 'postCount' => 0, 'last' => null,
        ]]);
        break;

    case 'category_delete':
        if (!is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $id = (string)param('id');
        $c  = db_row('SELECT * FROM categories WHERE id=?', [$id]);
        if (!$c) json_out(['error' => 'Category not found'], 404);
        $tc = (int)db_val('SELECT COUNT(*) FROM threads WHERE category_id=?', [$id]);
        if ($tc > 0) json_out(['error' => "Cannot delete: this category still has {$tc} thread(s). Move or delete them first."], 409);
        db()->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);
        json_out(['ok' => true]);
        break;

    case 'threads':
        $cat  = param('category');
        $page = max(1, (int)(param('page') ?: 1));
        $per  = 15;
        $where = $cat ? ' WHERE category_id=?' : '';
        $params = $cat ? [$cat] : [];
        $total = (int)db_val('SELECT COUNT(*) FROM threads' . $where, $params);
        $pages = max(1, ceil($total / $per));
        $list = db_all('SELECT * FROM threads' . $where . ' ORDER BY pinned DESC, updated_at DESC LIMIT ' . (($page-1)*$per) . ',' . $per, $params);
        json_out(['threads' => array_map('public_thread', $list), 'page' => $page, 'per' => $per, 'total' => $total, 'pages' => $pages]);
        break;

    case 'thread':
        $id = (int)param('id');
        $t = db_row('SELECT * FROM threads WHERE id=?', [$id]);
        if (!$t) json_out(['error' => 'Thread not found'], 404);
        db()->prepare('UPDATE threads SET views=views+1 WHERE id=?')->execute([$id]);
        $cat = db_row('SELECT * FROM categories WHERE id=?', [$t['category_id']]);
        $posts = db_all('SELECT p.*, u.username, u.color, u.role, u.avatar_url, u.avatar_border FROM posts p LEFT JOIN users u ON u.id=p.author_id WHERE p.thread_id=? ORDER BY p.id ASC', [$id]);
        $atts = [];
        if ($posts) {
            $ids = [];
            foreach ($posts as $p) $ids[] = (int)$p['id'];
            $rows = db_all('SELECT * FROM attachments WHERE post_id IN (' . implode(',', $ids) . ')');
            foreach ($rows as $r) {
                $atts[(int)$r['post_id']][] = ['id' => (int)$r['id'], 'url' => $r['url'], 'name' => $r['name'], 'mime' => $r['mime'], 'size' => (int)$r['size']];
            }
        }
        $outPosts = array_map(function ($p) use ($atts) {
            return ['id' => (int)$p['id'], 'content' => $p['content'], 'createdAt' => (int)$p['created_at'],
                    'author' => ['id' => (int)$p['author_id'], 'username' => $p['username'], 'color' => $p['color'], 'role' => $p['role'], 'avatar' => !empty($p['avatar_url']) ? $p['avatar_url'] : null, 'avatarBorder' => $p['avatar_border'] ?? ''],
                    'attachments' => isset($atts[(int)$p['id']]) ? $atts[(int)$p['id']] : []];
        }, $posts);
        json_out(['thread' => array_merge(public_thread($t), ['category' => $cat ? ['id' => $cat['id'], 'name' => $cat['name']] : null]),
                  'posts' => $outPosts,
                  // Карта ник→роль для подсветки @упоминаний цветом роли.
                  'mentionRoles' => mention_roles_map(array_column($posts, 'content'))]);
        break;

    case 'thread_create':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $cat = param('categoryId');
        // Server-side caps mirror the client limits (title 120 / body 5000) —
        // a hand-rolled request can no longer stuff unbounded text into the DB.
        $title   = utf8_limit(trim(str_replace("\0", '', (string)param('title'))), 120);
        $content = utf8_limit(trim(str_replace("\0", '', (string)param('content'))), 5000);
        if (!db_row('SELECT id FROM categories WHERE id=?', [$cat])) json_out(['error' => 'Invalid category'], 400);
        if (strlen($title) < 3) json_out(['error' => 'Title too short'], 400);
        if ($content === '' && empty(param('attachments'))) json_out(['error' => 'Content required'], 400);
        // Flood guard (security.php 8b) — stops scripted thread spam.
        $flood = sec_flood_gate($user, 'thread');
        if ($flood) json_out(['error' => $flood['error']], $flood['code']);
        $now = time();
        db()->prepare('INSERT INTO threads (category_id,author_id,title,pinned,locked,views,created_at,updated_at) VALUES (?,?,?,0,0,0,?,?)')
            ->execute([$cat, $user['id'], $title, $now, $now]);
        $tid = $pdo->lastInsertId();
        db()->prepare('INSERT INTO posts (thread_id,author_id,content,created_at) VALUES (?,?,?,?)')->execute([$tid, $user['id'], $content, $now]);
        $pid = $pdo->lastInsertId();
        // Persist any attachments the client sent with the opening post
        // (validated: only this user's own real uploads may be referenced).
        foreach (clean_attachments(param('attachments'), $user['id']) as $a) {
            db()->prepare('INSERT INTO attachments (post_id,user_id,url,name,mime,size,created_at) VALUES (?,?,?,?,?,?,?)')
                ->execute([$pid, $user['id'], $a['url'], $a['name'], $a['mime'], $a['size'], $now]);
        }
        // @упоминания в первом посте темы → уведомления (как в post_create:
        // раньше упомянутый узнавал о теме, только если его тегнули в ответе).
        foreach (find_mentions($content, $user['id']) as $mu) {
            notify_user($mu['id'], 'mention', $user['username'], $title, 'thread/' . $tid);
        }
        $t = db_row('SELECT * FROM threads WHERE id=?', [$tid]);
        json_out(['thread' => public_thread($t)]);
        break;

    case 'post_create':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $id = (int)param('id');
        $t = db_row('SELECT * FROM threads WHERE id=?', [$id]);
        if (!$t) json_out(['error' => 'Thread not found'], 404);
        if ($t['locked']) json_out(['error' => 'Thread is locked'], 403);
        // Server-side cap mirrors the client limit (5000 chars).
        $content = utf8_limit(trim(str_replace("\0", '', (string)param('content'))), 5000);
        if ($content === '' && empty(param('attachments'))) json_out(['error' => 'Reply cannot be empty'], 400);
        // Flood guard (security.php 8b) — stops scripted reply spam.
        $flood = sec_flood_gate($user, 'post');
        if ($flood) json_out(['error' => $flood['error']], $flood['code']);
        $now = time();
        db()->prepare('INSERT INTO posts (thread_id,author_id,content,created_at) VALUES (?,?,?,?)')->execute([$id, $user['id'], $content, $now]);
        $pid = $pdo->lastInsertId();
        // (validated: only this user's own real uploads may be referenced).
        foreach (clean_attachments(param('attachments'), $user['id']) as $a) {
            db()->prepare('INSERT INTO attachments (post_id,user_id,url,name,mime,size,created_at) VALUES (?,?,?,?,?,?,?)')
                ->execute([$pid, $user['id'], $a['url'], $a['name'], $a['mime'], $a['size'], $now]);
        }
        db()->prepare('UPDATE threads SET updated_at=? WHERE id=?')->execute([$now, $id]);
        // Уведомления: автору темы (ответ) + адресаты @упоминаний.
        if ((int)$t['author_id'] !== (int)$user['id']) {
            notify_user($t['author_id'], 'reply_thread', $user['username'], $t['title'], 'thread/' . $id);
        }
        foreach (find_mentions($content, $user['id']) as $mu) {
            // Автор темы при ответе уже получил reply-нотиф — не дублируем mention.
            $isAuthor = (int)$mu['id'] === (int)$t['author_id'];
            if ($isAuthor && (int)$t['author_id'] !== (int)$user['id']) continue;
            notify_user($mu['id'], 'mention', $user['username'], $t['title'], 'thread/' . $id);
        }
        json_out(['post' => ['id' => (int)$pid, 'content' => $content, 'createdAt' => $now, 'author' => public_user($user)],
                  'mentionRoles' => mention_roles_map([$content])]);
        break;

    case 'thread_pin':
        // Moderation action — owner / admin / moderator.
        if (!is_mod($user)) json_out(['error' => 'Forbidden'], 403);
        $id = (int)param('id'); $t = db_row('SELECT * FROM threads WHERE id=?', [$id]);
        if (!$t) json_out(['error' => 'Not found'], 404);
        db()->prepare('UPDATE threads SET pinned=1-pinned WHERE id=?')->execute([$id]);
        json_out(['pinned' => (int)db_row('SELECT pinned FROM threads WHERE id=?', [$id])['pinned']]);
        break;

    case 'thread_lock':
        // Moderation action — owner / admin / moderator.
        if (!is_mod($user)) json_out(['error' => 'Forbidden'], 403);
        $id = (int)param('id'); $t = db_row('SELECT * FROM threads WHERE id=?', [$id]);
        if (!$t) json_out(['error' => 'Not found'], 404);
        db()->prepare('UPDATE threads SET locked=1-locked WHERE id=?')->execute([$id]);
        json_out(['locked' => (int)db_row('SELECT locked FROM threads WHERE id=?', [$id])['locked']]);
        break;

    case 'thread_delete':
        // Moderation action — owner / admin / moderator.
        if (!is_mod($user)) json_out(['error' => 'Forbidden'], 403);
        $id = (int)param('id');
        db()->prepare('DELETE FROM posts WHERE thread_id=?')->execute([$id]);
        db()->prepare('DELETE FROM threads WHERE id=?')->execute([$id]);
        json_out(['ok' => true]);
        break;

    case 'user_ban':
        if (!is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $name = param('username'); $u = db_row('SELECT * FROM users WHERE username=?', [$name]);
        if (!$u) json_out(['error' => 'User not found'], 404);
        if ($u['role'] === 'owner') json_out(['error' => 'Cannot ban owner'], 403);
        $newBanned = 1 - (int)$u['banned'];
        // Reason is stored when banning and cleared when unbanning.
        $reason = $newBanned ? utf8_limit(trim((string)param('reason')), 500) : '';
        try {
            db()->prepare('UPDATE users SET banned=?, ban_reason=? WHERE id=?')
                ->execute([$newBanned, $reason, $u['id']]);
        } catch (Throwable $e) {
            // Fallback for databases that don't yet have the ban_reason column
            // (run db_migration_ban_reason.sql to enable reasons): ban anyway.
            db()->prepare('UPDATE users SET banned=? WHERE id=?')->execute([$newBanned, $u['id']]);
        }
        json_out(['banned' => $newBanned]);
        break;

    /* ---------------- Profile / search / stats ---------------- */
    case 'profile':
        $name = param('user'); $u = db_row('SELECT * FROM users WHERE username=?', [$name]);
        if (!$u) json_out(['error' => 'User not found'], 404);
        $threads = db_all('SELECT * FROM threads WHERE author_id=? ORDER BY updated_at DESC LIMIT 20', [$u['id']]);
        // Privacy fix: the profile payload is public (the page shows the bio),
        // but the account EMAIL is private. Previously it was returned to ANY
        // visitor, logged in or not — expose it only to the account owner and
        // staff now. (HWID was removed from the site entirely.)
        $pub = public_user($u, true);
        $canSeePrivate = $user && (is_staff($user) || (int)$user['id'] === (int)$u['id']);
        if (!$canSeePrivate) { unset($pub['email']); }
        $postCount = (int)db_val('SELECT COUNT(*) FROM posts WHERE author_id=?', [$u['id']]);
        json_out(['user' => $pub, 'threads' => array_map('public_thread', $threads), 'postCount' => $postCount]);
        break;

    case 'profile_update':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $set = []; $params = [];
        $uname = param('username');
        if ($uname !== null) {
            // Username change is a staff-only privilege (owner/admin).
            // Same charset rule as at registration; must stay unique.
            if (!is_staff($user)) json_out(['error' => 'Only owner/admin can change the username'], 403);
            $uname = trim((string)$uname);
            if (!preg_match('/^[a-zA-Z0-9_.\-]{3,20}$/', $uname)) json_out(['error' => 'Username must be 3-20 chars: letters, digits, dot, underscore, dash'], 400);
            if (strcasecmp($uname, (string)$user['username']) !== 0 && db_row('SELECT id FROM users WHERE username=?', [$uname])) {
                json_out(['error' => 'This username is already taken'], 409);
            }
            $set[] = 'username=?'; $params[] = $uname;
        }
        $color = param('color');
        if ($color !== null) {
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) json_out(['error' => 'Invalid color'], 400);
            $set[] = 'color=?'; $params[] = $color;
        }
        $status = param('status');
        if ($status !== null) { $set[] = 'status=?'; $params[] = utf8_limit(trim(str_replace("\0", '', (string)$status)), 80); }
        $bg = param('profile_bg');
        if ($bg !== null) {
            $bgTrim = trim((string)$bg);
            if ($bgTrim === '') { $bg = ''; } // allow clearing
            else { $bg = sec_safe_url($bgTrim, 255); if ($bg === '') json_out(['error' => 'Background must be a clean http(s) URL (no quotes, brackets or spaces)'], 400); }
            $set[] = 'profile_bg=?'; $params[] = $bg;
        }
        foreach (['link_youtube' => 'linkYoutube', 'link_discord' => 'linkDiscord', 'link_telegram' => 'linkTelegram'] as $col => $key) {
            $v = param($key);
            if ($v !== null) {
                $vTrim = trim((string)$v);
                if ($vTrim === '') { $v = ''; } // allow clearing
                else { $v = sec_safe_url($vTrim, 200); if ($v === '') json_out(['error' => 'Link must be a clean http(s) URL (no quotes, brackets or spaces)'], 400); }
                $set[] = $col . '=?'; $params[] = $v;
            }
        }
        $ap = param('avatarPreset');
        if ($ap !== null) {
            // Pick a ready-made avatar: strict whitelist + the file must exist on
            // disk. No upload involved, so nothing user-controlled reaches fs paths.
            $apTrim = trim((string)$ap);
            if (!preg_match('/^preset_[0-9a-z]{1,12}\.(png|jpe?g|webp)$/', $apTrim)) json_out(['error' => 'Invalid preset'], 400);
            if (!is_file(__DIR__ . '/assets/preset-avatars/' . $apTrim)) json_out(['error' => 'Unknown preset'], 404);
            $set[] = 'avatar_url=?'; $params[] = '/assets/preset-avatars/' . $apTrim;
        }
        $ab = param('avatarBorder');
        if ($ab !== null) {
            if (!in_array($ab, ['none','gradient','neon','fire','ocean','gold','purple','emerald','aurora','comet','pulse'], true)) json_out(['error' => 'Invalid border'], 400);
            $set[] = 'avatar_border=?'; $params[] = $ab;
        }
        if ($set) {
            $params[] = $user['id'];
            db()->prepare('UPDATE users SET ' . implode(',', $set) . ' WHERE id=?')->execute($params);
        }
        $u = db_row('SELECT * FROM users WHERE id=?', [$user['id']]);
        json_out(['user' => public_user($u, true)]);
        break;

    case 'attachment_upload':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        // $_FILES пуст, но тело запроса было — почти наверняка сервер отрезал
        // его по post_max_size: говорим об этом внятно вместо «No file».
        if (empty($_FILES['file'])) {
            if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
                json_out(['error' => 'File is too large for this server (limit ' . (ini_get('post_max_size') ?: '?') . '). Try a smaller image.'], 400);
            }
            json_out(['error' => 'No file'], 400);
        }
        $f = $_FILES['file'];
        if ($f['error'] !== UPLOAD_ERR_OK) {
            $upErrs = [
                UPLOAD_ERR_INI_SIZE  => 'File exceeds the server upload limit (' . (ini_get('upload_max_filesize') ?: '?') . '). Try a smaller image.',
                UPLOAD_ERR_FORM_SIZE => 'File is too large.',
                UPLOAD_ERR_PARTIAL   => 'Upload was interrupted — please try again.',
                UPLOAD_ERR_NO_TMP_DIR => 'Server temp folder is missing — contact the administrator.',
                UPLOAD_ERR_CANT_WRITE => 'Server could not save the file (disk) — contact the administrator.',
            ];
            json_out(['error' => isset($upErrs[$f['error']]) ? $upErrs[$f['error']] : 'Upload error (code ' . (int)$f['error'] . ')'], 400);
        }
        if ($f['size'] > 15 * 1024 * 1024) json_out(['error' => 'File too large (max 15 MB)'], 400);
        $allowedImg = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
        $mime = $f['type'];
        $ext = $allowedImg[$mime] ?? null;
        if ($ext === null) {
            $e = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
            $gen = ['jpg','jpeg','png','gif','webp','mp4','webm','ogv','mp3','wav','ogg','txt','pdf','zip','rar','7z'];
            if (!in_array($e, $gen, true)) json_out(['error' => 'Unsupported file type'], 400);
            $mime = 'application/octet-stream'; $ext = $e;
        }
        // Defence in depth: never accept a script-like extension.
        if (sec_dangerous_ext($ext)) json_out(['error' => 'Unsupported file type'], 400);
        // For image extensions, confirm the bytes are a real image of that type.
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true) && !sec_image_magic($f['tmp_name'], $ext)) {
            json_out(['error' => 'Image file is invalid or corrupt'], 400);
        }
        $dir = __DIR__ . '/assets/uploads';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $name = $user['id'] . '_' . bin2hex(random_bytes(10)) . '.' . $ext;
        if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) json_out(['error' => 'Could not save file'], 500);
        json_out(['url' => '/assets/uploads/' . $name, 'name' => $f['name'], 'mime' => $mime, 'size' => (int)$f['size']]);
        break;

    case 'search':
        $q = mb_strtolower(trim((string)(param('q') ?? '')), 'UTF-8');
        if ($q === '') json_out(['threads' => []]);
        $like = '%' . $q . '%';
        $list = db_all('SELECT * FROM threads WHERE LOWER(title) LIKE ? OR id IN (SELECT thread_id FROM posts WHERE LOWER(content) LIKE ?) ORDER BY updated_at DESC LIMIT 30', [$like, $like]);
        json_out(['threads' => array_map('public_thread', $list)]);
        break;

    case 'stats':
        json_out([
            'users'      => (int)db_val('SELECT COUNT(*) FROM users'),
            'threads'    => (int)db_val('SELECT COUNT(*) FROM threads'),
            'posts'      => (int)db_val('SELECT COUNT(*) FROM posts'),
            'categories' => (int)db_val('SELECT COUNT(*) FROM categories'),
            // Live "online" count: users active in the last 60s (presence table).
            'online'     => (int)db_val('SELECT COUNT(*) FROM online WHERE last_seen > ?', [time() - 60]),
        ]);
        break;

    /* ---------------- Chat (AJAX polling) ---------------- */
    case 'chat_history':
        $msgs = array_reverse(db_all('SELECT c.*, u.avatar_url, u.color, u.avatar_border FROM chat c LEFT JOIN users u ON u.id=c.user_id ORDER BY id DESC LIMIT 60'));
        json_out(['messages' => array_map('chat_msg', $msgs),
                  'mentionRoles' => mention_roles_map(array_column($msgs, 'content'))]);
        break;

    case 'chat_poll':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $since = (int)param('since');
        update_presence($user);
        $msgs = db_all('SELECT c.*, u.avatar_url, u.color, u.avatar_border FROM chat c LEFT JOIN users u ON u.id=c.user_id WHERE c.id > ? ORDER BY id ASC', [$since]);
        json_out(['messages' => array_map('chat_msg', $msgs), 'presence' => presence_list($user), 'typing' => typing_list($user), 'notif' => notif_unread_count($user['id']),
                  'mentionRoles' => mention_roles_map(array_column($msgs, 'content'))]);
        break;

    case 'chat_send':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $content = trim((string)param('content'));
        $content = utf8_limit($content, 500);
        if ($content === '') json_out(['error' => 'Empty message'], 400);
        // Anti-spam: reject floods / duplicates / rapid-fire before touching the DB.
        $spam = chat_antispam_check($user, $content);
        if ($spam) json_out(['error' => $spam['error']], $spam['code']);
        $now = time();
        db()->prepare('INSERT INTO chat (user_id,username,role,content,created_at) VALUES (?,?,?,?,?)')
            ->execute([$user['id'], $user['username'], $user['role'], $content, $now]);
        $mid = $pdo->lastInsertId();
        // Include u.avatar_border so the message you just sent renders with your
        // current animated border (matches chat_history / chat_poll).
        $m = db_row('SELECT c.*, u.avatar_url, u.color, u.avatar_border FROM chat c LEFT JOIN users u ON u.id=c.user_id WHERE c.id=?', [$mid]);
        chat_antispam_record($user, $content);
        update_presence($user);
        // @упоминания в чате → уведомление (схлопывается в одно непрочитанное).
        foreach (find_mentions($content, $user['id']) as $mu) {
            notify_user($mu['id'], 'mention_chat', $user['username'], 'Live chat', 'chat');
        }
        json_out(['message' => chat_msg($m), 'mentionRoles' => mention_roles_map([$content])]);
        break;

    case 'chat_typing':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        db()->prepare('INSERT INTO typing (user_id,username,updated_at) VALUES (?,?,?) ON DUPLICATE KEY UPDATE username=VALUES(username),updated_at=VALUES(updated_at)')
            ->execute([$user['id'], $user['username'], time()]);
        json_out(['ok' => true]);
        break;

    /* ---------------- Avatars ---------------- */
    case 'avatar_upload':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        if (empty($_FILES['avatar'])) json_out(['error' => 'No file'], 400);
        $f = $_FILES['avatar'];
        if ($f['error'] !== UPLOAD_ERR_OK) json_out(['error' => 'Upload error'], 400);
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
        $mime = $f['type'];
        if (!isset($allowed[$mime])) json_out(['error' => 'Only JPG/PNG/GIF/WEBP images'], 400);
        if ($f['size'] > 2 * 1024 * 1024) json_out(['error' => 'Image too large (max 2 MB)'], 400);
        // Real content check: the bytes must match a genuine image of this type
        // (the client-supplied MIME/type is spoofable, so we don't trust it alone).
        if (!sec_image_magic($f['tmp_name'], $allowed[$mime])) json_out(['error' => 'Image file is invalid or corrupt'], 400);
        $dir = __DIR__ . '/assets/avatars';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $name = $user['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
        if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) json_out(['error' => 'Could not save file'], 500);
        db()->prepare('UPDATE users SET avatar_url=? WHERE id=?')->execute(['/assets/avatars/' . $name, $user['id']]);
        json_out(['avatar' => '/assets/avatars/' . $name]);
        break;

    case 'avatar_remove':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        db()->prepare('UPDATE users SET avatar_url="" WHERE id=?')->execute([$user['id']]);
        json_out(['ok' => true]);
        break;

    case 'profile_bg_upload':
        // Profile background: user picks an image from their PC (no URL pasting).
        // Same hardening as avatars: real-image bytes check, random name, hardened
        // uploads dir. Applied instantly (writes profile_bg), UI shows a live preview.
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        if (empty($_FILES['file'])) json_out(['error' => 'No file'], 400);
        $f = $_FILES['file'];
        if ($f['error'] !== UPLOAD_ERR_OK) json_out(['error' => 'Upload error'], 400);
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
        $mime = $f['type'];
        if (!isset($allowed[$mime])) json_out(['error' => 'Only JPG/PNG/GIF/WEBP images'], 400);
        if ($f['size'] > 8 * 1024 * 1024) json_out(['error' => 'Image too large (max 8 MB)'], 400);
        if (!sec_image_magic($f['tmp_name'], $allowed[$mime])) json_out(['error' => 'Image file is invalid or corrupt'], 400);
        $dir = __DIR__ . '/assets/uploads';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        // Remove the previous background file — only if it is one of OUR bg_ uploads
        // (regex-pinned, basename, never a user-controlled path).
        $old = db_val('SELECT profile_bg FROM users WHERE id=?', [$user['id']]);
        if ($old && preg_match('#^/assets/uploads/bg_[0-9]+_[a-f0-9]{16}\.(jpg|jpeg|png|gif|webp)$#i', $old)) {
            @unlink($dir . '/' . basename($old));
        }
        $name = 'bg_' . $user['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
        if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) json_out(['error' => 'Could not save file'], 500);
        db()->prepare('UPDATE users SET profile_bg=? WHERE id=?')->execute(['/assets/uploads/' . $name, $user['id']]);
        $u = db_row('SELECT * FROM users WHERE id=?', [$user['id']]);
        json_out(['url' => '/assets/uploads/' . $name, 'user' => public_user($u, true)]);
        break;

    /* ---------------- Forgot password (email-gated self-service) ---------------- */
    case 'forgot_request':
        // Accept email OR username. Always return the same generic response
        // (anti-enumeration) and only send an email when a matching account
        // with a valid email actually exists. Throttled per IP (file-based,
        // works even without cookies) to stop mail flooding.
        $acct = trim((string)param('account'));
        $ipErr = sec_ip_throttle('forgot', 5, 600);
        if ($ipErr) json_out(['error' => $ipErr], 429);
        $generic = ['ok' => true, 'ttl_label' => reset_ttl_label(), 'message' => 'If that email or username matches an account, a reset email has been sent. Check your inbox (and spam folder).'];
        if ($acct === '') json_out($generic);
        $u = db_row('SELECT * FROM users WHERE username=? OR email=?', [$acct, $acct]);
        if (!$u || empty($u['email']) || !filter_var($u['email'], FILTER_VALIDATE_EMAIL)) json_out($generic);
        $token = reset_save($u['id'], defined('RESET_TTL') ? RESET_TTL : 3600);
        $base = rtrim(defined('SITE_URL') ? SITE_URL : '', '/');
        $resetUrl = $base . '/#/reset?token=' . $token;
        $mail = build_reset_email($u['username'], $resetUrl);
        reset_gc();
        sec_send_mail($u['email'], 'Password reset for +W.TECH FORUM', $mail['html'], $mail['text']);
        json_out($generic);
        break;

    case 'forgot_check':
        // Lets the reset page know whether a token link is still valid,
        // without revealing which account it belongs to.
        $token = (string)param('token');
        json_out(['valid' => reset_load($token) ? true : false]);
        break;

    case 'forgot_reset':
        $token = (string)param('token');
        $pw = (string)param('password');
        $ipErr = sec_ip_throttle('reset', 10, 600);
        if ($ipErr) json_out(['error' => $ipErr], 429);
        if (strlen($pw) < 6) json_out(['error' => 'Password must be at least 6 characters'], 400);
        $j = reset_load($token);
        if (!$j) json_out(['error' => 'This reset link is invalid or has expired. Please request a new one.'], 400);
        $u = db_row('SELECT * FROM users WHERE id=?', [(int)$j['user_id']]);
        if (!$u) { reset_consume($token); json_out(['error' => 'Invalid reset link.'], 400); }
        // Also kill any stored "Remember me" token: after a password reset a
        // stolen quick-login cookie must no longer open the account.
        db()->prepare('UPDATE users SET password_hash=?, remember_token="" WHERE id=?')->execute([password_hash($pw, PASSWORD_BCRYPT), $u['id']]);
        reset_consume($token); // one-time use
        json_out(['ok' => true]);
        break;

    case 'admin_users':
        if (!is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $q = trim((string)(param('q') ?? ''));
        $sql = 'SELECT u.*, (SELECT COUNT(*) FROM posts p WHERE p.author_id=u.id) AS post_count FROM users u';
        $params = [];
        if ($q !== '') { $sql .= ' WHERE u.username LIKE ?'; $params[] = '%' . $q . '%'; }
        $sql .= ' ORDER BY (u.role IN ("owner","admin")) DESC, u.username ASC LIMIT 200';
        $rows = db_all($sql, $params);
        $out = array_map(function ($u) {
            return [
                'id'        => (int)$u['id'],
                'username'  => $u['username'],
                'role'      => $u['role'],
                'color'     => $u['color'],
                'avatar'    => !empty($u['avatar_url']) ? $u['avatar_url'] : null,
                'banned'    => (int)$u['banned'],
                'joined_at' => (int)$u['joined_at'],
                'postCount' => (int)$u['post_count'],
            ];
        }, $rows);
        json_out(['users' => $out]);
        break;

    /* ---------------- Direct messages (DM) ---------------- */
    case 'dm_conversations':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $rows = db_all(
            'SELECT c.id, c.user1_id, c.user2_id,
                    (SELECT content FROM pm WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) AS last_content,
                    (SELECT created_at FROM pm WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) AS last_at,
                    (SELECT COUNT(*) FROM pm WHERE conversation_id=c.id AND sender_id<>? AND read_at IS NULL) AS unread
             FROM conversations c
             WHERE c.user1_id=? OR c.user2_id=?
             ORDER BY last_at DESC',
            [$user['id'], $user['id'], $user['id']]
        );
        $out = array_map(function ($r) use ($user) {
            $otherId = ($r['user1_id'] == $user['id']) ? $r['user2_id'] : $r['user1_id'];
            $other = db_row('SELECT * FROM users WHERE id=?', [$otherId]);
            return [
                'id'     => (int)$r['id'],
                'other'  => $other ? public_user($other) : null,
                'last'   => $r['last_content'] !== null ? ['content' => $r['last_content'], 'createdAt' => (int)$r['last_at']] : null,
                'unread' => (int)$r['unread'],
            ];
        }, $rows);
        json_out(['conversations' => $out]);
        break;

    case 'dm_messages':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $name = param('with');
        $other = db_row('SELECT * FROM users WHERE username=?', [$name]);
        if (!$other) json_out(['error' => 'User not found'], 404);
        if ($other['id'] === $user['id']) json_out(['error' => 'Cannot message yourself'], 400);
        $conv = get_or_create_conversation($user['id'], $other['id']);
        db()->prepare('UPDATE pm SET read_at=? WHERE conversation_id=? AND sender_id<>? AND read_at IS NULL')
            ->execute([time(), $conv['id'], $user['id']]);
        $msgs = db_all('SELECT * FROM pm WHERE conversation_id=? ORDER BY id ASC', [$conv['id']]);
        $out = array_map(function ($m) use ($user) {
            return [
                'id'        => (int)$m['id'],
                'content'   => $m['content'],
                'createdAt' => (int)$m['created_at'],
                'mine'      => (int)$m['sender_id'] === (int)$user['id'],
                'senderId'  => (int)$m['sender_id'],
            ];
        }, $msgs);
        json_out(['conversationId' => (int)$conv['id'], 'other' => public_user($other), 'messages' => $out,
                  'mentionRoles' => mention_roles_map(array_column($msgs, 'content'))]);
        break;

    case 'dm_send':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $name = trim((string)param('to'));
        $content = utf8_limit(trim(str_replace("\0", '', (string)param('content'))), 2000);
        if ($content === '') json_out(['error' => 'Empty message'], 400);
        $other = db_row('SELECT * FROM users WHERE username=?', [$name]);
        if (!$other) json_out(['error' => 'User not found'], 404);
        if ($other['id'] === $user['id']) json_out(['error' => 'Cannot message yourself'], 400);
        if ($other['banned']) json_out(['error' => 'This user is banned'], 403);
        // Flood guard (security.php 8b) — stops scripted DM spam.
        $flood = sec_flood_gate($user, 'dm');
        if ($flood) json_out(['error' => $flood['error']], $flood['code']);
        $conv = get_or_create_conversation($user['id'], $other['id']);
        $now = time();
        db()->prepare('INSERT INTO pm (conversation_id,sender_id,content,created_at) VALUES (?,?,?,?)')
            ->execute([$conv['id'], $user['id'], $content, $now]);
        $mid = $pdo->lastInsertId();
        db()->prepare('UPDATE conversations SET updated_at=? WHERE id=?')->execute([$now, $conv['id']]);
        notify_user($other['id'], 'dm', $user['username'], utf8_limit($content, 60), 'dm/' . $user['username']);
        $m = db_row('SELECT * FROM pm WHERE id=?', [$mid]);
        json_out(['message' => [
            'id' => (int)$m['id'], 'content' => $m['content'], 'createdAt' => (int)$m['created_at'],
            'mine' => true, 'senderId' => (int)$user['id'],
        ], 'conversationId' => (int)$conv['id'], 'mentionRoles' => mention_roles_map([$content])]);
        break;

    case 'dm_unread':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $n = (int)db_val(
            'SELECT COUNT(*) FROM pm WHERE conversation_id IN (SELECT id FROM conversations WHERE user1_id=? OR user2_id=?) AND sender_id<>? AND read_at IS NULL',
            [$user['id'], $user['id'], $user['id']]
        );
        json_out(['unread' => $n]);
        break;

    /* ---------------- Notification center ---------------- */
    case 'notif_list':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        // Inbox-only: cleared notifications were deleted (see notif_read), and
        // anything still unread=1 here is what the bell badge counts.
        $rows = db_all('SELECT * FROM notifications WHERE user_id=? AND unread=1 ORDER BY id DESC LIMIT 30', [$user['id']]);
        json_out(['notifications' => array_map('public_notif', $rows), 'unread' => notif_unread_count($user['id'])]);
        break;

    case 'notif_unread':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        json_out(['unread' => notif_unread_count($user['id'])]);
        break;

    case 'notif_read':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $nid = (int)param('id');
        // "Read" notifications are deleted outright instead of being kept with
        // unread=0: the bell panel is an inbox of what needs attention, so a
        // cleared notification must never reappear there (and the table stays
        // small on shared hosting).
        if ($nid > 0) db()->prepare('DELETE FROM notifications WHERE id=? AND user_id=?')->execute([$nid, $user['id']]);
        else db()->prepare('DELETE FROM notifications WHERE user_id=?')->execute([$user['id']]);
        json_out(['ok' => true, 'unread' => notif_unread_count($user['id'])]);
        break;

    case 'admin_set_role':
        if (!is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $name = param('username');
        $role = param('role');
        // Staff can appoint members, customers, support agents, moderators and
        // admins (never the owner).
        if (!in_array($role, ['member', 'customer', 'support', 'moderator', 'admin'], true)) json_out(['error' => 'Invalid role'], 400);
        $u = db_row('SELECT * FROM users WHERE username=?', [$name]);
        if (!$u) json_out(['error' => 'User not found'], 404);
        if ($u['role'] === 'owner') json_out(['error' => 'Cannot change the owner'], 403);
        db()->prepare('UPDATE users SET role=? WHERE id=?')->execute([$role, $u['id']]);
        json_out(['role' => $role]);
        break;

    /* ---------------- Support tickets ---------------- */
    case 'ticket_list':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        // Ticket desk level (owner/admin/moderator/support) sees ALL tickets.
        $staff = is_ticket_staff($user);
        if ($staff) {
            $rows = db_all('SELECT t.*, u.username, u.color, u.role, (SELECT COUNT(*) FROM ticket_replies r WHERE r.ticket_id=t.id) AS replies FROM tickets t LEFT JOIN users u ON u.id=t.user_id ORDER BY t.updated_at DESC LIMIT 300');
        } else {
            $rows = db_all('SELECT t.*, (SELECT COUNT(*) FROM ticket_replies r WHERE r.ticket_id=t.id) AS replies FROM tickets t WHERE t.user_id=? ORDER BY t.updated_at DESC LIMIT 300', [$user['id']]);
        }
        $out = array_map(function ($t) {
            return [
                'id' => (int)$t['id'], 'subject' => $t['subject'], 'category' => $t['category'],
                'status' => $t['status'], 'priority' => $t['priority'] ?? 'normal',
                'createdAt' => (int)$t['created_at'], 'updatedAt' => (int)$t['updated_at'],
                'replies' => (int)$t['replies'],
                'author' => isset($t['username']) ? ['username' => $t['username'], 'color' => $t['color'] ?? '#444', 'role' => $t['role'] ?? 'member'] : null,
            ];
        }, $rows);
        json_out(['tickets' => $out, 'staff' => $staff ? true : false]);
        break;

    case 'ticket_view':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $id = (int)param('id');
        $t = db_row('SELECT t.*, u.username, u.color, u.role FROM tickets t LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?', [$id]);
        if (!$t) json_out(['error' => 'Ticket not found'], 404);
        // Ticket desk level (owner/admin/moderator/support) may open anyone's ticket.
        $staff = is_ticket_staff($user);
        if (!$staff && (int)$t['user_id'] !== (int)$user['id']) json_out(['error' => 'Forbidden'], 403);
        $reps = db_all('SELECT r.*, u.username, u.color, u.role FROM ticket_replies r LEFT JOIN users u ON u.id=r.user_id WHERE r.ticket_id=? ORDER BY r.created_at ASC', [$id]);
        $replies = array_map(function ($r) {
            return [
                'id' => (int)$r['id'], 'content' => $r['content'], 'createdAt' => (int)$r['created_at'],
                'author' => ['username' => $r['username'], 'color' => $r['color'] ?? '#444', 'role' => $r['role'] ?? 'member'],
                'staff' => in_array($r['role'] ?? '', ['owner', 'admin', 'moderator', 'support'], true),
            ];
        }, $reps);
        json_out([
            'ticket' => [
                'id' => (int)$t['id'], 'subject' => $t['subject'], 'category' => $t['category'],
                'status' => $t['status'], 'priority' => $t['priority'] ?? 'normal',
                'createdAt' => (int)$t['created_at'], 'updatedAt' => (int)$t['updated_at'],
                'author' => ['username' => $t['username'], 'color' => $t['color'] ?? '#444', 'role' => $t['role'] ?? 'member'],
            ],
            'replies' => $replies, 'staff' => $staff ? true : false,
        ]);
        break;

    case 'ticket_create':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        if (!empty($user['banned'])) json_out(['error' => 'You cannot create tickets while banned'], 403);
        $subject = utf8_limit(trim(str_replace("\0", '', (string)param('subject'))), 160);
        $content = utf8_limit(trim(str_replace("\0", '', (string)param('content'))), 5000);
        $category = param('category');
        if (!in_array($category, ['general', 'bug', 'billing', 'account', 'other'], true)) $category = 'general';
        if ($subject === '') json_out(['error' => 'Subject is required'], 400);
        if ($content === '') json_out(['error' => 'Message is required'], 400);
        // Flood guard (security.php 8b) — stops scripted ticket spam.
        $flood = sec_flood_gate($user, 'ticket');
        if ($flood) json_out(['error' => $flood['error']], $flood['code']);
        $now = time();
        db()->prepare('INSERT INTO tickets (user_id,subject,category,status,priority,created_at,updated_at) VALUES (?,?,?,?,?,?,?)')
            ->execute([$user['id'], $subject, $category, 'open', 'normal', $now, $now]);
        $tid = (int)db()->lastInsertId();
        db()->prepare('INSERT INTO ticket_replies (ticket_id,user_id,content,created_at) VALUES (?,?,?,?)')
            ->execute([$tid, $user['id'], $content, $now]);
        // Уведомляем весь тикет-деск о новом тикете.
        foreach (ticket_staff_ids($user['id']) as $sid) {
            notify_user($sid, 'ticket_new', $user['username'], $subject, 'ticket/' . $tid);
        }
        json_out(['id' => $tid]);
        break;

    case 'ticket_reply':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $id = (int)param('id');
        $content = utf8_limit(trim(str_replace("\0", '', (string)param('content'))), 5000);
        if ($content === '') json_out(['error' => 'Reply is empty'], 400);
        $t = db_row('SELECT * FROM tickets WHERE id=?', [$id]);
        if (!$t) json_out(['error' => 'Ticket not found'], 404);
        // Ticket desk (owner/admin/moderator/support) may reply to any ticket,
        // including closed ones; the author may reply while it is open.
        $staff = is_ticket_staff($user);
        if (!$staff && (int)$t['user_id'] !== (int)$user['id']) json_out(['error' => 'Forbidden'], 403);
        if ($t['status'] === 'closed' && !$staff) json_out(['error' => 'This ticket is closed'], 403);
        $now = time();
        db()->prepare('INSERT INTO ticket_replies (ticket_id,user_id,content,created_at) VALUES (?,?,?,?)')
            ->execute([$id, $user['id'], $content, $now]);
        $newStatus = $staff ? 'answered' : 'open';
        db()->prepare('UPDATE tickets SET status=?, updated_at=? WHERE id=?')->execute([$newStatus, $now, $id]);
        // Уведомления: ответ саппорта → автору тикета; ответ юзера → тикет-деску.
        if ($staff && (int)$t['user_id'] !== (int)$user['id']) {
            notify_user($t['user_id'], 'ticket_answer', $user['username'], $t['subject'], 'ticket/' . $id);
        } elseif (!$staff) {
            foreach (ticket_staff_ids($user['id']) as $sid) {
                notify_user($sid, 'ticket_reply', $user['username'], $t['subject'], 'ticket/' . $id);
            }
        }
        json_out(['ok' => true, 'status' => $newStatus]);
        break;

    case 'ticket_status':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        $id = (int)param('id');
        $status = param('status');
        if (!in_array($status, ['open', 'answered', 'closed'], true)) json_out(['error' => 'Invalid status'], 400);
        $t = db_row('SELECT * FROM tickets WHERE id=?', [$id]);
        if (!$t) json_out(['error' => 'Ticket not found'], 404);
        // Only the ticket desk (owner / admin / moderator / support) may change
        // a ticket's status. Regular users — including the ticket's author —
        // cannot close or reopen tickets: they create and reply while it's open.
        if (!is_ticket_staff($user)) json_out(['error' => 'Only staff can change ticket status'], 403);
        db()->prepare('UPDATE tickets SET status=?, updated_at=? WHERE id=?')->execute([$status, time(), $id]);
        if ((int)$t['user_id'] !== (int)$user['id']) {
            notify_user($t['user_id'], 'ticket_status', $user['username'], utf8_limit($t['subject'] . ' — ' . $status, 190), 'ticket/' . $id);
        }
        json_out(['ok' => true, 'status' => $status]);
        break;

    case 'ticket_delete':
        // Ticket desk action — owner / admin / moderator / support.
        if (!is_ticket_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $id = (int)param('id');
        if (!db_row('SELECT id FROM tickets WHERE id=?', [$id])) json_out(['error' => 'Ticket not found'], 404);
        db()->prepare('DELETE FROM ticket_replies WHERE ticket_id=?')->execute([$id]);
        db()->prepare('DELETE FROM tickets WHERE id=?')->execute([$id]);
        json_out(['ok' => true]);
        break;

    /* ---------------- Loader download (customers only) ----------------
       The .lua is blocked from direct web access by assets/lua/.htaccess
       ("Require all denied"), so THIS endpoint is the only way to fetch it.
       Runs over GET with the session cookie (normal browser download). */
    case 'download_loader':
        if (!$user) json_out(['error' => 'Not authenticated'], 401);
        if (!can_download($user)) json_out(['error' => 'The loader is available to customers only.'], 403);
        $file = loader_file_path();
        if (!$file) json_out(['error' => 'File is temporarily unavailable.'], 404);
        $src = (string)file_get_contents($file);
        // Obfuscate ON THE FLY: every customer receives a uniquely-renamed,
        // string-encrypted build with a hidden watermark built from their
        // account id (leak tracing). The build → account mapping is logged
        // to data/lua_builds.log (data/ is denied from the web). If the
        // obfuscator throws on anything, the ORIGINAL file is served so the
        // download never breaks.
        $build = '';
        $payload = $src;
        try {
            require_once __DIR__ . '/lua_obfuscator.php';
            $build = 'WT-' . strtoupper(bin2hex(random_bytes(4))) . '-U' . (int)$user['id'];
            $payload = lua_obfuscate($src, $build);
            @file_put_contents(
                __DIR__ . '/data/lua_builds.log',
                json_encode([
                    'at'    => time(),
                    'build' => $build,
                    'uid'   => (int)$user['id'],
                    'user'  => $user['username'],
                    'ip'    => $_SERVER['REMOTE_ADDR'] ?? '',
                ], JSON_UNESCAPED_UNICODE) . "\n",
                FILE_APPEND | LOCK_EX
            );
        } catch (Throwable $e) {
            @error_log('[wtech obf] ' . $e->getMessage());
            $payload = $src;
            $build = '';
        }
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="loader.lua"');
        // Every download is a NEW unique build — never let caches serve an old one.
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('Content-Length: ' . strlen($payload));
        echo $payload;
        exit;

    /* ---------------- Admin: loader file management ----------------
       Replace the .lua served by download_loader straight from the admin
       panel — no FTP/SSH needed. The new file is syntax-checked with the
       SAME full Lua 5.1 parser the on-the-fly obfuscator uses, so a
       corrupt or non-Lua upload can never brick every customer's
       download. The replaced build is backed up to assets/lua/backup/
       (web-denied) first. */
    case 'loader_info':
        if (!$user || !is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        $file = loader_file_path();
        if (!$file) json_out(['error' => 'Loader file missing'], 404);
        $backups = glob(__DIR__ . '/assets/lua/backup/loader_*.lua') ?: [];
        json_out([
            'name'         => basename($file),
            'size'         => filesize($file),
            'mtime'        => filemtime($file),
            'sha1'         => sha1_file($file),
            'backups'      => count($backups),
            'latestBackup' => $backups ? (int)max(array_map('filemtime', $backups)) : null,
        ]);
        break;

    case 'loader_replace':
        if (!$user || !is_staff($user)) json_out(['error' => 'Forbidden'], 403);
        if (empty($_FILES['loader'])) json_out(['error' => 'No file'], 400);
        $f = $_FILES['loader'];
        if ($f['error'] !== UPLOAD_ERR_OK) json_out(['error' => 'Upload error (code ' . (int)$f['error'] . ')'], 400);
        if ($f['size'] <= 0) json_out(['error' => 'File is empty'], 400);
        if ($f['size'] > 1024 * 1024) json_out(['error' => 'File too large (max 1 MB)'], 400);
        // Never trust the client-supplied name/MIME: read the bytes ourselves.
        $src = (string)@file_get_contents($f['tmp_name']);
        if ($src === '') json_out(['error' => 'File is empty'], 400);
        // Syntax-check with the same full Lua 5.1 parser as the obfuscator:
        // only a valid, loadable script is allowed to replace the loader.
        require_once __DIR__ . '/lua_obfuscator.php';
        try {
            $chk = new LuaObfParser(lua_tokenize($src));
            $chk->parseChunk();
        } catch (Throwable $e) {
            json_out(['error' => 'Lua syntax check failed: ' . $e->getMessage()], 400);
        }
        $dir  = __DIR__ . '/assets/lua';
        // The uploaded file is ALWAYS stored as loader.lua — however the
        // admin called it on their PC, customers download "loader.lua".
        $file = $dir . '/loader.lua';
        // Back up the current build before replacing it (best-effort).
        $cur  = loader_file_path();
        if ($cur) {
            $bdir = $dir . '/backup';
            if (!is_dir($bdir)) {
                @mkdir($bdir, 0755, true);
                @file_put_contents($bdir . '/.htaccess', "Require all denied\nOptions -Indexes\n");
            }
            @copy($cur, $bdir . '/loader_' . date('Ymd_His') . '.lua');
        }
        // Atomic replace: write a temp file, then rename — a customer must
        // never download a half-written loader.
        $tmp = $dir . '/.upload_' . bin2hex(random_bytes(6)) . '.tmp';
        if (@file_put_contents($tmp, $src, LOCK_EX) === false) json_out(['error' => 'Could not write file (check folder permissions)'], 500);
        if (!@rename($tmp, $file)) { @unlink($tmp); json_out(['error' => 'Could not replace the loader file'], 500); }
        @chmod($file, 0644);
        json_out(['ok' => true, 'size' => strlen($src), 'sha1' => sha1($src)]);
        break;

    default:
        json_out(['error' => 'Unknown action'], 400);
    }
} catch (\Throwable $e) {
    // Never leak internals (SQL, paths, DSN) to the client — log the real cause
    // server-side and return a generic message instead.
    @error_log('[wtech api] ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine());
    json_out(['error' => 'Something went wrong. Please try again.'], 500);
}
