<?php
require_once __DIR__ . '/security.php';
sec_headers();
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: public, max-age=0, must-revalidate');
// Манифест РЕАЛЬНО существующих emoji-файлов бандла (строится с диска при
// каждом запросе app.php): JS берёт локальный SVG только когда файл есть,
// иначе сразу уходит на twemoji CDN — 404 с нашего сервера за emoji не бывает.
$__wtechEmojiFiles = glob(__DIR__ . '/assets/emoji/72x72/*.svg') ?: array();
$__wtechEmojiManifest = array();
foreach ($__wtechEmojiFiles as $__ef) { $__wtechEmojiManifest[basename($__ef)] = true; }
?>
'use strict';

window.__EMOJI_LOCAL = <?php echo json_encode($__wtechEmojiManifest, JSON_UNESCAPED_SLASHES); ?>;

window.state = { user: null, quickUser: null };

// External backend admin panel URL — embedded here as a single source of
// truth so the header button can link to it without scattering the key.
// External backend admin panel URL is NO LONGER stored on the client.
// The topbar "Backend" button now points to /go-backend.php, which checks
// the session + role (owner/admin) server-side and only then 302-redirects
// to the real panel URL. The secret ?key= lives only in go-backend.php and
// never reaches the browser — so it can't be read from app.js / DevTools.

/* =========================================================
   Unified API — works for both PHP/Beget (mode='php')
   and Node.js (mode='node'). Set window.API_MODE in index.
   ========================================================= */
const API = (function () {
  const mode = window.API_MODE === 'node' ? 'node' : 'php';
  async function req(method, url, body) {
    // cache-bust every GET so logged-in state (e.g. /me) is never served stale
    if (method === 'GET' && url.indexOf('_=') === -1) {
      url += (url.indexOf('?') === -1 ? '?' : '&') + '_=' + Date.now();
    }
    const opt = { method, headers: {} };
    // Identify SPA API calls. The server (security.php) requires this header on
    // mutating requests as a CSRF defense — a cross-site attacker cannot set it.
    opt.headers['X-Requested-With'] = 'XMLHttpRequest';
    // CSRF double-submit token: echo back the value the server gave us (via the
    // X-CSRF-Token response header). Same-origin JS can read it; an attacker can't.
    if (window.__csrf) opt.headers['X-CSRF-Token'] = window.__csrf;
    if (body !== undefined) {
      if (body instanceof FormData) {
        // Let the browser set the multipart boundary; do NOT JSON-encode.
        opt.body = body;
      } else {
        opt.headers['Content-Type'] = 'application/json';
        opt.body = JSON.stringify(body);
      }
    }
    const res = await fetch(url, opt);
    // Pick up / refresh the CSRF token the server sends on every response.
    const csrfHdr = res.headers.get('X-CSRF-Token');
    if (csrfHdr) window.__csrf = csrfHdr;
    let data = null; try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      // If the server says this account is banned, lock the UI immediately
      // (even without a page reload) before propagating the error. Use the fresh
      // user record from the response (it carries the ban reason); the client's
      // cached state.user was loaded before the ban and has no reason yet.
      if (res.status === 403 && data && data.banned && typeof showBanScreen === 'function') {
        const bannedUser = (data.user) || (window.state && window.state.user) || {};
        if (data.user && window.state) window.state.user = data.user; // keep cache consistent
        showBanScreen(bannedUser);
      }
      throw new Error((data && data.error) || ('HTTP ' + res.status));
    }
    return data;
  }
  const phpGet = (a, p) => { let u = '/api.php?action=' + a; if (p) for (const k in p) u += '&' + k + '=' + encodeURIComponent(p[k]); return req('GET', u); };
  const phpPost = (a, b) => req('POST', '/api.php?action=' + a, b);
  const nodeGet = (u) => req('GET', u);
  const nodePost = (u, b) => req('POST', u, b);
  const nodeDel = (u) => req('DELETE', u);
  return {
    mode,
    me:          () => mode === 'node' ? nodeGet('/api/auth/me') : phpGet('me'),
    login:       (u, p, remember) => mode === 'node' ? nodePost('/api/auth/login', { username: u, password: p, remember: !!remember }) : phpPost('login', { username: u, password: p, remember: !!remember }),
    register:    (o) => mode === 'node' ? nodePost('/api/auth/register', o) : phpPost('register', o),
    registerVerify: (o) => mode === 'node' ? nodePost('/api/auth/register_verify', o) : phpPost('register_verify', o),
    registerResend: (token) => mode === 'node' ? nodePost('/api/auth/register_resend', { token }) : phpPost('register_resend', { token }),
    logout:      () => mode === 'node' ? nodePost('/api/auth/logout') : phpPost('logout'),
    categories:  () => mode === 'node' ? nodeGet('/api/categories') : phpGet('categories'),
    threads:     (p) => mode === 'node' ? nodeGet('/api/threads?' + new URLSearchParams(p)) : phpGet('threads', p),
    thread:      (id) => mode === 'node' ? nodeGet('/api/threads/' + id) : phpGet('thread', { id }),
    createThread: (o) => mode === 'node' ? nodePost('/api/threads', o) : phpPost('thread_create', o),
    createPost:  (id, c, attachments) => mode === 'node' ? nodePost('/api/threads/' + id + '/posts', { content: c, attachments: attachments || [] }) : phpPost('post_create', { id, content: c, attachments: attachments || [] }),
    profileUpdate:   (o) => mode === 'node' ? nodePost('/api/profile_update', o) : phpPost('profile_update', o),
    attachmentUpload: (fd) => mode === 'node' ? nodePost('/api/attachment_upload', fd) : phpPost('attachment_upload', fd),
    pin:         (id) => mode === 'node' ? nodePost('/api/threads/' + id + '/pin') : phpPost('thread_pin', { id }),
    lock:        (id) => mode === 'node' ? nodePost('/api/threads/' + id + '/lock') : phpPost('thread_lock', { id }),
    delThread:   (id) => mode === 'node' ? nodeDel('/api/threads/' + id) : phpPost('thread_delete', { id }),
    ban:         (username, reason) => mode === 'node' ? nodePost('/api/users/' + encodeURIComponent(username) + '/ban', { reason: reason || '' }) : phpPost('user_ban', { username, reason: reason || '' }),
    profile:     (username) => mode === 'node' ? nodeGet('/api/users/' + encodeURIComponent(username)) : phpGet('profile', { user: username }),
    search:      (q) => mode === 'node' ? nodeGet('/api/search?q=' + encodeURIComponent(q)) : phpGet('search', { q }),
    stats:       () => mode === 'node' ? nodeGet('/api/stats') : phpGet('stats'),
    forgotRequest: (account) => mode === 'node' ? nodePost('/api/forgot', { account }) : phpPost('forgot_request', { account }),
    forgotCheck:   (token) => mode === 'node' ? nodePost('/api/forgot_check', { token }) : phpPost('forgot_check', { token }),
    forgotReset:   (o) => mode === 'node' ? nodePost('/api/forgot_reset', o) : phpPost('forgot_reset', o),
    avatarUpload:  (fd) => mode === 'node' ? nodePost('/api/avatar', fd) : phpPost('avatar_upload', fd),
    profileBgUpload: (fd) => mode === 'node' ? nodePost('/api/profile_bg', fd) : phpPost('profile_bg_upload', fd),
    avatarRemove:  () => mode === 'node' ? nodePost('/api/avatar_remove') : phpPost('avatar_remove'),
    quickLoginInfo: () => mode === 'node' ? nodeGet('/api/quick_login_info') : phpGet('quick_login_info'),
    quickLogin:     () => mode === 'node' ? nodePost('/api/quick_login') : phpPost('quick_login'),
    quickForget:    () => mode === 'node' ? nodePost('/api/quick_forget') : phpPost('quick_forget'),
    chatHistory: () => mode === 'node' ? nodeGet('/api/chat/history') : phpGet('chat_history'),
    chatPoll:    (since) => mode === 'node' ? nodeGet('/api/chat/poll?since=' + since) : phpGet('chat_poll', { since }),
    chatSend:    (c) => mode === 'node' ? nodePost('/api/chat', { content: c }) : phpPost('chat_send', { content: c }),
    chatTyping:  () => mode === 'node' ? nodePost('/api/chat/typing') : phpPost('chat_typing'),
    adminUsers:  (q) => mode === 'node' ? nodeGet('/api/admin/users?q=' + encodeURIComponent(q || '')) : phpGet('admin_users', q ? { q } : {}),
    adminSetRole:  (username, role) => mode === 'node' ? nodePost('/api/admin/set-role', { username, role }) : phpPost('admin_set_role', { username, role }),
    categoryCreate: (o) => mode === 'node' ? nodePost('/api/categories', o) : phpPost('category_create', o),
    categoryDelete: (id) => mode === 'node' ? nodeDel('/api/categories/' + encodeURIComponent(id)) : phpPost('category_delete', { id }),
    loaderInfo:     () => mode === 'node' ? nodeGet('/api/admin/loader-info') : phpGet('loader_info'),
    loaderReplace:  (fd) => mode === 'node' ? nodePost('/api/admin/loader-replace', fd) : phpPost('loader_replace', fd),
    ticketList:   () => mode === 'node' ? nodeGet('/api/tickets') : phpGet('ticket_list'),
    ticketView:   (id) => mode === 'node' ? nodeGet('/api/tickets/' + id) : phpGet('ticket_view', { id }),
    ticketCreate: (o) => mode === 'node' ? nodePost('/api/tickets', o) : phpPost('ticket_create', o),
    ticketReply:  (id, content) => mode === 'node' ? nodePost('/api/tickets/' + id + '/reply', { content }) : phpPost('ticket_reply', { id, content }),
    ticketStatus: (id, status) => mode === 'node' ? nodePost('/api/tickets/' + id + '/status', { status }) : phpPost('ticket_status', { id, status }),
    ticketDelete: (id) => mode === 'node' ? nodeDel('/api/tickets/' + id) : phpPost('ticket_delete', { id }),
    dmConversations: () => mode === 'node' ? nodeGet('/api/dm/conversations') : phpGet('dm_conversations'),
    dmMessages:     (withU) => mode === 'node' ? nodeGet('/api/dm/messages?with=' + encodeURIComponent(withU)) : phpGet('dm_messages', { with: withU }),
    dmSend:         (to, content) => mode === 'node' ? nodePost('/api/dm/send', { to, content }) : phpPost('dm_send', { to, content }),
    dmUnread:       () => mode === 'node' ? nodeGet('/api/dm/unread') : phpGet('dm_unread'),
    notifList:   () => mode === 'node' ? Promise.resolve({ notifications: [], unread: 0 }) : phpGet('notif_list'),
    notifUnread: () => mode === 'node' ? Promise.resolve({ unread: 0 }) : phpGet('notif_unread'),
    notifRead:   (id) => mode === 'node' ? Promise.resolve({ ok: true, unread: 0 }) : phpPost('notif_read', { id: id || 0 }),
  };
})();

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function avatarHTML(u, cls) {
  const user = u || { username: '?' };
  const bc = borderClass(user);
  const borderCls = bc === 'b-none' ? '' : 'av-border ' + bc;
  if (user.avatar) {
    // Uploaded image: show it cleanly, without the initial-letter overlay.
    return `<span class="${cls} ${borderCls}" style="--fillc:url('${esc(user.avatar)}') center/cover"></span>`;
  }
  const color = user.color || '#444';
  const initial = esc((user.username || '?')[0]);
  return `<span class="${cls} ${borderCls}" style="--fillc:${esc(color)}">${initial}</span>`;
}
// Animated avatar-border presets (the key is stored per-user in `avatarBorder`).
const BORDER_KEYS = ['none', 'gradient', 'neon', 'fire', 'ocean', 'gold', 'purple', 'emerald', 'aurora', 'comet', 'pulse'];
// Ready-made avatar choices offered in the profile editor (served from assets,
// selection is written via profileUpdate's avatarPreset param).
const PRESET_AVATARS = Array.from({ length: 12 }, (_, i) => '/assets/preset-avatars/preset_' + String(i + 1).padStart(2, '0') + '.png');
function borderClass(u) {
  const k = (u && u.avatarBorder) || 'none';
  return BORDER_KEYS.includes(k) ? 'b-' + k : 'b-none';
}
// HSL <-> hex for the custom color rails in the profile editor.
function hslToHex(h, s, l) {
  h = ((h % 360) + 360) % 360;
  const a = s * Math.min(l, 1 - l);
  const f = n => { const k = (n + h / 30) % 12; const c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); return Math.round(255 * c).toString(16).padStart(2, '0'); };
  return '#' + f(0) + f(8) + f(4);
}
function hexToHsl(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '') || [0, 'ff3232'];
  const r = parseInt(m[1].slice(0, 2), 16) / 255, g = parseInt(m[1].slice(2, 4), 16) / 255, b = parseInt(m[1].slice(4, 6), 16) / 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  const l = (mx + mn) / 2, s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  let h = 0;
  if (d) { if (mx === r) h = 60 * (((g - b) / d) % 6); else if (mx === g) h = 60 * ((b - r) / d + 2); else h = 60 * ((r - g) / d + 4); }
  return { h: (h + 360) % 360, s: Math.min(1, Math.max(.45, s)), l };
}
// Resolve the color a username/nickname should be shown in: the user's chosen
// nickname color, falling back to the prior role-based default. Used so a
// nickname color change is reflected everywhere the name is rendered.
function nameColor(u) {
  if (u && u.color) return u.color;
  if (u && u.role === 'owner') return '#ff3232';
  if (u && u.role === 'admin') return '#ff7a45';
  if (u && u.role === 'moderator') return '#ff9500';
  if (u && u.role === 'support') return '#5b8cff';
  if (u && u.role === 'customer') return '#46d39a';
  return '#c9c9d1';
}
// Downloads access (mirrors the server's can_download): the loader is for
// customers; owner/admin keep access too. Drives the nav link + the page gate.
function canDownload(u) { return !!(u && (u.role === 'customer' || u.role === 'owner' || u.role === 'admin')); }
function timeStr(ts) {
  const diff = (Date.now() - ts * 1000) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  return new Date(ts * 1000).toLocaleDateString();
}
function dateStr(ts) {
  return new Date(ts * 1000).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}
function queryParams(q) {
  const out = {}; if (!q) return out;
  q.split('&').forEach(p => { const [k, v] = p.split('='); out[k] = decodeURIComponent(v || ''); });
  return out;
}

/* ---------------- Content helpers (attachments, embeds) ---------------- */
function formatBytes(n) {
  n = Number(n) || 0;
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1024 / 1024).toFixed(1) + ' MB';
}
// Only return the URL if it is a safe http(s) link (used for user-supplied profile links/bg).
// Also allow a same-origin absolute path (/assets/uploads/…): server-uploaded
// images (profile backgrounds) are stored that way. Quotes/whitespace/brackets
// and protocol-relative "//host" are rejected.
function safeUrl(u) {
  u = u || '';
  if (/^https?:\/\//i.test(u)) return u;
  if (/^\/(?!\/)[^\s'"<>\\]*$/.test(u)) return u;
  return '';
}
function youtubeId(url) {
  const m = /(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/.exec(url || '');
  return m ? m[1] : null;
}
/* ---------------- @упоминания (цвет = роль упомянутого) ----------------
   Сервер присылает карту ник→роль (mentionRoles) вместе со списками
   сообщений/постов — сливаем её в кэш. Подсвечиваем только ники, которые
   реально существуют на сайте (нет роли в кэше → @слово остаётся текстом).
   Если упомянут ТЫ — дополнительный класс .me (яркая обводка). */
const MENTION_RE = /@([A-Za-z0-9_][A-Za-z0-9_.\-]{2,19})(?![A-Za-z0-9_.\-])/g;
function mentionRolesMerge(roles) {
  if (!roles || typeof roles !== 'object' || Array.isArray(roles)) return;
  window.state.mentionRoles = window.state.mentionRoles || {};
  for (const k of Object.keys(roles)) {
    const v = String(roles[k]);
    if (/^(member|moderator|admin|owner)$/.test(v)) window.state.mentionRoles[k.toLowerCase()] = v;
  }
}
function mentionAttrs(name) {
  const role = (window.state.mentionRoles || {})[String(name).toLowerCase()];
  if (!role) return null;
  const me = !!(window.state.user && String(window.state.user.username).toLowerCase() === String(name).toLowerCase());
  return { role, me };
}
// Строковая обёртка для HTML-рендеров (посты, ЛС). Вход — УЖЕ экранированный
// текст; ник из MENTION_RE сам по себе безопасен ([A-Za-z0-9_.-]).
function wrapMentions(html) {
  return String(html).replace(MENTION_RE, (m, name) => {
    const a = mentionAttrs(name);
    if (!a) return m;
    return `<a class="mention mention-role-${a.role}${a.me ? ' me' : ''}" href="#/profile/${encodeURIComponent(name)}" title="${a.role}">@${name}</a>`;
  });
}
// DOM-якорь для чата (там текст собирается нодами, без innerHTML).
function mentionAnchor(name) {
  const a = mentionAttrs(name);
  if (!a) return null;
  const el = document.createElement('a');
  el.className = `mention mention-role-${a.role}${a.me ? ' me' : ''}`;
  el.href = '#/profile/' + encodeURIComponent(name);
  el.title = a.role + ' profile';
  el.textContent = '@' + name;
  return el;
}

// Render post text: escape it, auto-linkify URLs, and embed YouTube videos as iframes.
function formatPostContent(text) {
  const safe = esc(text == null ? '' : text);
  const urlRe = /https?:\/\/[^\s<]+/gi;
  let out = '', last = 0, m;
  while ((m = urlRe.exec(safe)) !== null) {
    const url = m[0];
    // @упоминания подсвечиваем только в текстовых кусках — URL внутри
    // ссылки/iframe трогать нельзя (там @ ломал бы адрес).
    out += wrapMentions(safe.slice(last, m.index));
    out += embedOrLink(url);
    last = m.index + url.length;
  }
  out += wrapMentions(safe.slice(last));
  return out;
}
function embedOrLink(url) {
  const yt = youtubeId(url);
  if (yt) return `<div class="embed embed-yt"><iframe src="https://www.youtube.com/embed/${esc(yt)}" title="YouTube video" frameborder="0" allow="encrypted-media; picture-in-picture; fullscreen" allowfullscreen loading="lazy"></iframe></div>`;
  return `<a class="post-link" href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`;
}
function attachIcon(a) {
  const mime = (a.mime || '').toLowerCase();
  if (/^image\//.test(mime)) return '🖼️';
  if (/^video\//.test(mime)) return '🎬';
  if (/^audio\//.test(mime)) return '🎵';
  return '📄';
}
function attachmentHTML(a) {
  const url = esc(a.url);
  const name = esc(a.name || 'file');
  const mime = (a.mime || '').toLowerCase();
  const size = a.size ? formatBytes(a.size) : '';
  if (/^image\//.test(mime)) {
    return `<div class="att att-img"><a href="${url}" target="_blank" rel="noopener noreferrer"><img src="${url}" alt="${name}" loading="lazy"></a></div>`;
  }
  if (/^video\//.test(mime) || /\.(mp4|webm|ogv)$/i.test(name)) {
    return `<div class="att att-video"><video controls src="${url}" preload="metadata"></video></div>`;
  }
  if (/^audio\//.test(mime) || /\.(mp3|wav|ogg)$/i.test(name)) {
    return `<div class="att att-audio"><audio controls src="${url}" preload="metadata"></audio></div>`;
  }
  return `<a class="att att-file" href="${url}" target="_blank" rel="noopener noreferrer" download>
    <span class="att-file-ic">📄</span>
    <span class="att-file-meta"><b>${name}</b><small>${size}</small></span>
    <span class="att-file-dl">Download ⬇</span>
  </a>`;
}
const ICON_YT = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M23 12s0-3.2-.4-4.7a3 3 0 0 0-2.1-2.1C18.9 4.8 12 4.8 12 4.8s-6.9 0-8.5.4A3 3 0 0 0 1.4 7.3C1 8.8 1 12 1 12s0 3.2.4 4.7a3 3 0 0 0 2.1 2.1c1.6.4 8.5.4 8.5.4s6.9 0 8.5-.4a3 3 0 0 0 2.1-2.1C23 15.2 23 12 23 12ZM9.8 15.6V8.4l6.3 3.6Z"/></svg>';
const ICON_DISC = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M20.3 4.4A19.8 19.8 0 0 0 15.4 3l-.3.5a18 18 0 0 1 4.2 1.4 16.5 16.5 0 0 0-14.6 0A18 18 0 0 1 9 4.5L8.7 4A19.8 19.8 0 0 0 3.7 4.4 20.9 20.9 0 0 0 0 19.6a20 20 0 0 0 6 3l.8-1.3a13 13 0 0 1-2-1l.5-.4a13.7 13.7 0 0 0 11.4 0l.5.4a13 13 0 0 1-2 1l.8 1.3a20 20 0 0 0 6-3 20.9 20.9 0 0 0-3.7-15.2ZM8 16.2c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2Zm8 0c-1.1 0-2-1-2-2.2s.9-2.2 2-2.2 2 1 2 2.2-.9 2.2-2 2.2Z"/></svg>';
const ICON_TG = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M21.9 4.3 18.6 20c-.2.9-.8 1.2-1.7.8l-4.8-3.5-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.3 9.6-8.7c.4-.4-.1-.6-.6-.2L6.4 13.3l-5-1.6c-1-.3-1-1 .2-1.5L20.4 2.9c.9-.3 1.7.2 1.5 1.4Z"/></svg>';
function profileLinksHTML(u) {
  const links = [];
  if (safeUrl(u.linkYoutube)) links.push(['yt', u.linkYoutube, ICON_YT]);
  if (safeUrl(u.linkDiscord)) links.push(['disc', u.linkDiscord, ICON_DISC]);
  if (safeUrl(u.linkTelegram)) links.push(['tg', u.linkTelegram, ICON_TG]);
  if (!links.length) return '';
  return `<div class="profile-links">` + links.map(([k, url, svg]) =>
    `<a class="plink plink-${k}" href="${esc(url)}" target="_blank" rel="noopener noreferrer" title="${esc(url)}">${svg}</a>`).join('') + `</div>`;
}

/* ---------------- Attachment composer ---------------- */
function attachmentPickersHTML() {
  return `
    <div class="attach-bar">
      <button type="button" class="btn attach-btn" id="attach-btn">📎 Attach file</button>
      <input type="file" id="attach-input" hidden multiple accept="image/*,video/*,audio/*,.pdf,.txt,.zip,.rar,.7z,.mp4,.webm,.ogv,.mp3,.wav,.ogg">
      <span class="muted attach-hint">images, video, audio, PDF, ZIP · max 15 MB</span>
    </div>
    <div class="attach-list" id="attach-list"></div>`;
}
function wireAttachment(scope, pending) {
  const btn = scope.querySelector('#attach-btn');
  const input = scope.querySelector('#attach-input');
  const list = scope.querySelector('#attach-list');
  if (!btn || !input || !list) return;
  const render = () => {
    list.innerHTML = pending.map((it, i) => `
      <div class="attach-item ${it.uploading ? 'uploading' : ''} ${it.error ? 'error' : ''}">
        <span class="attach-ic">${attachIcon(it)}</span>
        <span class="attach-name">${esc(it.name)}</span>
        <span class="attach-size">${it.uploading ? 'uploading…' : formatBytes(it.size)}</span>
        ${it.error ? `<span class="attach-err">${esc(it.error)}</span>` : ''}
        <button type="button" class="attach-x" data-i="${i}" title="Remove">×</button>
      </div>`).join('');
    list.querySelectorAll('.attach-x').forEach(b => b.onclick = () => { pending.splice(parseInt(b.dataset.i, 10), 1); render(); });
  };
  btn.onclick = () => input.click();
  input.onchange = async () => {
    for (const file of Array.from(input.files)) {
      if (file.size > 15 * 1024 * 1024) { toast('File too large (max 15 MB): ' + file.name, 'error'); continue; }
      const it = { name: file.name, size: file.size, uploading: true };
      pending.push(it); render();
      try {
        const fd = new FormData();
        const upFile = (typeof window.wtechOptimizeImage === 'function') ? await window.wtechOptimizeImage(file) : file;
        fd.append('file', upFile);
        const r = await API.attachmentUpload(fd);
        it.url = r.url; it.mime = r.mime; it.size = r.size; it.name = r.name || file.name; it.uploading = false;
      } catch (e) { it.error = e.message; it.uploading = false; toast(e.message, 'error'); }
      render();
    }
    input.value = '';
  };
}
function pendingAttachments(pending) {
  return pending.filter(p => p.url).map(p => ({ url: p.url, name: p.name, mime: p.mime, size: p.size }));
}

/* ---------------- Toast notifications ---------------- */
function toast(message, type = 'info', ms = 4000) {
  let root = document.getElementById('toasts');
  if (!root) { root = document.createElement('div'); root.id = 'toasts'; root.className = 'toasts'; document.body.appendChild(root); }
  const t = document.createElement('div');
  t.className = 'toast toast-' + type;
  const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : type === 'warn' ? '⚠' : 'ℹ';
  t.innerHTML = `<span class="toast-ic">${icon}</span><span class="toast-msg">${esc(message)}</span><span class="toast-x">✕</span>`;
  const bar = document.createElement('div'); bar.className = 'toast-bar'; bar.style.animationDuration = ms + 'ms';
  t.appendChild(bar);
  root.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  // Hovering a toast pauses BOTH the auto-dismiss timer and the progress bar
  // so the user can actually read a long message before it flies away.
  let left = ms, started = Date.now();
  let timer = setTimeout(() => dismiss(t), ms);
  t._timer = timer;
  t.addEventListener('mouseenter', () => {
    clearTimeout(timer);
    left -= Date.now() - started;
    bar.style.animationPlayState = 'paused';
  });
  t.addEventListener('mouseleave', () => {
    started = Date.now();
    left = Math.max(400, left);
    timer = setTimeout(() => dismiss(t), left);
    t._timer = timer;
    bar.style.animationPlayState = 'running';
  });
  t.onclick = () => dismiss(t);
  function dismiss(el) {
    clearTimeout(el._timer);
    if (el._closing) return;
    el._closing = true;
    // Capture the height first so the slot can collapse smoothly afterwards
    el.style.height = el.offsetHeight + 'px';
    el.classList.remove('show');
    el.classList.add('hide');
    // Let the slide-out (toastOut, 300ms) start, then collapse the freed slot
    // so the toasts below glide up instead of hard-jumping.
    setTimeout(() => el.classList.add('collapse'), 240);
    setTimeout(() => el.remove(), 500);
  }
  return t;
}

/* ---------- Полноэкранный просмотр картинок внутри сайта (лайтбокс) ----------
   Клик по ЛЮБОЙ контентной картинке (чат, ЛС, аттачи постов и тикетов)
   открывает её на полный экран ОВЕРЛЕЕМ — никуда не уводя с сайта (внешние
   target=_blank ссылки-обёртки перехватываются preventDefault-ом). Стрелки
   ←/→ листают остальные картинки того же блока (диалога чата/ЛС/поста),
   Esc закрывает, клик по картинке — зум fit ↔ реальный размер.
   Биндинг ОДИН раз, делегированно — работает и для контента, отрисованного
   позже (свежие сообщения чата/посты). Аватары, emoji и UI-иконки не
   трогаем: селекторы позитивные (только контентные картинки). */
function lbCollection(img) {
  if (img.classList.contains('chat-img')) {
    const dm = img.closest('.dm-thread');
    const scope = dm || img.closest('#chat-messages') || document;
    return Array.from(scope.querySelectorAll('img.chat-img'));
  }
  const wrap = img.closest('.post-attachments') || img.closest('.ticket-attachments');
  if (wrap) return Array.from(wrap.querySelectorAll('.att-img img'));
  return [img];
}
function openWtechLightbox(urls, idx) {
  if (!urls) return;
  urls = urls.filter(Boolean);
  if (!urls.length) return;
  let i = Math.max(0, Math.min(idx | 0, urls.length - 1));
  const ov = document.createElement('div');
  ov.className = 'wtech-lightbox';
  ov.setAttribute('role', 'dialog');
  ov.setAttribute('aria-label', 'Image viewer');
  ov.innerHTML = `
    <div class="lb-stage"><img class="lb-img" alt="" draggable="false"></div>
    <button class="lb-x" type="button" aria-label="Close">✕</button>
    ${urls.length > 1 ? '<button class="lb-nav prev" type="button" aria-label="Previous">‹</button><button class="lb-nav next" type="button" aria-label="Next">›</button>' : ''}
    ${urls.length > 1 ? '<div class="lb-count"></div>' : ''}`;
  const img = ov.querySelector('.lb-img');
  const cnt = ov.querySelector('.lb-count');
  const show = (dir) => {
    img.classList.remove('lb-swap-l', 'lb-swap-r');
    img.src = urls[i];
    if (cnt) cnt.textContent = (i + 1) + ' / ' + urls.length;
    if (dir) { void img.getBoundingClientRect().width; img.classList.add(dir < 0 ? 'lb-swap-l' : 'lb-swap-r'); }
  };
  const step = dd => { i = (i + dd + urls.length) % urls.length; show(dd); };
  let zoomed = false;
  const setZoom = z => { zoomed = z; ov.classList.toggle('zoomed', z); };
  const onKey = (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); close(); }
    else if (e.key === 'ArrowLeft') step(-1);
    else if (e.key === 'ArrowRight') step(1);
  };
  const prevOverflow = document.documentElement.style.overflow;
  document.documentElement.style.overflow = 'hidden';
  const close = () => {
    document.removeEventListener('keydown', onKey, true);
    document.documentElement.style.overflow = prevOverflow;
    ov.classList.remove('open');
    ov.classList.add('closing');
    setTimeout(() => ov.remove(), 220);
  };
  ov.addEventListener('click', (e) => {
    if (e.target.closest('.lb-x')) { e.stopPropagation(); close(); return; }
    if (e.target.closest('.lb-nav.prev')) { e.stopPropagation(); step(-1); return; }
    if (e.target.closest('.lb-nav.next')) { e.stopPropagation(); step(1); return; }
    if (e.target === img) { setZoom(!zoomed); return; }
    if (!zoomed || !e.target.closest('.lb-stage')) close();
  });
  show();
  document.body.appendChild(ov);
  requestAnimationFrame(() => { if (ov.isConnected) ov.classList.add('open'); });
  document.addEventListener('keydown', onKey, true);
}
function lbGlobalClick(e) {
  const t = e.target;
  if (!(t instanceof Element)) return;
  if (t.closest('.wtech-lightbox, .shot-viewer, .emoji-pop, .attach-bar, #topbar')) return;
  const img = t.closest('img.chat-img, .post-attachments .att-img img, .ticket-attachments .att-img img');
  if (!img) return;
  e.preventDefault();
  e.stopPropagation();
  const col = lbCollection(img).filter(im => im.getBoundingClientRect().width > 0);
  const idx = Math.max(0, col.indexOf(img));
  openWtechLightbox(col.map(im => im.currentSrc || im.src), idx);
}
if (!window.__lbBound) {
  window.__lbBound = true;
  document.addEventListener('click', lbGlobalClick, true); // capture: перехват до target=_blank
}

/* ---------------- Animated auth panel (replaces modals) ---------------- */
function loginFormHTML() {
  const last = localStorage.getItem('wtech_last_user') || '';
  const quick = state.quickUser
    ? `<div class="quick-box">
         ${avatarHTML(state.quickUser, 'avatar lg')}
         <div class="quick-meta">
           <div class="quick-name" style="color:${esc(nameColor(state.quickUser))}">${esc(state.quickUser.username)}</div>
           <button class="btn btn-accent" id="quick-login" style="margin-top:8px">Quick login</button>
           <a class="auth-link" id="quick-remove" style="font-size:12px;margin-top:6px;font-weight:500">Remove saved account</a>
         </div>
       </div>
       <div class="divider"><span>or use password</span></div>`
    : '';
  return `<div class="auth-head"><h3>Log in</h3><button class="auth-x" data-close="1">✕</button></div>
  <div class="auth-body form">
    ${quick}
    <label>Username</label><input id="auth-user" value="${esc(last)}" placeholder="Username" autocomplete="username">
    <label>Password</label><input id="auth-pass" type="password" placeholder="Password" autocomplete="current-password">
    <label class="check"><input type="checkbox" id="auth-remember"> Remember me</label>
    <button class="btn btn-accent" id="auth-go">Log in</button>
    <p class="muted" style="text-align:center;margin-top:8px"><a class="auth-link" id="to-forgot">Forgot password?</a></p>
    <p class="muted" style="text-align:center">No account? <a class="auth-link" id="to-register">Create one</a></p>
  </div>`;
}
function registerFormHTML() {
  return `<div class="auth-head"><h3>Sign up</h3><button class="auth-x" data-close="1">✕</button></div>
  <div class="auth-body form">
    <label>Username</label><input id="auth-user" placeholder="3-20 chars: letters, numbers, _ . -">
    <label>Email</label><input id="auth-email" type="email" placeholder="you@example.com" autocomplete="email">
    <label>Password</label><input id="auth-pass" type="password" placeholder="At least 6 characters">
    <p class="muted" style="margin:6px 0 0;font-size:12px">We will email you a 6-digit code to confirm your address.</p>
    <button class="btn btn-accent" id="auth-go">Send confirmation code</button>
    <p class="muted" style="text-align:center;margin-top:10px">Already registered? <a class="auth-link" id="to-login">Log in</a></p>
  </div>`;
}
function registerConfirmHTML(data) {
  const mask = esc((data && data.email_mask) || 'your email');
  return `<div class="auth-head"><h3>Confirm your email</h3><button class="auth-x" data-close="1">✕</button></div>
  <div class="auth-body form">
    <p class="muted" style="margin:0 0 10px">We sent a 6-digit code to <b>${mask}</b>. Enter it below to finish creating your account. The code is valid for 15 minutes — check your spam folder if you don't see it.</p>
    <label>Confirmation code</label>
    <input id="rc-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="123456" class="rc-code-input">
    <button class="btn btn-accent" id="rc-verify">Confirm and create account</button>
    <p class="muted" style="text-align:center;margin-top:10px">Didn't get it? <a class="auth-link" id="rc-resend">Resend code</a></p>
    <p class="muted" style="text-align:center;margin-top:4px"><a class="auth-link" id="rc-back">Use a different email</a></p>
  </div>`;
}
function forgotStep1HTML() {
  return `<div class="auth-head"><h3>Forgot password</h3><button class="auth-x" data-close="1">✕</button></div>
  <div class="auth-body form">
    <p class="muted" style="margin:0 0 10px">Enter your email or username and we will email you a link to reset your password.</p>
    <label>Email or username</label><input id="fg-user" placeholder="you@email.com or username" autocomplete="email">
    <button class="btn btn-accent" id="fg-next">Send reset email</button>
    <p class="muted" style="text-align:center;margin-top:10px"><a class="auth-link" id="to-login2">Back to login</a></p>
  </div>`;
}
function forgotSentHTML(ttlLabel) {
  const ttl = esc(ttlLabel || '5 minutes');
  return `<div class="auth-head"><h3>Check your email</h3><button class="auth-x" data-close="1">✕</button></div>
  <div class="auth-body form">
    <p class="muted" style="margin:0 0 6px">If the email or username you entered matches an account, we have sent a password-reset link to its email address.</p>
    <p class="muted" style="margin:0 0 14px">The link is valid for ${ttl}. If you do not see the email, check your spam folder.</p>
    <button class="btn btn-accent" id="to-login2" style="width:100%">Back to login</button>
  </div>`;
}
function forgotStep2HTML(username, mask) {
  return `<div class="auth-head"><h3>Reset password</h3><button class="auth-x" data-close="1">✕</button></div>
  <div class="auth-body form">
    <p class="muted">Account: <b>${esc(username)}</b></p>
    <p class="muted">Email on file: <b>${esc(mask)}</b></p>
    <label>Confirm email</label><input id="fg-email" placeholder="your@email.com">
    <label>New password</label><input id="fg-pass" type="password" placeholder="At least 6 characters">
    <button class="btn btn-accent" id="fg-reset">Reset password</button>
    <p class="muted" style="text-align:center;margin-top:10px"><a class="auth-link" id="to-login2">Back to login</a></p>
  </div>`;
}
function showAuth(mode, data) {
  let scrim = document.getElementById('auth-scrim');
  let panel = document.getElementById('auth-panel');
  if (!panel) {
    scrim = document.createElement('div'); scrim.id = 'auth-scrim'; scrim.className = 'auth-scrim';
    panel = document.createElement('div'); panel.id = 'auth-panel'; panel.className = 'auth-panel';
    document.body.appendChild(scrim); document.body.appendChild(panel);
    scrim.addEventListener('click', hideAuth);
  }
  panel.innerHTML = mode === 'register' ? registerFormHTML()
    : mode === 'register_confirm' ? registerConfirmHTML(data)
    : mode === 'forgot' ? forgotStep1HTML()
    : mode === 'forgot_sent' ? forgotSentHTML(data && data.ttl_label)
    : loginFormHTML();
  const closeBtn = panel.querySelector('[data-close]'); if (closeBtn) closeBtn.onclick = hideAuth;
  const toReg = panel.querySelector('#to-register'); if (toReg) toReg.onclick = () => showAuth('register');
  const toLog = panel.querySelector('#to-login'); if (toLog) toLog.onclick = () => showAuth('login');
  const toLog2 = panel.querySelector('#to-login2'); if (toLog2) toLog2.onclick = () => showAuth('login');
  const toForgot = panel.querySelector('#to-forgot'); if (toForgot) toForgot.onclick = () => showAuth('forgot');
  const go = panel.querySelector('#auth-go'); if (go) go.onclick = () => (mode === 'register' ? doRegister() : doLogin());
  const ql = panel.querySelector('#quick-login'); if (ql) ql.onclick = doQuickLogin;
  const qr = panel.querySelector('#quick-remove'); if (qr) qr.onclick = doQuickForget;
  const pass = panel.querySelector('#auth-pass'); if (pass) pass.addEventListener('keydown', e => { if (e.key === 'Enter') (mode === 'register' ? doRegister() : doLogin()); });
  const fgnext = panel.querySelector('#fg-next');
  if (fgnext) fgnext.onclick = async () => {
    const acct = panel.querySelector('#fg-user').value.trim();
    if (!acct) { toast('Enter your email or username', 'warn'); return; }
    fgnext.disabled = true;
    try { const r = await API.forgotRequest(acct); showAuth('forgot_sent', { ttl_label: r.ttl_label }); }
    catch (e) { toast(e.message, 'error'); fgnext.disabled = false; }
  };
  // Register: confirm-code step wiring.
  const rcVerify = panel.querySelector('#rc-verify');
  if (rcVerify) rcVerify.onclick = () => doRegisterVerify(data);
  const rcResend = panel.querySelector('#rc-resend');
  if (rcResend) rcResend.onclick = async () => {
    if (!data || !data.token) return;
    rcResend.style.pointerEvents = 'none';
    try { await API.registerResend(data.token); toast('A new code has been sent.', 'success'); }
    catch (e) { toast(e.message, 'error'); }
    finally { setTimeout(() => { rcResend.style.pointerEvents = ''; }, 3000); }
  };
  const rcBack = panel.querySelector('#rc-back');
  if (rcBack) rcBack.onclick = () => showAuth('register');
  const rcCode = panel.querySelector('#rc-code');
  if (rcCode) {
    // Digits only + auto-submit as soon as 6 digits are entered.
    rcCode.addEventListener('input', () => {
      rcCode.value = rcCode.value.replace(/\D+/g, '').slice(0, 6);
      if (rcCode.value.length === 6) doRegisterVerify(data);
    });
    rcCode.addEventListener('keydown', e => { if (e.key === 'Enter') doRegisterVerify(data); });
    setTimeout(() => rcCode.focus(), 360);
  }
  const fgreset = panel.querySelector('#fg-reset');
  if (fgreset) fgreset.onclick = async () => {
    const uname = (panel.querySelector('#fg-user') || {}).value || '';
    try { await API.forgotReset({ username: uname, email: panel.querySelector('#fg-email').value, password: panel.querySelector('#fg-pass').value }); toast('Password reset — you can log in now.', 'success'); showAuth('login'); }
    catch (e) { toast(e.message, 'error'); }
  };
  requestAnimationFrame(() => { scrim.classList.add('show'); panel.classList.add('show'); });
  const userInput = panel.querySelector('#auth-user'); if (userInput) setTimeout(() => userInput.focus(), 360);
}
function hideAuth() {
  const scrim = document.getElementById('auth-scrim'); const panel = document.getElementById('auth-panel');
  if (scrim) scrim.classList.remove('show'); if (panel) panel.classList.remove('show');
}
async function doLogin() {
  const u = document.getElementById('auth-user').value, p = document.getElementById('auth-pass').value;
  const remember = document.getElementById('auth-remember') ? document.getElementById('auth-remember').checked : false;
  try {
    const r = await API.login(u, p, remember);
    localStorage.setItem('wtech_last_user', u);
    state.user = r.user;
    // Banned account: let them in only as far as the ban screen (server-side the
    // account is locked to me/logout), so they can see the reason and log out.
    if (state.user.banned) { hideAuth(); showBanScreen(state.user); return; }
    hideAuth(); updateAuth();
    if (window.initChat) window.initChat();
    router();
    toast('Welcome, ' + r.user.username + '!', 'success');
  } catch (e) { toast(e.message, 'error'); }
}
async function doRegister() {
  const u = document.getElementById('auth-user').value;
  const p = document.getElementById('auth-pass').value;
  const e = document.getElementById('auth-email').value;
  const btn = document.getElementById('auth-go');
  if (btn) btn.disabled = true;
  try {
    const r = await API.register({ username: u, email: e, password: p });
    // Server always returns { pending, token, email_mask } when the code has
    // been emailed — jump to the confirmation step and remember the details.
    if (r && r.pending) {
      showAuth('register_confirm', { token: r.token, email_mask: r.email_mask, username: u });
      toast('We emailed you a 6-digit code — check your inbox (and spam).', 'success');
      return;
    }
    // Legacy path (kept for safety): server created the account directly.
    state.user = r.user; hideAuth(); updateAuth();
    if (window.initChat) window.initChat();
    router();
    toast('Account created. Welcome, ' + r.user.username + '!', 'success');
  } catch (err) { toast(err.message, 'error'); if (btn) btn.disabled = false; }
}
async function doRegisterVerify(ctx) {
  if (!ctx || !ctx.token) { toast('This confirmation expired. Please sign up again.', 'error'); showAuth('register'); return; }
  const codeEl = document.getElementById('rc-code');
  const btn    = document.getElementById('rc-verify');
  const code   = (codeEl && codeEl.value || '').replace(/\D+/g, '');
  if (code.length !== 6) { toast('Enter the 6-digit code from the email.', 'warn'); return; }
  if (btn) btn.disabled = true;
  try {
    const r = await API.registerVerify({ token: ctx.token, code });
    state.user = r.user; hideAuth(); updateAuth();
    if (window.initChat) window.initChat();
    router();
    toast('Email confirmed. Welcome, ' + r.user.username + '!', 'success');
  } catch (err) {
    toast(err.message, 'error');
    if (btn) btn.disabled = false;
    if (codeEl) { codeEl.value = ''; codeEl.focus(); }
  }
}

/* ---------------- Topbar ---------------- */
function renderTopbar() {
  document.getElementById('topbar').innerHTML = `
    <div class="topbar-inner">
    <a class="brand" href="#/home" aria-label="+W.TECH FORUM — home">
      <img class="logo-img" src="/assets/img/logo.png?v=2" alt="(◣_◢) +W.TECH FORUM" draggable="false">
    </a>
    <nav class="nav">
      <a href="#/home">Home</a>
      <a href="#/tickets">Tickets</a>
      <a href="#/forum">Forum</a>
      <a href="#/downloads" id="nav-downloads">Downloads</a>
    </nav>
    <div class="topbar-right">
      <button class="btn chat-toggle" id="chat-toggle">💬 Chat</button>
      <button class="btn notif-bell" id="notif-bell" type="button" style="display:none" title="Notifications">🔔<span class="nav-badge notif-badge" id="notif-badge"></span></button>
      <div id="auth-area"></div>
      <a class="topbar-dm" href="#/dm" id="nav-dm">✉ Messages <span class="nav-badge" id="dm-badge"></span></a>
    </div>
    </div>`;
  const ct = document.getElementById('chat-toggle');
  if (ct) ct.onclick = () => document.getElementById('chat').classList.toggle('open');
  const nb = document.getElementById('notif-bell');
  if (nb) nb.onclick = (e) => { e.stopPropagation(); toggleNotifPanel(); };
}
async function refreshDmBadge() {
  const el = document.getElementById('dm-badge');
  if (!el) return;
  if (!state.user) { el.style.display = 'none'; el.textContent = ''; return; }
  try {
    const r = await API.dmUnread();
    const n = r.unread || 0;
    el.textContent = n ? (n > 99 ? '99+' : String(n)) : '';
    el.style.display = n ? 'inline-flex' : 'none';
  } catch (e) { /* ignore */ }
}
// Poll the unread-DM count on an interval so the topbar badge lights up the
// moment a message lands — works on both the PHP (polling) and Node backends.
// Node also pushes via socket.io for true instant delivery; this is the
// universal fallback and covers the PHP/Beget deploy as well.
function startDmWatcher() {
  if (window.__dmWatch) return;
  window.__dmWatch = setInterval(() => { if (state.user) refreshDmBadge(); }, 4000);
}

/* ---------------- Notification center (колокольчик в шапке) ----------------
   Источники: ответы в твоих темах, @упоминания (форум и чат), ЛС,
   тикеты (+ лайки конфигов в версии с маркетом).
   Realtime: chat_poll (1.5 с) таскает счётчик в поле `notif`, me() — в
   `unreadNotif`; плюс фолбэк-интервал 30 с, если чат не опрашивается. */
const NOTIF_TEXT = {
  reply_thread:  { ic: '💬', text: () => 'replied to your thread' },
  mention:       { ic: '＠', text: () => 'mentioned you in' },
  mention_chat:  { ic: '💬', text: () => 'mentioned you in' },
  dm:            { ic: '✉',  text: () => 'sent you a message' },
  ticket_new:    { ic: '🎫', text: () => 'opened a new ticket' },
  ticket_reply:  { ic: '🎫', text: () => 'replied in the ticket' },
  ticket_answer: { ic: '🎫', text: () => 'answered your ticket' },
  ticket_status: { ic: '🎫', text: () => 'changed your ticket' },
  config_like:   { ic: '❤',  text: () => 'liked your config' },
};
function notifTime(t) {
  const d = Date.now() / 1000 - (t || 0);
  if (d < 60) return 'just now';
  if (d < 3600) return Math.max(1, Math.floor(d / 60)) + 'm ago';
  if (d < 86400) return Math.floor(d / 3600) + 'h ago';
  if (d < 7 * 86400) return Math.floor(d / 86400) + 'd ago';
  const dt = new Date((t || 0) * 1000);
  return dt.toLocaleDateString('en-US');
}
function setNotifCount(n) {
  n = Math.max(0, n | 0);
  const prev = state.notifUnread || 0;
  state.notifUnread = n;
  const el = document.getElementById('notif-badge');
  if (el) {
    el.textContent = n ? (n > 99 ? '99+' : String(n)) : '';
    el.style.display = n ? 'inline-flex' : 'none';
  }
  // Новое уведомление при закрытой панели — мигнуть колокольчиком.
  if (n > prev && !document.getElementById('notif-panel')) {
    const bell = document.getElementById('notif-bell');
    if (bell) { bell.classList.remove('ring'); void bell.offsetWidth; bell.classList.add('ring'); }
  }
}
window.setNotifCount = setNotifCount; // хук для chat.php (poll таскает d.notif)
async function pollNotifCount() {
  if (!state.user) { setNotifCount(0); return; }
  try { const r = await API.notifUnread(); if (state.user) setNotifCount(r.unread || 0); } catch (e) { /* transient */ }
}
function refreshNotifBell() {
  const bell = document.getElementById('notif-bell');
  if (!bell) return;
  bell.style.display = state.user ? '' : 'none';
  if (!state.user) closeNotifPanel();
  pollNotifCount();
}
function startNotifWatcher() {
  if (window.__notifWatch) return;
  window.__notifWatch = setInterval(() => { if (state.user) pollNotifCount(); }, 30000);
}
function closeNotifPanel() {
  const p = document.getElementById('notif-panel');
  if (p) p.remove();
  document.removeEventListener('click', notifOutsideHandler);
  document.removeEventListener('keydown', notifEscHandler);
}
function notifOutsideHandler(e) {
  const p = document.getElementById('notif-panel');
  const b = document.getElementById('notif-bell');
  if (p && !p.contains(e.target) && b && !b.contains(e.target)) closeNotifPanel();
}
function notifEscHandler(e) { if (e.key === 'Escape') closeNotifPanel(); }
async function toggleNotifPanel() {
  if (document.getElementById('notif-panel')) { closeNotifPanel(); return; }
  if (!state.user) return;
  const bell = document.getElementById('notif-bell');
  const panel = document.createElement('div');
  panel.id = 'notif-panel'; panel.className = 'notif-panel';
  panel.innerHTML = `
    <div class="notif-head"><span>🔔 Notifications</span><button type="button" id="notif-clear">Mark all read</button></div>
    <div class="notif-list"><div class="notif-empty muted">Loading…</div></div>`;
  document.body.appendChild(panel);
  const r = bell.getBoundingClientRect();
  panel.style.top = (r.bottom + 8) + 'px';
  panel.style.right = Math.max(8, window.innerWidth - r.right - 8) + 'px';
  document.getElementById('notif-clear').onclick = async (e) => {
    e.stopPropagation();
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      const res = await API.notifRead(0);
      setNotifCount(res.unread || 0);
      // Notifications are deleted server-side — make them disappear in the
      // panel too (fade out, then show the empty state), not just de-highlight.
      panel.querySelectorAll('.notif-item').forEach(el => el.classList.add('notif-fade'));
      setTimeout(() => {
        const l = panel.querySelector('.notif-list');
        if (l && document.body.contains(panel)) l.innerHTML = '<div class="notif-empty muted">All caught up — no unread notifications</div>';
      }, 240);
    } catch (err) { toast(err.message || 'Failed', 'error'); btn.disabled = false; }
  };
  setTimeout(() => document.addEventListener('click', notifOutsideHandler), 0);
  document.addEventListener('keydown', notifEscHandler);
  try {
    const d = await API.notifList();
    if (!document.getElementById('notif-panel')) return; // закрыли, пока грузили
    setNotifCount(d.unread || 0);
    renderNotifItems(panel, d.notifications || []);
  } catch (e) {
    if (!document.getElementById('notif-panel')) return;
    panel.querySelector('.notif-list').innerHTML = `<div class="notif-empty muted">${esc(e.message)}</div>`;
  }
}
function renderNotifItems(panel, items) {
  const list = panel.querySelector('.notif-list');
  if (!items.length) { list.innerHTML = '<div class="notif-empty muted">All caught up — no unread notifications</div>'; return; }
  list.innerHTML = items.map(n => {
    const meta = NOTIF_TEXT[n.type] || { ic: '🔔', text: () => 'notified you about' };
    return `<div class="notif-item${n.unread ? ' unread' : ''}" data-id="${n.id}" data-link="${esc(n.link)}">
      <span class="notif-ic">${meta.ic}</span>
      <span class="notif-body"><b>${esc(n.actor)}</b> ${meta.text(n)}${n.title ? ` <i>«${esc(n.title)}»</i>` : ''}${n.cnt > 1 ? ` <b class="notif-cnt">×${n.cnt}</b>` : ''}<small class="muted">${notifTime(n.created)}</small></span>
    </div>`;
  }).join('');
  list.querySelectorAll('.notif-item').forEach(el => el.onclick = async () => {
    const id = +el.dataset.id, link = el.dataset.link || '';
    try { const res = await API.notifRead(id); setNotifCount(res.unread || 0); } catch (e) {}
    closeNotifPanel();
    // Упоминание в чате: маршрута у чата нет — открываем панель и мигаем ей.
    if (link === 'chat') {
      const chat = document.getElementById('chat');
      if (chat) {
        chat.classList.add('open');
        chat.classList.add('chat-flash');
        setTimeout(() => chat.classList.remove('chat-flash'), 1600);
      }
      return;
    }
    if (link) location.hash = '#/' + link.replace(/^#?\/?/, '');
  });
}

/* ---------------- Live stats (silent AJAX polling) ----------------
   Keeps the home-page counters (Members / Threads / Posts / Online)
   up to date without a page reload. The Online counter is the most
   time-sensitive one, so it is also fed live by chat.js from every
   chat_poll response (see setOnlineCount below) — that gives it a
   ~1.5 s refresh cadence for logged-in users, instead of waiting for
   the slower stats poll below. */
function setStatText(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  const txt = String(value);
  if (el.textContent !== txt) {
    el.textContent = txt;
    // Subtle, silent highlight so the change is perceptible but not intrusive.
    el.classList.remove('stat-bump'); void el.offsetWidth; el.classList.add('stat-bump');
  }
}
// Single source of truth for the "online" count: updates BOTH the chat
// sidebar's "N online" pill and the hero-stats "Online" number in one call.
// Exposed on window so chat.js can push the fresh count the instant a
// chat_poll response arrives — no waiting for the 5 s stats tick.
function setOnlineCount(n) {
  n = Math.max(0, parseInt(n, 10) || 0);
  setStatText('stat-online', n);                 // hero-stats on the home view
  const pill = document.getElementById('chat-presence');
  if (pill) {
    const txt = n + ' online';
    if (pill.textContent !== txt) pill.textContent = txt;
  }
}
window.setOnlineCount = setOnlineCount;
async function refreshStats() {
  // The Online part of stats runs on its own live-update path (chat_poll),
  // so we only need the other three counters here. But if the hero block
  // isn't on screen at all, skip the request entirely — no wasted traffic.
  if (!document.getElementById('stat-users')) return; // not on the home view
  try {
    const s = await API.stats();
    setStatText('stat-users', s.users);
    setStatText('stat-threads', s.threads);
    setStatText('stat-posts', s.posts);
    // Only use the stats endpoint's `online` as a fallback for guests
    // (who never talk to chat_poll). For logged-in users chat.js pushes
    // a fresher value every ~1.5 s and we shouldn't overwrite it with a
    // possibly-slightly-stale one from the general stats endpoint.
    if (!state.user) setOnlineCount(s.online || 0);
    else setStatText('stat-online', (typeof window.__lastOnline === 'number' ? window.__lastOnline : (s.online || 0)));
  } catch (e) { /* ignore transient errors */ }
}
function startStatsWatcher() {
  if (window.__statsWatch) return;
  // 5 s (was 20 s) — the Online counter now updates from chat_poll for
  // logged-in users, and this shorter interval keeps Members/Threads/Posts
  // fresh too without meaningful extra load (one tiny GET every 5 s).
  window.__statsWatch = setInterval(refreshStats, 5000);
  // Refresh instantly when the tab becomes visible again so numbers are fresh.
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshStats(); });
}

function updateAuth() {
  const el = document.getElementById('auth-area');
  const isStaff = state.user && ['owner', 'admin'].includes(state.user.role);
  if (state.user) {
    el.innerHTML = `
      <a class="userchip" href="#/profile/${encodeURIComponent(state.user.username)}">
        ${avatarHTML(state.user, 'avatar')}
        <span style="color:${esc(nameColor(state.user))}">${esc(state.user.username)}</span>
      </a>
      ${isStaff ? `<button class="btn admin-trigger" id="admin-trigger" title="Admin panel">⚙ Admin</button>` : ''}
      ${isStaff ? `<a class="btn backend-link" href="/go-backend.php" target="_blank" rel="noopener noreferrer" title="Open backend admin panel">⚙ Backend</a>` : ''}
      <button class="btn" id="logout-btn">Log out</button>`;
    document.getElementById('logout-btn').onclick = async () => {
      try { await API.logout(); } catch (e) {}
      state.user = null; await refreshQuickUser(); updateAuth(); closeAdminDropdown();
      if (window.initChat) window.initChat();
      router();
      // Refresh the "Online" counter immediately after we drop out of the
      // presence table on the server (chat_poll won't fire again while
      // logged out — the general stats endpoint is the fastest path here).
      if (typeof refreshStats === 'function') refreshStats();
    };
    const at = document.getElementById('admin-trigger');
    if (at) at.onclick = (e) => { e.stopPropagation(); toggleAdminDropdown(); };
  } else {
    el.innerHTML = `<button class="btn" data-action="login">Log in</button><button class="btn btn-accent" data-action="register">Sign up</button>`;
  }
  const navDm = document.getElementById('nav-dm');
  if (navDm) navDm.style.display = state.user ? '' : 'none';
  // The Downloads link only exists for customers (+ owner/admin); after the
  // role is granted the link appears on the next login / page reload.
  const navDl = document.getElementById('nav-downloads');
  if (navDl) navDl.style.display = canDownload(state.user) ? '' : 'none';
  refreshDmBadge();
  refreshNotifBell();
}
async function refreshQuickUser() {
  try { const q = await API.quickLoginInfo(); state.quickUser = (q && q.user) ? q.user : null; }
  catch (e) { state.quickUser = null; }
}
async function doQuickLogin() {
  try {
    const r = await API.quickLogin();
    state.user = r.user; state.quickUser = null;
    if (state.user.banned) { hideAuth(); showBanScreen(state.user); return; }
    hideAuth(); updateAuth();
    if (window.initChat) window.initChat();
    router();
    toast('Welcome back, ' + r.user.username + '!', 'success');
  } catch (e) { toast(e.message, 'error'); }
}
async function doQuickForget() {
  try {
    await API.quickForget();
    state.quickUser = null;
    showAuth('login'); // re-render the modal without the saved account
    toast('Saved account removed', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

/* ---------------- Row renderers ---------------- */
function threadRow(t) {
  // Standard leading icon: pinned / locked / normal discussion.
  const icon = t.pinned ? '📌' : (t.locked ? '🔒' : '💬');
  return `<a class="trow" href="#/thread/${t.id}">
    <span class="tpin">${icon}</span>
    <span class="ttitle">${esc(t.title)}</span>
    <span class="tmeta"><span class="tauthor" style="color:${esc(nameColor(t.author))}">${esc(t.author.username)}</span> <span class="tag tag-${t.author.role}">${esc(t.author.role)}</span> · ${t.postCount} replies</span>
  </a>`;
}
function catRow(c) {
  return `<a class="crow" href="#/category/${c.id}">
    <span class="cicon">${esc(c.icon || '🗂️')}</span>
    <span class="cbody"><b>${esc(c.name)}</b><small>${esc(c.description)}</small></span>
    <span class="ccount">${c.threadCount}<small>threads</small></span>
  </a>`;
}
function catCard(c) {
  return `<a class="cat-card" href="#/category/${c.id}">
    <div class="cat-icon">${esc(c.icon || '🗂️')}</div>
    <div class="cat-info">
      <h3>${esc(c.name)}</h3><p>${esc(c.description)}</p>
      <div class="cat-stats">${c.threadCount} threads · ${c.postCount} posts</div>
      ${c.last ? `<div class="cat-last">Last: ${esc(c.last.title)}</div>` : ''}
    </div></a>`;
}
function postRow(p) {
  const u = p.author || { username: 'unknown' };
  const phref = '#/profile/' + encodeURIComponent(u.username);
  const color = esc(nameColor(u));
  const atts = (p.attachments || []).map(attachmentHTML).join('');
  return `<div class="post">
    <div class="post-side">
      <a class="post-avatar" href="${phref}" title="View profile">${avatarHTML(u, 'avatar lg')}</a>
      <a class="pname" href="${phref}" title="View profile" style="color:${color}">${esc(u.username)}</a>
      <div class="prole">${esc(u.role || '')}</div>
    </div>
    <div class="post-main">
      <div class="post-time">${timeStr(p.createdAt)}</div>
      <div class="post-content">${formatPostContent(p.content)}</div>
      ${atts ? `<div class="post-attachments">${atts}</div>` : ''}
    </div>
  </div>`;
}
function pager(t, base) {
  if (t.pages <= 1) return '';
  let s = '<div class="pager">';
  for (let i = 1; i <= t.pages; i++) s += `<a class="${i === t.page ? 'active' : ''}" href="${base}${i}">${i}</a>`;
  s += '</div>';
  return s;
}

/* ---------------- Views ---------------- */
async function renderHome(app) {
  // Landing в стиле nixware.cc: полноэкранный hero (canvas-частицы + орбы +
  // глитч логотипа), карточки фич, count-up статистика, FAQ. Форум — по CTA.
  // Чат колонку скрываем и здесь (на случай попадания сюда из default-ветки
  // роутера, где стандартная проверка segs.length === 0 не сработала).
  const __homeChat = document.getElementById('chat');
  if (__homeChat) __homeChat.style.display = 'none';
  const __homeChatCol = document.querySelector('.chat-column');
  if (__homeChatCol) __homeChatCol.style.display = 'none';
  const [latest, stats] = await Promise.all([
    API.threads({ page: 1 }).then(d => d.threads.slice(0, 8)),
    API.stats(),
  ]);
  // Конфиги: market есть только в fixed-линии — ссылка подбирается в рантайме.
  const hasMarket = (typeof API.configsList === 'function');
  const cfgLink = hasMarket ? '#/market' : '#/category/configs';
  const cfgLabel = hasMarket ? 'Workshop & Market' : 'Community configs';
  const feats = [
    { ic: '⚔️', t: 'Legit & Rage', d: 'Fine-tuning for quiet legit play or full rage — the loader is adapted to current CS:GO mechanics.', href: '#/downloads', a: 'Get the loader' },
    { ic: '👁️', t: 'Visuals & ESP', d: 'Enemy positions, chams and world objects with a customizable palette and display filters.', href: '#/downloads', a: 'See features' },
    { ic: '📜', t: 'Lua scripts', d: 'Open API to extend the loader: community-made scripts or your own solutions.', href: '#/category/lua', a: 'Open Lua section' },
    { ic: '🧩', t: cfgLabel, d: 'A database of ready configs from users: quick search, one-click download, share your own.', href: cfgLink, a: 'Browse configs' },
  ];
  app.innerHTML = `
    <section class="ld-hero">
      <canvas id="ld-stars" aria-hidden="true"></canvas>
      <div class="ld-orb ld-orb-1" aria-hidden="true"></div>
      <div class="ld-orb ld-orb-2" aria-hidden="true"></div>
      <div class="ld-orb ld-orb-3" aria-hidden="true"></div>
      <div class="ld-gridlay" aria-hidden="true"></div>
      <div class="ld-hero-in">
        <div class="ld-badge fu" style="--d:.05s"><span class="ld-badge-dot"></span>online right now: <b>${stats.online || 0}</b></div>
        <h1 class="ld-logo" data-text="+W.TECH LOADER">+W.TECH LOADER</h1>
        <p class="ld-sub fu" style="--d:.3s">Fast. Undetected. The community-powered loader for CS:GO — configs, Lua scripts and the community itself in one place.</p>
        <div class="ld-cta fu" style="--d:.45s">
          <a class="ld-btn" href="#/forum">Enter the forum <span class="ld-btn-arrow">→</span></a>
          <a class="ld-btn ld-btn-ghost" href="#/downloads">Downloads</a>
        </div>
        <div class="ld-hint fu" style="--d:.6s">one click to discussions, configs and support</div>
      </div>
      <div class="ld-mock-float" aria-hidden="true"><div class="ld-mock">
        <div class="ld-mock-head"><i></i><i></i><i></i><span>+W.tech-recode</span></div>
        <div class="ld-mock-body">
          <div class="ld-mock-sec">— combat —</div>
          <div class="ld-mock-row on"><i></i>aimbot<b>on</b></div>
          <div class="ld-mock-row on"><i></i>triggerbot<b>on</b></div>
          <div class="ld-mock-row"><i></i>silent aim<b>off</b></div>
          <div class="ld-mock-sec">— visuals —</div>
          <div class="ld-mock-row on"><i></i>esp box<b>on</b></div>
          <div class="ld-mock-row on"><i></i>chams<b>on</b></div>
          <div class="ld-mock-slider"><span>fov</span><div class="ld-mock-slider-bar"><div class="ld-mock-slider-fill"></div></div><b>72</b></div>
          <div class="ld-mock-scan"></div>
        </div>
      </div></div>
      <div class="ld-scroll" aria-hidden="true"><span>▾</span></div>
    </section>

    <section class="ld-feats">
      ${feats.map((f, i) => `
        <a class="ld-feat fu" style="--d:${(.1 + i * .1).toFixed(2)}s" href="${f.href}">
          <span class="ld-feat-ic">${f.ic}</span>
          <span class="ld-feat-t">${f.t}</span>
          <span class="ld-feat-d">${f.d}</span>
          <span class="ld-feat-a">${f.a} →</span>
        </a>`).join('')}
    </section>

    <section class="ld-strip fu" style="--d:.2s">
      <div class="ld-stat"><b data-count="${stats.users}" id="stat-users">0</b><span>Members</span></div>
      <div class="ld-stat"><b data-count="${stats.threads}" id="stat-threads">0</b><span>Threads</span></div>
      <div class="ld-stat"><b data-count="${stats.posts}" id="stat-posts">0</b><span>Posts</span></div>
      <div class="ld-stat"><b id="stat-online">${stats.online || 0}</b><span>Online</span></div>
    </section>

    <section class="ld-low fu" style="--d:.3s">
      <div class="ld-faq card">
        <h2>FAQ</h2>
        <details class="ld-faq-i" open><summary>How do I get access to the loader?</summary><p>Register on the forum and create a support ticket — the staff will set up your access and answer within 24 hours.</p></details>
        <details class="ld-faq-i"><summary>Where do I download the loader?</summary><p>On the <a href="#/downloads">Downloads</a> page — it unlocks once your account has the customer role.</p></details>
        <details class="ld-faq-i"><summary>Where can I get help?</summary><p>In <a href="#/tickets">tickets</a> (private, staff-only) or in the <a href="#/category/support">Support</a> category on the forum.</p></details>
      </div>
      <div class="card ld-latest">
        <h2>📢 Latest from the team</h2>
        <div class="thread-list">${latest.map(threadRow).join('')}</div>
        <a href="#/forum" style="color:var(--accent-2);font-weight:600">View all discussions →</a>
      </div>
    </section>`;
  renderFooter();
  startLandingFx(app);
  emojiParse(app);
}

/* ---------- Landing FX: particle network canvas + count-up ---------- */
// rAF-цикл сам останавливается и снимает слушатели, когда canvas выпал из DOM
// (переход на другой маршрут) — утечек и «фонового жора CPU» нет.
function startLandingFx(app) {
  const cv = app.querySelector('#ld-stars');
  if (cv) runStarfield(cv);
  app.querySelectorAll('[data-count]').forEach(el => animateCount(el, +el.dataset.count || 0));
  splitLogoChars(app);
  // Hero за экраном (лендинг длинный) → ставим на паузу ВСЕ его CSS-анимации
  // (буквы-волна/перелив, орбы, сетка, пульс кнопки, скан, стрелочки). Класс
  // снимается при возврате — ни огрызков CPU/GPU на невидимом блоке.
  const hero = app.querySelector('.ld-hero');
  if (hero && ('IntersectionObserver' in window) && !window.__ldHeroIO) {
    window.__ldHeroIO = new IntersectionObserver(es => {
      document.querySelectorAll('.ld-hero').forEach(h => {
        h.classList.toggle('ld-paused', !(es[0] && es[0].isIntersecting));
      });
    }, { threshold: 0.01 });
    window.__ldHeroIO.observe(hero);
  }
}
// Заголовок лендинга: режем «+W.TECH LOADER» на буквы — каждая влетает
// снизу из блюра с лёгким поворотом (каскад слева направо), а через ~1.6 c
// подключается тихая «волна» (у всех букв своя фаза). Градиент/блик и
// редкий глитч слоёв ::before/::after у родителя при этом сохраняются.
// При prefers-reduced-motion текст остаётся как есть, без нарезки.
function splitLogoChars(app) {
  const h1 = app.querySelector('.ld-logo');
  if (!h1 || h1.dataset.split) return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  h1.dataset.split = '1';
  const text = h1.textContent;
  h1.textContent = '';
  let i = 0;
  for (const ch of text) {
    if (ch === ' ') { h1.appendChild(document.createTextNode(' ')); continue; }
    const sp = document.createElement('span');
    sp.className = 'ld-ch';
    sp.style.setProperty('--i', String(i++));
    sp.textContent = ch;
    h1.appendChild(sp);
  }
  setTimeout(() => { if (h1.isConnected) h1.classList.add('ld-logo-live'); }, 1600);
}
function animateCount(el, target) {
  const t0 = performance.now(), dur = 1100;
  const f = t => {
    if (!el.isConnected) return;
    const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = Math.round(target * e);
    if (k < 1) requestAnimationFrame(f);
  };
  requestAnimationFrame(f);
}
function runStarfield(cv) {
  const ctx = cv.getContext('2d');
  if (!ctx) return;
  // DPR ограничен 1.5: на HiDPI fill-rate был главным жором GPU, визуально
  // разницы между 1.5x и 2x буфером для мелких точек/линий нет.
  const DPR = Math.min(1.5, window.devicePixelRatio || 1);
  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w = 0, h = 0;
  const pts = [];
  for (let i = 0; i < 62; i++) pts.push({
    x: Math.random(), y: Math.random(),
    vx: (Math.random() - .5) * .00055, vy: (Math.random() - .5) * .00055,
    r: Math.random() * 1.5 + .4,
  });
  function resize() {
    const r = cv.parentNode.getBoundingClientRect();
    w = cv.width = Math.max(1, r.width * DPR);
    h = cv.height = Math.max(1, r.height * DPR);
  }
  let mx = .5, my = .5;
  const onMove = e => {
    const r = cv.getBoundingClientRect();
    if (!r.width) return;
    mx = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    my = Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
  };
  const onResize = () => { resize(); if (reduced) draw(); };
  resize();
  window.addEventListener('pointermove', onMove, { passive: true });
  window.addEventListener('resize', onResize);
  // Пауза, когда hero прокручен за экран (лендинг — длинная страница):
  // IntersectionObserver гасит draw-кадры, rAF-цикл почти ничего не стоит.
  let onScreen = true;
  const io = ('IntersectionObserver' in window)
    ? new IntersectionObserver(es => { onScreen = !!(es[0] && es[0].isIntersecting); }, { threshold: 0.02 })
    : null;
  if (io) io.observe(cv);
  const LINK = 110;
  function draw() {
    ctx.clearRect(0, 0, w, h);
    const px = reduced ? 0 : (mx - .5) * 42 * DPR, py = reduced ? 0 : (my - .5) * 42 * DPR;
    const linkMax = LINK * DPR, linkMax2 = linkMax * linkMax;
    ctx.lineWidth = DPR;
    for (let i = 0; i < pts.length; i++) {
      const ax = pts[i].x * w + px, ay = pts[i].y * h + py;
      for (let j = i + 1; j < pts.length; j++) {
        const bx = pts[j].x * w + px, by = pts[j].y * h + py;
        const dx = ax - bx, dy = ay - by, d2 = dx * dx + dy * dy;
        if (d2 < linkMax2) {
          ctx.strokeStyle = 'rgba(255,60,60,' + ((1 - Math.sqrt(d2) / linkMax) * .38).toFixed(3) + ')';
          ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        }
      }
    }
    ctx.fillStyle = 'rgba(255,235,235,.8)';
    for (const p of pts) { ctx.beginPath(); ctx.arc(p.x * w + px, p.y * h + py, p.r * DPR, 0, 6.2832); ctx.fill(); }
  }
  if (reduced) { draw(); return; } // статичный кадр для prefers-reduced-motion
  const step = () => {
    if (!cv.isConnected) {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('resize', onResize);
      if (io) io.disconnect();
      return;
    }
    // вкладка в фоне → rAF и так не тикает; hero за экраном → кадр не рисуем
    if (!onScreen) { requestAnimationFrame(step); return; }
    for (const p of pts) {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x += 1; if (p.x > 1) p.x -= 1;
      if (p.y < 0) p.y += 1; if (p.y > 1) p.y -= 1;
    }
    draw();
    requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
function renderFooter() {
  const slot = document.getElementById('footer-slot');
  if (!slot) return;
  slot.innerHTML = `
    <footer class="site-footer">
      <div class="footer-inner">
        <div class="footer-col footer-brand">
          <div class="footer-logo">
            <span class="footer-mark">(◣ _ ◢)</span>
            <span class="footer-title">+W.TECH <b>FORUM</b></span>
          </div>
          <p class="footer-tag">Fast. Undetected. The community-powered loader for CS:GO.</p>
        </div>
        <div class="footer-col">
          <h4>Community</h4>
          <a href="#/home">Home</a>
          <a href="#/forum">Forum</a>
          <a href="#/tickets">Support tickets</a>
          <a href="#/downloads">Downloads</a>
          <a href="#/rules">Rules</a>
        </div>
        <div class="footer-col">
          <h4>Account</h4>
          ${state.user
            ? `<a href="#/profile/${encodeURIComponent(state.user.username)}">My profile</a>
               <a href="#/dm">Direct messages</a>
               <a href="#" data-action="logout">Log out</a>`
            : `<a href="#" data-action="login">Log in</a>
               <a href="#" data-action="register">Sign up</a>`}
        </div>
        <div class="footer-col">
          <h4>Follow</h4>
          <a href="https://t.me/" target="_blank" rel="noopener noreferrer">Telegram</a>
          <a href="https://discord.com/" target="_blank" rel="noopener noreferrer">Discord</a>
          <a href="https://youtube.com/" target="_blank" rel="noopener noreferrer">YouTube</a>
        </div>
      </div>
      <div class="footer-bottom">
        <span>&copy; ${new Date().getFullYear()} +W.TECH FORUM. All rights reserved.</span>
        <span class="footer-meta">Made with <span style="color:var(--accent)">♥</span> by the community</span>
      </div>
    </footer>`;
}
function clearFooter() {
  const slot = document.getElementById('footer-slot');
  if (slot) slot.innerHTML = '';
}
/* ---------------- Support tickets (UI) ---------------- */
// Moderation level on the client (owner / admin / moderator) — mirrors the
// server's is_mod(). Server-side checks still enforce everything.
function isStaffClient() { return !!(state.user && ['owner', 'admin', 'moderator'].includes(state.user.role)); }
function statusIcon(s) { return s === 'closed' ? '🔒' : (s === 'answered' ? '💬' : '🎫'); }
function ticketRowHTML(t, staff) {
  const a = t.author;
  return `<a class="trow ticket-row" href="#/ticket/${t.id}">
    <span class="tpin">${statusIcon(t.status)}</span>
    <span class="ttitle">${esc(t.subject)} <span class="ticket-cat">#${esc(t.category)}</span></span>
    <span class="tmeta">${staff && a ? `<span class="tauthor" style="color:${esc(nameColor(a))}">${esc(a.username)}</span> · ` : ''}<span class="ticket-status st-${esc(t.status)}">${esc(t.status)}</span> · ${t.replies} repl. · ${timeStr(t.updatedAt)}</span>
  </a>`;
}
function replyHTML(r) {
  const a = r.author || {};
  return `<div class="tk-reply ${r.staff ? 'tk-staff' : ''}">
    <div class="tk-reply-head">
      <span class="tauthor" style="color:${esc(nameColor(a))}">${esc(a.username || '?')}</span>
      ${r.staff ? `<span class="tag tag-${esc(a.role || 'member')}">${esc(a.role || '')}</span>` : ''}
      <span class="muted tk-time">${timeStr(r.createdAt)}</span>
    </div>
    <div class="tk-reply-body">${formatPostContent(r.content)}</div>
  </div>`;
}
async function renderTickets(app) {
  if (!state.user) { app.innerHTML = '<p class="notice">Please <a href="#" data-action="login" style="color:var(--accent-2)">log in</a> to view tickets.</p>'; return; }
  let data;
  try { data = await API.ticketList(); } catch (e) { app.innerHTML = '<div class="error">' + esc(e.message) + '</div>'; return; }
  const tickets = data.tickets || [];
  const staff = !!data.staff;
  app.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;flex-wrap:wrap">
      <h1 style="margin:0">Support Tickets</h1>
      <a class="btn btn-accent" href="#/newticket">+ New ticket</a>
    </div>
    ${tickets.length ? `<div class="ticket-list">${tickets.map(t => ticketRowHTML(t, staff)).join('')}</div>` : '<p class="notice">No tickets yet. Create one if you need help.</p>'}`;
  emojiParse(app);
}
async function renderTicket(app, id) {
  if (!state.user) { app.innerHTML = '<p class="notice">Please <a href="#" data-action="login" style="color:var(--accent-2)">log in</a>.</p>'; return; }
  let data;
  try { data = await API.ticketView(id); } catch (e) { app.innerHTML = '<div class="error">' + esc(e.message) + '</div>'; return; }
  const t = data.ticket; const staff = !!data.staff;
  const isOwner = !!(state.user && t.author && state.user.username === t.author.username);
  const closed = t.status === 'closed';
  const canReply = staff || (isOwner && !closed);
  app.innerHTML = `
    <div class="breadcrumb"><a href="#/tickets">Tickets</a> › <span>#${t.id} · ${esc(t.subject)}</span></div>
    <div class="ticket-head">
      <h1 style="margin:0 0 6px">${esc(t.subject)}</h1>
      <div class="ticket-meta">
        <span class="ticket-status st-${esc(t.status)}">${esc(t.status)}</span>
        <span class="ticket-cat">#${esc(t.category)}</span>
        <span class="muted">by <b style="color:${esc(nameColor(t.author))}">${esc(t.author.username)}</b> · ${timeStr(t.createdAt)}</span>
      </div>
      <div class="ticket-actions">
        ${staff ? `<select class="tk-status" id="tk-status">
            <option value="open" ${t.status === 'open' ? 'selected' : ''}>open</option>
            <option value="answered" ${t.status === 'answered' ? 'selected' : ''}>answered</option>
            <option value="closed" ${t.status === 'closed' ? 'selected' : ''}>closed</option>
          </select>` : ''}
        ${staff ? `<button class="btn btn-danger" id="tk-delete">Delete</button>` : ''}
      </div>
    </div>
    <div class="ticket-replies" id="tk-replies">${data.replies.map(r => replyHTML(r)).join('')}</div>
    ${canReply ? `<div class="reply-box"><textarea id="tk-reply" placeholder="Write a reply…"></textarea><button class="btn btn-accent" id="tk-send">Send reply</button></div>` : '<p class="notice">This ticket is closed. Only staff can reply.</p>'}`;
  emojiParse(app);
  const repliesEl = document.getElementById('tk-replies');
  if (repliesEl) repliesEl.scrollTop = repliesEl.scrollHeight;
  const sendBtn = document.getElementById('tk-send');
  if (sendBtn) sendBtn.onclick = async () => {
    const ta = document.getElementById('tk-reply'); const v = ta.value.trim();
    if (!v) { toast('Write a reply', 'warn'); return; }
    sendBtn.disabled = true;
    try { await API.ticketReply(id, v); renderTicket(app, id); }
    catch (e) { toast(e.message, 'error'); sendBtn.disabled = false; }
  };
  const sel = document.getElementById('tk-status');
  if (sel) sel.onchange = async () => {
    try { await API.ticketStatus(id, sel.value); renderTicket(app, id); }
    catch (e) { toast(e.message, 'error'); renderTicket(app, id); }
  };
  const del = document.getElementById('tk-delete');
  if (del) del.onclick = async () => {
    const ok = await wtechConfirm('Delete this ticket and all its replies? This cannot be undone.', { title: 'Delete ticket', okText: 'Delete' });
    if (!ok) return;
    try { await API.ticketDelete(id); toast('Ticket deleted', 'success'); location.hash = '#/tickets'; }
    catch (e) { toast(e.message, 'error'); }
  };
}
async function renderNewTicket(app) {
  if (!state.user) { app.innerHTML = '<p class="notice">Please <a href="#" data-action="login" style="color:var(--accent-2)">log in</a>.</p>'; return; }
  const cats = [['general', 'General question'], ['bug', 'Bug / crash report'], ['billing', 'Billing / purchase'], ['account', 'Account / ban appeal'], ['other', 'Other']];
  app.innerHTML = `
    <div class="breadcrumb"><a href="#/tickets">Tickets</a> › <span>New ticket</span></div>
    <h1>New support ticket</h1>
    <div class="form card">
      <label>Category</label>
      <select id="ntk-cat">${cats.map(c => `<option value="${c[0]}">${esc(c[1])}</option>`).join('')}</select>
      <label>Subject</label><input id="ntk-subject" maxlength="160" placeholder="Short summary of your issue">
      <label>Message</label><textarea id="ntk-content" maxlength="5000" placeholder="Describe your issue in detail…"></textarea>
      <button class="btn btn-accent" id="ntk-send">Create ticket</button>
    </div>`;
  document.getElementById('ntk-send').onclick = async () => {
    const subject = document.getElementById('ntk-subject').value.trim();
    const content = document.getElementById('ntk-content').value.trim();
    const category = document.getElementById('ntk-cat').value;
    if (!subject) { toast('Subject is required', 'warn'); return; }
    if (!content) { toast('Message is required', 'warn'); return; }
    const btn = document.getElementById('ntk-send'); btn.disabled = true;
    try { const r = await API.ticketCreate({ subject, content, category }); location.hash = '#/ticket/' + r.id; }
    catch (e) { toast(e.message, 'error'); btn.disabled = false; }
  };
}

async function renderForum(app) {
  const cats = await API.categories();
  app.innerHTML = `<h1>Forum</h1>
    <div class="forum-searchbar">
      <input id="forum-search-input" placeholder="Search threads and posts…" maxlength="80" autocomplete="off">
      <button class="btn btn-accent" id="forum-search-btn" type="button">Search</button>
    </div>
    <div class="cat-grid">${cats.categories.map(catCard).join('')}</div>`;
  const fsGo = () => { location.hash = '#/search?q=' + encodeURIComponent((document.getElementById('forum-search-input').value || '').trim()); };
  const fsBtn = document.getElementById('forum-search-btn'); if (fsBtn) fsBtn.onclick = fsGo;
  const fsInp = document.getElementById('forum-search-input');
  if (fsInp) fsInp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); fsGo(); } });
  emojiParse(app);
}
async function renderCategory(app, catId, q) {
  const [catRes, threadsRes] = await Promise.all([API.categories(), API.threads({ category: catId, page: q.page || 1 })]);
  const cat = (catRes.categories.find(c => c.id === catId)) || { name: 'Unknown', description: '' };
  const t = threadsRes;
  app.innerHTML = `
    <div class="breadcrumb"><a href="#/forum">Forum</a> › <span>${esc(cat.name)}</span></div>
    <div class="cat-head" style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px">
      <div><h1 style="margin:0">${esc(cat.name)}</h1><p class="muted" style="margin:0">${esc(cat.description)}</p></div>
      ${state.user ? `<a class="btn btn-accent" href="#/new?cat=${encodeURIComponent(catId)}">+ New Thread</a>` : ''}
    </div>
    <div class="thread-list">${t.threads.length ? t.threads.map(threadRow).join('') : '<p class="notice">No threads yet. Be the first!</p>'}</div>
    ${pager(t, '#/category/' + encodeURIComponent(catId) + '?page=')}`;
  emojiParse(app);
}
async function renderThread(app, id) {
  const data = await API.thread(id);
  mentionRolesMerge(data.mentionRoles); // раскраска @упоминаний до рендера постов
  const t = data.thread;
  // Pin / lock / delete are moderation actions: owner, admin AND moderator.
  const isAdmin = state.user && ['owner', 'admin', 'moderator'].includes(state.user.role);
  const canReply = state.user && !t.locked && !state.user.banned;
  app.innerHTML = `
    <div class="breadcrumb"><a href="#/forum">Forum</a> › <a href="#/category/${t.categoryId}">${esc(t.category ? t.category.name : 'Category')}</a> › <span>${esc(t.title)}</span></div>
    <div class="thread-head">
      <h1>${esc(t.title)} ${t.pinned ? '<span class="badge">PINNED</span>' : ''} ${t.locked ? '<span class="badge badge-lock">LOCKED</span>' : ''}</h1>
      <div class="thread-actions">
        ${canReply ? '<button class="btn" id="reply-jump">Reply</button>' : ''}
        ${isAdmin ? `<button class="btn" data-act="pin" data-id="${t.id}">${t.pinned ? 'Unpin' : 'Pin'}</button>
          <button class="btn" data-act="lock" data-id="${t.id}">${t.locked ? 'Unlock' : 'Lock'}</button>
          <button class="btn btn-danger" data-act="delete" data-id="${t.id}">Delete</button>` : ''}
      </div>
    </div>
    <div class="posts">${data.posts.map(postRow).join('')}</div>
    ${canReply ? `<div class="reply-box" id="replybox">
        <textarea id="reply-content" placeholder="Write your reply…" maxlength="5000"></textarea>
        ${attachmentPickersHTML()}
        <button class="btn btn-accent" id="reply-send">Post reply</button>
      </div>` : (t.locked ? '<p class="notice">🔒 This thread is locked.</p>' : (state.user ? '' : '<p class="notice">Please <a href="#" data-action="login" style="color:var(--accent-2)">log in</a> to reply.</p>'))}`;
  if (canReply) {
    const pending = [];
    wireAttachment(app, pending);
    const send = async () => {
      const content = document.getElementById('reply-content').value;
      if (!content.trim() && pending.length === 0) { toast('Write something or attach a file', 'warn'); return; }
      if (pending.some(p => p.uploading)) { toast('Still uploading attachments…', 'warn'); return; }
      const replySend = document.getElementById('reply-send');
      replySend.disabled = true;
      try {
        const r = await API.createPost(id, content, pendingAttachments(pending));
        mentionRolesMerge(r && r.mentionRoles);
        toast('Reply posted', 'success');
        // Do NOT reload the whole page here: a full reload starts the global
        // preloader again. Re-render the thread through the SPA router instead,
        // so the new reply appears immediately without launching the preloader.
        await renderThread(app, id);
        const box = document.getElementById('replybox');
        if (box) box.scrollIntoView({ behavior: 'smooth', block: 'end' });
      }
      catch (e) { toast(e.message, 'error'); replySend.disabled = false; }
    };
    document.getElementById('reply-send').onclick = send;
    const jump = document.getElementById('reply-jump'); if (jump) jump.onclick = () => document.getElementById('replybox').scrollIntoView({ behavior: 'smooth' });
  }
  app.querySelectorAll('[data-act]').forEach(btn => {
    btn.onclick = async () => {
      const act = btn.getAttribute('data-act'); const tid = btn.getAttribute('data-id');
      try {
        if (act === 'pin') await API.pin(tid);
        if (act === 'lock') await API.lock(tid);
        if (act === 'delete') { const ok = await wtechConfirm('Delete this thread? This cannot be undone.', { title: 'Delete thread', okText: 'Delete' }); if (!ok) return; await API.delThread(tid); location.hash = '#/forum'; return; }
        await renderThread(app, id);
      } catch (e) { toast(e.message, 'error'); }
    };
  });
  emojiParse(app);
}
async function renderNewThread(app, cat) {
  const cats = await API.categories();
  if (!state.user) { app.innerHTML = '<p class="notice">Please <a href="#" data-action="login" style="color:var(--accent-2)">log in</a> to create a thread.</p>'; return; }
  // The category is fixed automatically to wherever the "+ New Thread" button
  // was pressed (the ?cat= param) — there is no manual picker anymore. If
  // someone lands on #/new with no category at all, fall back to the first one.
  const target = (cats.categories.find(c => c.id === cat)) || cats.categories[0];
  if (!target) { app.innerHTML = '<p class="notice">No categories available.</p>'; return; }
  const categoryId = target.id;
  app.innerHTML = `
    <h1>New Thread</h1>
    <div class="form card">
      <div class="muted" style="margin:0 0 14px">📁 Posting to <b style="color:var(--text)">${esc(target.name)}</b></div>
      <label>Title</label><input id="nt-title" maxlength="120" placeholder="A descriptive title">
      <label>Content</label><textarea id="nt-content" maxlength="5000" placeholder="Write your post…"></textarea>
      ${attachmentPickersHTML()}
      <button class="btn btn-accent" id="nt-submit">Create thread</button>
    </div>`;
  emojiParse(app);
  const pending = [];
  wireAttachment(app, pending);
  document.getElementById('nt-submit').onclick = async () => {
    const content = document.getElementById('nt-content').value;
    if (!content.trim() && pending.length === 0) { toast('Write something or attach a file', 'warn'); return; }
    if (pending.some(p => p.uploading)) { toast('Still uploading attachments…', 'warn'); return; }
    const btn = document.getElementById('nt-submit'); btn.disabled = true;
    try { const r = await API.createThread({ categoryId, title: document.getElementById('nt-title').value, content, attachments: pendingAttachments(pending) }); location.hash = '#/thread/' + r.thread.id; }
    catch (e) { toast(e.message, 'error'); btn.disabled = false; }
  };
}
async function renderProfile(app, username) {
  // No username segment at all (bare "#/profile") — nothing to look up.
  if (!username) { location.hash = '#/'; return; }
  let data = null;
  try {
    data = await API.profile(username);
  } catch (e) {
    // Unknown/bot name (e.g. "Антиспам"): show a real "not found" page instead
    // of throwing into the router's bare error text. That bare error left the
    // content column almost empty, and since the chat panel mirrors the
    // content height, the whole page looked broken ("only a dead chat").
    app.innerHTML = `<div class="card form" style="max-width:520px;margin:48px auto;text-align:center">
      <div style="font-size:44px;line-height:1">🔍</div>
      <h1 style="margin:12px 0 8px">User not found</h1>
      <p class="muted" style="margin:0">There is no profile for «${esc(String(username))}». The account may not exist, or there is a typo in the name.</p>
      <p style="margin:18px 0 0"><a class="btn btn-accent" href="#/">← Back to home</a></p>
    </div>`;
    return;
  }
  const u = data.user;
  const own = state.user && state.user.username === username;
  // Avatar is display-only on the profile page — changing it (and everything
  // else) lives in the "Edit profile" modal and applies only via Save.
  const avatarBlock = avatarHTML(u, 'avatar xl');
  const bg = safeUrl(u.profileBg);
  app.innerHTML = `
    ${bg ? `<div class="profile-cover" style="background-image:url('${esc(bg)}')"></div>` : ''}
    <div class="profile-head${bg ? ' has-cover' : ''}">
      ${avatarBlock}
      <div class="profile-meta">
        <h1><span class="pname-colored" style="color:${esc(nameColor(u))}">${esc(u.username)}</span> <span class="tag tag-${u.role}">${esc(u.role)}</span></h1>
        ${u.banned ? '<span class="badge badge-ban">BANNED</span>' : ''}
        <p class="muted">Joined ${dateStr(u.joined_at)} · ${data.postCount} posts</p>
        ${u.status ? `<p class="profile-status">${esc(u.status)}</p>` : ''}
        ${u.bio ? `<p class="profile-bio">${esc(u.bio)}</p>` : ''}
        ${profileLinksHTML(u)}
        <div class="profile-actions">
          ${own ? `<button class="btn" id="edit-profile">✎ Edit profile</button>` : ''}
          ${!own && state.user ? `<button class="btn" id="dm-start">✉ Send message</button>` : ''}
        </div>
      </div>
    </div>
    <h2>Threads by ${esc(u.username)}</h2>
    <div class="thread-list">${data.threads.map(threadRow).join('') || '<p class="notice">No threads yet.</p>'}</div>`;
  emojiParse(app);
  const editBtn = document.getElementById('edit-profile');
  if (editBtn) editBtn.onclick = () => showProfileEditor(u);
  const dmStart = document.getElementById('dm-start');
  if (dmStart) dmStart.onclick = () => { location.hash = '#/dm/' + encodeURIComponent(username); };
}

// Profile customization modal: avatar, nickname color (custom rail picker),
// status, background (upload from PC), social links, animated avatar border.
// NOTHING is applied until "Save changes" — every edit is staged locally and
// shown only in the modal's live preview.
function showProfileEditor(u) {
  const root = document.getElementById('modal');
  const cur = state.user || u;
  // Username changes are an owner/admin privilege (enforced again server-side).
  const canRename = ['owner', 'admin'].includes((state.user && state.user.role) || cur.role || '');
  // ---- staged state (applied only via Save) ----
  let hs = hexToHsl(cur.color || '#ff3232');
  let curHex = /^#[0-9a-fA-F]{6}$/.test(cur.color || '') ? cur.color : '#ff3232';
  let selectedBorder = (cur.avatarBorder || 'none');
  let stagedAvatarUrl = null;   // data-URL used to preview a staged File
  let stagedAv = null;          // null = untouched | 'remove' | File | '/assets/preset-avatars/…'
  let stagedBg, stagedBgUrl; // undefined = untouched | '' = remove | File = upload

  root.innerHTML = `
    <div class="modal-backdrop" data-close="1"></div>
    <div class="modal profile-editor">
      <div class="modal-head"><h3>Edit profile</h3><button class="modal-x" data-close="1">✕</button></div>
      <div class="modal-body form">
        <label>Avatar</label>
        <div class="pe-av">
          <span id="pe-av-view" class="pe-av-view"></span>
          <div class="pe-av-btns">
            <label class="btn pe-av-pick" title="Upload avatar from your PC">📁 Choose<input type="file" id="pe-av-file" accept="image/png,image/jpeg,image/gif,image/webp" hidden></label>
            <button type="button" class="btn" id="pe-av-del">Remove</button>
          </div>
          <small class="muted">JPG/PNG/GIF/WEBP, max 2 MB · staged until Save</small>
          <div class="pe-av-presets">${PRESET_AVATARS.map(p => `<button type="button" class="pe-av-opt" data-preset="${p}" title="Use this avatar" style="background-image:url('${p}')"></button>`).join('')}</div>
        </div>
        ${canRename ? `<label>Username <small class="muted">(owner/admin · 3–20: A–Z, 0–9, . _ -)</small></label>
        <input id="pe-username" maxlength="20" autocomplete="off" value="${esc(cur.username)}">` : ''}
        <label>Nickname color</label>
        <div class="cp-rails">
          <div class="cp-rail cp-hue" id="pe-hue"><span class="cp-thumb" id="pe-hue-t"></span></div>
          <div class="cp-rail cp-light" id="pe-light"><span class="cp-thumb" id="pe-light-t"></span></div>
          <div class="cp-railmeta"><span class="cp-dot" id="pe-color-chip"></span><b class="cp-hex" id="pe-color-val"></b></div>
        </div>
        <div class="pe-nickprev">
          <span class="muted pe-nickprev-l">Preview — that is how your posts will look</span>
          <div class="pe-nickprev-post">
            <span id="pe-nickprev-av"></span>
            <span class="pe-nickprev-meta">
              <b class="pe-nickprev-name" id="pe-nickprev-name">${esc(cur.username)}</b>
              <span class="tag tag-${esc(cur.role || 'member')}">${esc(cur.role || 'member')}</span>
              <small class="muted">· just now</small>
            </span>
          </div>
        </div>
        <label>Status <small class="muted">(max 80)</small></label>
        <input id="pe-status" maxlength="80" placeholder="What's on your mind?" value="${esc(cur.status || '')}">
        <label>Profile background <small class="muted">(image from your PC · JPG/PNG/GIF/WEBP, max 8 MB)</small></label>
        <div class="pe-bg">
          <div class="pe-bg-view" id="pe-bg-view"></div>
          <div class="pe-bg-btns">
            <label class="btn pe-bg-pick" title="Upload a background from your PC">📁 Choose image<input type="file" id="pe-bg-file" accept="image/png,image/jpeg,image/gif,image/webp" hidden></label>
            <button type="button" class="btn" id="pe-bg-del">Remove</button>
          </div>
          <small class="muted">staged until Save</small>
        </div>
        <label>YouTube</label><input id="pe-yt" placeholder="https://youtube.com/…" value="${esc(cur.linkYoutube || '')}">
        <label>Discord</label><input id="pe-disc" placeholder="https://discord.gg/…" value="${esc(cur.linkDiscord || '')}">
        <label>Telegram</label><input id="pe-tg" placeholder="https://t.me/…" value="${esc(cur.linkTelegram || '')}">
        <label>Avatar border</label>
        <div class="border-picker" id="pe-borders">
          ${BORDER_KEYS.map(k => `<button type="button" class="border-swatch av-border b-${k}" data-border="${k}" title="${k}"><span class="swatch-inner">${k === 'none' ? '✕' : ''}</span></button>`).join('')}
        </div>
        <button class="btn btn-accent" id="pe-save">Save changes</button>
      </div>
    </div>`;
  root.style.display = 'flex';
  const close = () => { root.style.display = 'none'; root.innerHTML = ''; };
  root.querySelectorAll('[data-close]').forEach(el => el.onclick = close);

  // ---------- live preview (modal-only until Save) ----------
  const nickPrevName = root.querySelector('#pe-nickprev-name');
  const fakeUser = () => ({
    username: cur.username, role: cur.role,
    color: curHex,
    avatar: (stagedAv instanceof File) ? stagedAvatarUrl : (stagedAv === 'remove' ? null : (stagedAv || cur.avatar)),
    avatarBorder: selectedBorder,
  });
  function paintAvatar() {
    // Пересоздаёт DOM только при смене аватара/рамки — НЕ во время драга рельс.
    const host = root.querySelector('#pe-nickprev-av');
    if (host) host.innerHTML = avatarHTML(fakeUser(), 'avatar');
    const avv = root.querySelector('#pe-av-view');
    if (avv) avv.innerHTML = avatarHTML(fakeUser(), 'avatar xl');
  }
  function paintName() {
    // Быстрый путь для драга колорпикера: цвет ника и кружок-инициал меняем
    // через --fillc/стиль напрямую — узлы аватаров (с анимированными рамками)
    // не пересоздаются → модалка не дёргается.
    if (nickPrevName) nickPrevName.style.color = curHex;
    root.querySelectorAll('#pe-nickprev-av .avatar, #pe-av-view .avatar').forEach(a2 => {
      if (!String(a2.style.getPropertyValue('--fillc')).startsWith('url(')) a2.style.setProperty('--fillc', curHex);
    });
  }
  function paintPreview() { paintAvatar(); paintName(); }

  // ---------- custom color rails (hue + lightness) ----------
  const hueRail = root.querySelector('#pe-hue'), hueT = root.querySelector('#pe-hue-t');
  const lightRail = root.querySelector('#pe-light'), lightT = root.querySelector('#pe-light-t');
  const chip = root.querySelector('#pe-color-chip'), hexLbl = root.querySelector('#pe-color-val');
  function paintRails() {
    hueT.style.left = (hs.h / 360 * 100) + '%'; hueT.style.background = `hsl(${hs.h},85%,55%)`;
    lightT.style.left = (hs.l * 100) + '%'; lightT.style.background = curHex;
    lightRail.style.background = `linear-gradient(90deg,#000, hsl(${hs.h},${Math.max(hs.s, .45) * 100}%,52%), #fff)`;
    chip.style.background = curHex;
    hexLbl.textContent = curHex.toUpperCase();
  }
  const recalcHex = () => { hs.l = Math.min(.88, Math.max(.12, hs.l)); curHex = hslToHex(hs.h, hs.s, hs.l); };
  function railDrag(rail, onPct) {
    rail.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const go = (ev) => { const r = rail.getBoundingClientRect(); onPct(Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width))); };
      go(e);
      const mv = (ev) => go(ev);
      const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); };
      addEventListener('pointermove', mv); addEventListener('pointerup', up);
    });
  }
  railDrag(hueRail, (p) => { hs.h = Math.round(p * 359); if (hs.s < .35) hs.s = .85; recalcHex(); paintRails(); paintName(); });
  railDrag(lightRail, (p) => { hs.l = p; recalcHex(); paintRails(); paintName(); });

  // ---------- avatar staging (applied on Save) ----------
  const avFile = root.querySelector('#pe-av-file');
  const presetBtns = root.querySelectorAll('.pe-av-opt');
  const paintPresetSel = () => presetBtns.forEach(b => b.classList.toggle('sel', (stagedAv || cur.avatar) === b.dataset.preset));
  avFile.onchange = () => {
    const f = avFile.files[0]; avFile.value = '';
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) { toast('Avatar too large (max 2 MB)', 'error'); return; }
    stagedAv = f;
    const rd = new FileReader();
    rd.onload = () => { stagedAvatarUrl = String(rd.result || ''); paintPreview(); paintPresetSel(); };
    rd.readAsDataURL(f);
  };
  root.querySelector('#pe-av-del').onclick = () => { stagedAv = 'remove'; stagedAvatarUrl = null; paintPreview(); paintPresetSel(); };
  presetBtns.forEach(b => b.onclick = () => { stagedAv = b.dataset.preset; stagedAvatarUrl = null; paintPreview(); paintPresetSel(); });
  paintPresetSel(); // pre-marks the thumb if the current avatar is already a preset

  // Живое превью будущего ника (owner/admin) — пока только текст предпросмотра,
  // сам Save решает, менять ли ник по-настоящему.
  const unameLive = root.querySelector('#pe-username');
  if (unameLive) unameLive.addEventListener('input', () => { nickPrevName.textContent = unameLive.value.trim() || cur.username; });

  // ---------- background staging (applied on Save) ----------
  const bgView = root.querySelector('#pe-bg-view');
  function paintBg() {
    const v = stagedBg instanceof File ? stagedBgUrl : (stagedBg === '' ? null : (cur.profileBg || null));
    bgView.innerHTML = v ? `<div class="pe-bg-fill" style="background-image:url('${v}')"></div>` : '<span class="muted">No background yet</span>';
  }
  const bgFile = root.querySelector('#pe-bg-file');
  bgFile.onchange = () => {
    const f = bgFile.files[0]; bgFile.value = '';
    if (!f) return;
    if (f.size > 8 * 1024 * 1024) { toast('Image too large (max 8 MB)', 'error'); return; }
    stagedBg = f;
    const rd = new FileReader();
    rd.onload = () => { stagedBgUrl = String(rd.result || ''); paintBg(); };
    rd.readAsDataURL(f);
  };
  root.querySelector('#pe-bg-del').onclick = () => { stagedBg = ''; stagedBgUrl = null; paintBg(); };

  // ---------- border swatches (incl. the new animated ones) ----------
  const swatches = root.querySelectorAll('.border-swatch');
  function paintSwatches() { swatches.forEach(s2 => s2.classList.toggle('selected', s2.dataset.border === selectedBorder)); }
  swatches.forEach(s2 => s2.onclick = () => { selectedBorder = s2.dataset.border; paintSwatches(); paintPreview(); });

  paintRails(); paintPreview(); paintSwatches(); paintBg();

  // ---------- Save: the ONLY place changes get applied ----------
  root.querySelector('#pe-save').onclick = async () => {
    const btn = root.querySelector('#pe-save'); btn.disabled = true;
    const unameInp = root.querySelector('#pe-username');
    try {
      if (stagedAv instanceof File) { const fd = new FormData(); fd.append('avatar', stagedAv); await API.avatarUpload(fd); }
      else if (stagedAv === 'remove') { await API.avatarRemove(); }
      if (stagedBg instanceof File) { const fd = new FormData(); fd.append('file', stagedBg); await API.profileBgUpload(fd); }
      const payload = {
        color: curHex,
        status: root.querySelector('#pe-status').value,
        avatarBorder: selectedBorder,
        linkYoutube: root.querySelector('#pe-yt').value,
        linkDiscord: root.querySelector('#pe-disc').value,
        linkTelegram: root.querySelector('#pe-tg').value,
      };
      if (stagedBg === '') payload.profile_bg = '';
      if (typeof stagedAv === 'string' && stagedAv !== 'remove') payload.avatarPreset = stagedAv.split('/').pop();
      if (unameInp && unameInp.value.trim() && unameInp.value.trim() !== cur.username) payload.username = unameInp.value.trim();
      const r = await API.profileUpdate(payload);
      if (state.user && state.user.id === r.user.id) { state.user = Object.assign({}, state.user, r.user); updateAuth(); }
      if (payload.username) { try { localStorage.setItem('wtech_last_user', r.user.username); } catch (e2) {} }
      if (window.initChat) window.initChat();
      close();
      toast('Profile updated', 'success');
      if (payload.username && location.hash.indexOf('#/profile/') === 0) location.hash = '#/profile/' + encodeURIComponent(r.user.username);
      else renderProfile(document.getElementById('app'), r.user.username);
    } catch (e) { toast(e.message, 'error'); btn.disabled = false; }
  };
}

async function renderDownloads(app) {
  // Page gate: only customers (+ owner/admin) may even SEE the download card.
  // The file itself is additionally enforced server-side: the direct URL is
  // Apache-denied and /api.php?action=download_loader re-checks the role.
  if (!canDownload(state.user)) {
    app.innerHTML = `<h1>Downloads</h1>
      <div class="card"><p class="notice">🔒 The loader is available to <b>customers</b> only.<br>
      Once the staff grants your account the <span class="tag tag-customer">customer</span> role, this page unlocks and the Downloads link appears in the top menu.</p></div>`;
    return;
  }
  const dl = API.mode === 'node' ? '/downloads/loader.lua' : '/api.php?action=download_loader';

  // Latest loader changelog: the newest "Changelog" thread from the Releases
  // category — its first post IS the changelog shown here (instead of the old
  // generic Installation card). Optional: any failure just hides the block.
  let changelog = null;
  try {
    const rel = await API.threads({ category: 'releases', page: 1 });
    const list = (rel.threads || []).slice().sort((a, b) => b.createdAt - a.createdAt);
    const pick = list.find(t => /changelog/i.test(t.title)) || list[0];
    if (pick) {
      const full = await API.thread(pick.id);
      const post0 = (full.posts || [])[0];
      if (post0) changelog = { id: full.thread.id, title: full.thread.title, content: post0.content, author: post0.author, when: post0.createdAt };
    }
  } catch (e) { /* never let a missing changelog break the downloads card */ }

  // Version badge stays in sync too: read "v2.4.1" straight from the changelog
  // thread title, fall back to the hard-coded one when nothing is found.
  const verMatch = changelog ? /v?([\d]+\.[\d.]+)/.exec(changelog.title) : null;
  const ver = verMatch ? verMatch[1] : '2.4.1';

  app.innerHTML = `<h1>Downloads</h1>
    <div class="card download-card">
      <div class="dl-icon">⬇️</div>
      <div class="dl-info">
        <h2>+W.TECH LOADER <span class="badge">v${esc(ver)}</span></h2>
        <p>Best CS:GO loader. Requires GameSense</p>
        <p class="muted">Updated recently · 🔒 uniquely obfuscated on every download</p>
        <a class="btn btn-accent" href="${dl}" download>Download .lua</a>
      </div>
    </div>
    ${changelog ? `
    <div class="card cl-card">
      <h2>📝 Latest changelog</h2>
      <h3 class="cl-title"><a href="#/thread/${changelog.id}">${esc(changelog.title)}</a></h3>
      <div class="cl-meta muted">${esc((changelog.author && changelog.author.username) || 'unknown')} · ${timeStr(changelog.when)}</div>
      <div class="post-content cl-body">${formatPostContent(changelog.content)}</div>
      <div class="cl-footer">
        <a class="btn" href="#/thread/${changelog.id}">Open thread &amp; replies</a>
        <a class="btn" href="#/category/releases">All releases</a>
      </div>
    </div>` : `
    <div class="card"><p class="notice">📝 No changelog posted yet — check the <a href="#/category/releases" style="color:var(--accent-2)">Releases</a> section.</p></div>`}`;
  emojiParse(app);
}
function renderRules(app) {
  app.innerHTML = `<h1>Rules & Guidelines</h1>
    <div class="card"><ol class="steps">
      <li>No selling or trading of accounts, cheats, or bypasses.</li>
      <li>Keep it legal — no malware, ratting, or credential theft.</li>
      <li>Be respectful. No harassment, racism, or hate speech.</li>
      <li>No spam, advertising, or referral links.</li>
      <li>Share configs and clips in Showcase.</li>
      <li>Support questions go in Help & Support.</li>
      <li>Staff decisions are final. Bans can be appealed via the owner.</li>
    </ol></div>`;
}
async function renderSearch(app, q) {
  let html = `<h1>Search</h1>
    <div class="card form">
      <input id="search-input" value="${esc(q || '')}" placeholder="Search threads and posts…">
      <button class="btn btn-accent" id="search-btn">Search</button>
    </div>`;
  if (q) {
    try {
      const r = await API.search(q);
      html += `<div class="thread-list">${r.threads.length ? r.threads.map(threadRow).join('') : '<p class="notice">No results.</p>'}</div>`;
    } catch (e) { html += '<p class="notice">' + esc(e.message) + '</p>'; }
  }
  app.innerHTML = html;
  const doSearch = () => { location.hash = '#/search?q=' + encodeURIComponent(document.getElementById('search-input').value); };
  const btn = document.getElementById('search-btn'); if (btn) btn.onclick = doSearch;
  const inp = document.getElementById('search-input'); if (inp) inp.addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
}

/* ---------------- Admin panel ---------------- */
function adminRowHTML(u) {
  return `<div class="admin-row">
    <a class="admin-av" href="#/profile/${encodeURIComponent(u.username)}" title="View profile">${avatarHTML(u, 'avatar')}</a>
    <a class="admin-name" href="#/profile/${encodeURIComponent(u.username)}" style="color:${esc(nameColor(u))}">${esc(u.username)}</a>
    <span class="tag tag-${u.role}">${esc(u.role)}</span>
    ${u.banned ? '<span class="badge badge-ban">BANNED</span>' : ''}
    <span class="muted admin-meta">${u.postCount} posts · joined ${dateStr(u.joined_at)}</span>
    <span class="admin-act">
      ${u.role === 'owner'
        ? '<span class="muted admin-prot">protected</span>'
        : `<select class="admin-role" data-role="${esc(u.username)}">
             <option value="member" ${u.role === 'member' ? 'selected' : ''}>Member</option>
             <option value="customer" ${u.role === 'customer' ? 'selected' : ''}>Customer</option>
             <option value="support" ${u.role === 'support' ? 'selected' : ''}>Support</option>
             <option value="moderator" ${u.role === 'moderator' ? 'selected' : ''}>Moderator</option>
             <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
           </select>
           <button class="btn ${u.banned ? '' : 'btn-danger'}" data-ban="${esc(u.username)}" data-willban="${u.banned ? 0 : 1}">${u.banned ? 'Unban' : 'Ban'}</button>`}
    </span>
  </div>`;
}

// Shared loader used by BOTH the corner dropdown and the full #/admin page.
async function loadAdminUsers(listEl, countEl, q) {
  try {
    const r = await API.adminUsers(q || '');
    const users = r.users || [];
    if (countEl) countEl.textContent = users.length + (users.length === 1 ? ' user' : ' users');
    if (!users.length) { listEl.innerHTML = '<p class="notice">No users found.</p>'; return; }
    listEl.innerHTML = users.map(adminRowHTML).join('');
    listEl.querySelectorAll('[data-ban]').forEach(btn => {
      btn.onclick = async () => {
        const name = btn.getAttribute('data-ban');
        // When banning (not unbanning) ask the admin for a reason first.
        if (btn.getAttribute('data-willban') === '1') {
          const reason = await askBanReason(name);
          if (reason === null) return; // cancelled
          btn.disabled = true; btn.textContent = '…';
          try { const r2 = await API.ban(name, reason); toast(name + (r2.banned ? ' banned' : ' unbanned'), 'success'); loadAdminUsers(listEl, countEl, q); }
          catch (e) { toast(e.message, 'error'); loadAdminUsers(listEl, countEl, q); }
          return;
        }
        btn.disabled = true; btn.textContent = '…';
        try { const r2 = await API.ban(name); toast(name + (r2.banned ? ' banned' : ' unbanned'), 'success'); loadAdminUsers(listEl, countEl, q); }
        catch (e) { toast(e.message, 'error'); loadAdminUsers(listEl, countEl, q); }
      };
    });
    listEl.querySelectorAll('select.admin-role').forEach(sel => {
      sel.onchange = async () => {
        const name = sel.getAttribute('data-role');
        const role = sel.value;
        sel.disabled = true;
        try { await API.adminSetRole(name, role); toast(name + ' → ' + role, 'success'); loadAdminUsers(listEl, countEl, q); }
        catch (e) { toast(e.message, 'error'); loadAdminUsers(listEl, countEl, q); }
      };
    });
  } catch (e) {
    listEl.innerHTML = '<p class="error">' + esc(e.message) + '</p>';
  }
}

// Loads the category list into the admin panel with per-row delete buttons.
// Deletion is blocked (button disabled) for categories that still hold threads.
async function loadAdminCategories(listEl) {
  try {
    const r = await API.categories();
    const cats = r.categories || [];
    if (!cats.length) { listEl.innerHTML = '<p class="notice">No categories yet.</p>'; return; }
    listEl.innerHTML = cats.map(c => `
      <div class="admin-row cat-row">
        <span class="cat-icon">${esc(c.icon || '📁')}</span>
        <div class="cat-info">
          <b>${esc(c.name)}</b> <span class="muted">/${esc(c.id)}</span>
          <div class="muted cat-desc">${esc(c.description || '—')}</div>
        </div>
        <span class="muted cat-count">${c.threadCount} thread(s)</span>
        <button class="btn btn-danger" data-catdel="${esc(c.id)}" ${c.threadCount ? 'disabled title="Has threads — move or delete them first"' : ''}>Delete</button>
      </div>`).join('');
    emojiParse(listEl); // colorful category icons in the admin list
    listEl.querySelectorAll('[data-catdel]').forEach(btn => {
      btn.onclick = async () => {
        const id = btn.getAttribute('data-catdel');
        const ok = await wtechConfirm('Delete category "' + id + '"? This cannot be undone.', { title: 'Delete category', okText: 'Delete' });
        if (!ok) return;
        btn.disabled = true; btn.textContent = '…';
        try { await API.categoryDelete(id); toast('Category deleted', 'success'); loadAdminCategories(listEl); }
        catch (e) { toast(e.message, 'error'); loadAdminCategories(listEl); }
      };
    });
  } catch (e) {
    listEl.innerHTML = '<p class="error">' + esc(e.message) + '</p>';
  }
}

/* Preset icons offered when creating a category — rendered as colorful Twemoji
   in the dropdown and (once chosen) everywhere the icon is shown. */
const CATEGORY_ICONS = [
  "📢","🛠️","🎬","💬","🌐","📝","❓","🏆","💡","📌","🔥","⭐","❤️","🚀","🛡️","💎",
  "🎵","✅","⚡","🧩","🗂️","👥","🛒","🧪","🌟","🐶","🐻","🐼","🐯","🦊","🦄","🌹",
  "🌺","🌈","☀️","🌙","❄️","🍀","🌵","🍕","🍔","🍺","☕","🎲","📚","🐛"
];;
let __catIconPop = null;
let __catIconCb = null;
function buildCatIconPop() {
  if (__catIconPop) return __catIconPop;
  const pop = document.createElement('div');
  pop.className = 'emoji-popover cat-icon-pop';
  const grid = document.createElement('div');
  grid.className = 'emoji-grid';
  CATEGORY_ICONS.forEach(ic => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'emoji-cell'; b.textContent = ic;
    b.addEventListener('click', (ev) => {
      ev.preventDefault(); ev.stopPropagation();
      if (__catIconCb) __catIconCb(ic);
      hideCatIconPop();
    });
    grid.appendChild(b);
  });
  pop.appendChild(grid);
  emojiParse(grid);
  document.body.appendChild(pop);
  pop.addEventListener('mousedown', e => e.preventDefault());
  document.addEventListener('click', (ev) => {
    if (!__catIconPop || !__catIconPop.classList.contains('open')) return;
    if (__catIconPop.contains(ev.target)) return;
    if (ev.target.closest('#cat-icon-pick')) return;
    hideCatIconPop();
  });
  __catIconPop = pop;
  return pop;
}
function hideCatIconPop() { if (__catIconPop) __catIconPop.classList.remove('open'); }
function openCatIconPicker(anchor, cb) {
  const pop = buildCatIconPop();
  __catIconCb = cb;
  pop.classList.add('open');
  const r = anchor.getBoundingClientRect();
  let left = r.left;
  if (left + 304 > window.innerWidth) left = window.innerWidth - 304;
  if (left < 8) left = 8;
  pop.style.left = left + 'px';
  pop.style.top = (r.bottom + 8) + 'px';
  pop.style.bottom = 'auto';
}

// Corner dropdown anchored next to the profile chip in the top-right.
function ensureAdminDropdown() {
  let dd = document.getElementById('admin-dropdown');
  if (dd) return dd;
  dd = document.createElement('div');
  dd.id = 'admin-dropdown';
  dd.className = 'admin-dropdown';
  dd.innerHTML = `
    <div class="admin-dropdown-head">
      <span>⚙ Admin Panel</span>
      <button class="admin-dropdown-x" id="admin-dd-close" title="Close">✕</button>
    </div>
    <div class="admin-toolbar">
      <input id="admin-dd-search" class="admin-search" placeholder="Search users by name…" autocomplete="off">
      <span class="muted" id="admin-dd-count"></span>
    </div>
    <div class="admin-list" id="admin-dd-list"><div class="notice">Loading users…</div></div>
    <div class="admin-dropdown-foot"><a href="#/admin" id="admin-dd-full">Open full panel →</a></div>`;
  document.body.appendChild(dd);
  const search = dd.querySelector('#admin-dd-search');
  const list = dd.querySelector('#admin-dd-list');
  const count = dd.querySelector('#admin-dd-count');
  let t;
  search.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => loadAdminUsers(list, count, search.value.trim()), 250); });
  dd.querySelector('#admin-dd-close').onclick = closeAdminDropdown;
  dd.querySelector('#admin-dd-full').addEventListener('click', closeAdminDropdown);
  dd.addEventListener('click', e => e.stopPropagation());
  return dd;
}
function openAdminDropdown() {
  const dd = ensureAdminDropdown();
  dd.classList.add('open');
  const list = dd.querySelector('#admin-dd-list');
  const count = dd.querySelector('#admin-dd-count');
  loadAdminUsers(list, count, '');
  setTimeout(() => dd.querySelector('#admin-dd-search').focus(), 60);
}
function closeAdminDropdown() { const dd = document.getElementById('admin-dropdown'); if (dd) dd.classList.remove('open'); }
function toggleAdminDropdown() { const dd = document.getElementById('admin-dropdown'); if (dd && dd.classList.contains('open')) closeAdminDropdown(); else openAdminDropdown(); }

// Full-page admin view (still reachable via #/admin / "Open full panel").
async function renderAdmin(app) {
  const me = state.user;
  if (!me || !['owner', 'admin'].includes(me.role)) {
    app.innerHTML = '<div class="error">🔒 Admin access only.</div>';
    return;
  }
  app.innerHTML = `
    <h1>Admin Panel</h1>
    <div class="card admin-card">
      <div class="admin-toolbar">
        <input id="admin-search" class="admin-search" placeholder="Search users by name…" autocomplete="off">
        <span class="muted" id="admin-count"></span>
      </div>
      <div class="admin-list" id="admin-list"><div class="notice">Loading users…</div></div>
    </div>
    <div class="card admin-card" style="margin-top:18px">
      <h2 style="margin:0;padding:16px 16px 12px">🗂️ Categories</h2>
      <div class="cat-admin-add">
        <input id="cat-name" class="admin-search" placeholder="Category name *" autocomplete="off" style="flex:2">
        <input id="cat-desc" class="admin-search" placeholder="Description (optional)" autocomplete="off" style="flex:3">
        <button type="button" class="cat-icon-pick" id="cat-icon-pick" title="Choose an icon">
          <span id="cat-icon-val">🗂️</span><span class="cat-icon-pick-caret">▾</span>
        </button>
        <button class="btn btn-accent" id="cat-add" type="button">+ Add</button>
      </div>
      <div class="admin-list" id="admin-cat-list"><div class="notice">Loading categories…</div></div>
    </div>
    <div class="card admin-card" style="margin-top:18px">
      <h2 style="margin:0;padding:16px 16px 0">📦 Loader file</h2>
      <p class="muted" id="loader-cur" style="margin:0;padding:10px 16px">Loading current build info…</p>
      <div class="cat-admin-add loader-row">
        <input type="file" id="loader-file" accept=".lua,.txt" hidden>
        <button class="loader-pick" id="loader-pick" type="button" title="Choose a .lua file">📄 Choose file…</button>
        <span class="loader-file-name" id="loader-name">No file selected</span>
        <button class="btn btn-accent" id="loader-upload" type="button">⬆ Replace loader</button>
      </div>
      <p class="muted" style="margin:8px 0 0;padding:0 16px 16px;font-size:12px">The new .lua is syntax-checked (LuaJIT 5.1 grammar) before it replaces anything; the previous build is backed up automatically. Downloads stay uniquely obfuscated per customer.</p>
    </div>`;
  const listEl = document.getElementById('admin-list');
  const countEl = document.getElementById('admin-count');
  const searchEl = document.getElementById('admin-search');
  let t;
  searchEl.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => loadAdminUsers(listEl, countEl, searchEl.value.trim()), 250); });
  loadAdminUsers(listEl, countEl, '');

  // Categories management (create / delete).
  const catListEl = document.getElementById('admin-cat-list');
  loadAdminCategories(catListEl);

  // Icon chooser — a colorful dropdown of preset icons (instead of free text),
  // so the icon always renders correctly via Twemoji.
  let selectedCatIcon = '🗂️';
  const iconValEl = document.getElementById('cat-icon-val');
  const setCatIcon = (ic) => { selectedCatIcon = ic; iconValEl.textContent = ic; emojiParse(iconValEl); };
  setCatIcon(selectedCatIcon);
  document.getElementById('cat-icon-pick').addEventListener('click', (e) => {
    e.stopPropagation();
    openCatIconPicker(e.currentTarget, setCatIcon);
  });

  document.getElementById('cat-add').onclick = async () => {
    const nameEl = document.getElementById('cat-name');
    const descEl = document.getElementById('cat-desc');
    const name = nameEl.value.trim();
    if (!name) { toast('Category name is required', 'error'); nameEl.focus(); return; }
    const addBtn = document.getElementById('cat-add'); addBtn.disabled = true;
    try {
      await API.categoryCreate({ name: name, description: descEl.value.trim(), icon: selectedCatIcon });
      toast('Category created', 'success');
      nameEl.value = ''; descEl.value = '';
      setCatIcon('🗂️');
      loadAdminCategories(catListEl);
    } catch (e) { toast(e.message, 'error'); }
    finally { addBtn.disabled = false; }
  };

  /* ---- Loader replacement (admin): info + upload + syntax-checked swap ---- */
  const curEl = document.getElementById('loader-cur');
  const fileEl = document.getElementById('loader-file');
  const upBtn = document.getElementById('loader-upload');
  const pickBtn = document.getElementById('loader-pick');
  const nameEl = document.getElementById('loader-name');
  const fmtKB = b => (b / 1024).toFixed(1).replace(/\.0$/, '') + ' KB';
  // The native <input type=file> is hidden; the styled pick button opens it,
  // and the chosen name (+ size) is shown in the readout pill next to it.
  pickBtn.onclick = () => fileEl.click();
  fileEl.addEventListener('change', () => {
    if (fileEl.files && fileEl.files.length) {
      const f = fileEl.files[0];
      nameEl.textContent = f.name + ' (' + fmtKB(f.size) + ')';
      nameEl.title = f.name;
      nameEl.classList.add('has-file');
    } else {
      nameEl.textContent = 'No file selected';
      nameEl.title = '';
      nameEl.classList.remove('has-file');
    }
  });
  async function loadLoaderInfo() {
    try {
      const r = await API.loaderInfo();
      curEl.innerHTML = 'Current: <b>' + esc(r.name || 'loader.lua') + '</b> — ' + fmtKB(r.size)
        + ' · sha1 <code>' + esc(String(r.sha1).slice(0, 12)) + '</code>'
        + ' · updated ' + esc(dateStr(r.mtime))
        + (r.backups ? ' · backups: ' + r.backups : '');
    } catch (e) { curEl.textContent = 'Could not read loader info: ' + e.message; }
  }
  loadLoaderInfo();
  upBtn.onclick = async () => {
    if (!fileEl.files || !fileEl.files.length) { toast('Choose a .lua file first', 'warn'); return; }
    const fd = new FormData();
    fd.append('loader', fileEl.files[0]);
    upBtn.disabled = true; upBtn.textContent = '⏳ Checking & uploading…';
    try {
      const r = await API.loaderReplace(fd);
      toast('Loader replaced — ' + fmtKB(r.size) + ' (sha1 ' + String(r.sha1).slice(0, 8) + '…). Old build backed up.', 'success');
      fileEl.value = '';
      nameEl.textContent = 'No file selected';
      nameEl.title = '';
      nameEl.classList.remove('has-file');
      loadLoaderInfo();
    } catch (e) { toast(e.message, 'error'); }
    finally { upBtn.disabled = false; upBtn.textContent = '⬆ Replace loader'; }
  };
}

/* ---------------- Direct messages ---------------- */
/* ---------------- Voice messages (DM) ---------------- */
// A voice message is stored as a strict marker in the DM text:
//   [[voice:/assets/uploads/<file>|<seconds>]]
// The URL is validated against our uploads path so a crafted marker can never
// inject a foreign/JS url into the player.
const VOICE_RE = /^\[\[voice:(\/assets\/uploads\/[A-Za-z0-9_.\-]+)\|(\d{1,5})\]\]$/;
function parseVoice(content) {
  if (typeof content !== 'string') return null;
  const m = content.trim().match(VOICE_RE);
  return m ? { url: m[1], dur: parseInt(m[2], 10) || 0 } : null;
}
function dmPreview(content) { return parseVoice(content) ? '🎤 Voice message' : content; }
function fmtVoiceTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const m = Math.floor(s / 60), r = s % 60;
  return m + ':' + (r < 10 ? '0' : '') + r;
}
function seededBars(seed, n) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seed.length; i++) { h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  const out = [];
  for (let i = 0; i < n; i++) { h ^= h << 13; h >>>= 0; h ^= h >> 17; h ^= h << 5; h >>>= 0; out.push(0.22 + (h % 1000) / 1000 * 0.78); }
  return out;
}
function voiceBubbleInner(url, dur) {
  const bars = seededBars(url, 32).map((hgt, i) => `<span class="voice-bar" style="height:${Math.round(hgt * 100)}%"></span>`).join('');
  return `<div class="voice-player" data-url="${esc(url)}" data-dur="${dur}">
    <button type="button" class="voice-play" aria-label="Play voice message">▶</button>
    <div class="voice-waves">${bars}</div>
    <span class="voice-time">${fmtVoiceTime(dur)}</span>
  </div>`;
}
function pickRecMime() {
  const cands = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/ogg', 'audio/mp4', 'audio/mpeg', ''];
  for (const c of cands) {
    if (c && window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(c)) return { mime: c, ext: recExtFor(c) };
  }
  return { mime: '', ext: 'webm' };
}
function recExtFor(m) {
  if (m.indexOf('ogg') !== -1) return 'ogg';
  if (m.indexOf('mp4') !== -1 || m.indexOf('mpeg') !== -1) return 'mp4';
  if (m.indexOf('wav') !== -1) return 'wav';
  return 'webm';
}
// Wire every .voice-player inside `scope` (idempotent). Only one plays at a time.
function wireVoicePlayers(scope) {
  if (!scope) return;
  scope.querySelectorAll('.voice-player').forEach(vp => {
    if (vp.dataset.wired) return;
    vp.dataset.wired = '1';
    const url = vp.dataset.url || '';
    if (!/^\/assets\/uploads\/[A-Za-z0-9_.\-]+$/.test(url)) { vp.innerHTML = '<span class="muted">[voice]</span>'; return; }
    const bars = Array.from(vp.querySelectorAll('.voice-bar'));
    const playBtn = vp.querySelector('.voice-play');
    const timeEl = vp.querySelector('.voice-time');
    const total = parseInt(vp.dataset.dur, 10) || 0;
    const audio = new Audio(url);
    audio.preload = 'metadata';
    let duration = total;
    const paint = (frac) => { const played = Math.round(frac * bars.length); bars.forEach((b, i) => b.classList.toggle('played', i < played)); };
    const setPlaying = (on) => { audio._playing = on; playBtn.textContent = on ? '❚❚' : '▶'; vp.classList.toggle('playing', on); };
    audio.addEventListener('loadedmetadata', () => { if (isFinite(audio.duration) && audio.duration > 0) { duration = audio.duration; if (!audio._playing) timeEl.textContent = fmtVoiceTime(duration); } });
    audio.addEventListener('timeupdate', () => {
      const frac = duration > 0 ? audio.currentTime / duration : 0;
      paint(frac);
      timeEl.textContent = fmtVoiceTime(audio.currentTime) + ' / ' + fmtVoiceTime(duration);
    });
    audio.addEventListener('ended', () => { setPlaying(false); paint(0); timeEl.textContent = fmtVoiceTime(duration); });
    audio.addEventListener('pause', () => setPlaying(false));
    audio.addEventListener('error', () => { timeEl.textContent = 'error'; playBtn.disabled = true; });
    playBtn.addEventListener('click', () => {
      if (audio._playing) { audio.pause(); return; }
      if (window.__voiceCurrent && window.__voiceCurrent !== audio) { try { window.__voiceCurrent.pause(); } catch (e) {} }
      window.__voiceCurrent = audio;
      const p = audio.play();
      if (p && p.catch) p.catch(() => toast('Cannot play this audio', 'error'));
      setPlaying(true);
    });
    vp.querySelector('.voice-waves').addEventListener('click', (e) => {
      const r = e.currentTarget.getBoundingClientRect();
      const frac = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      if (duration > 0) audio.currentTime = frac * duration;
      paint(frac);
    });
  });
}

// Image links/uploads inside DM bubbles — same embedding as the live chat,
// so a picture never shows as a raw "/assets/uploads/…" path.
const DM_IMG_URL = /^((?:https?:)?\/\/|\/)[^\s'"<>]+?\.(png|jpe?g|gif|webp)(\?[^\s'"<>]*)?$/i;
function dmTextHTML(content) {
  return String(content == null ? '' : content).split(/(\s+)/).map(part => {
    if (!part) return '';
    if (DM_IMG_URL.test(part)) {
      const u2 = esc(part);
      return ` <a href="${u2}" target="_blank" rel="noopener nofollow ugc" class="chat-imgwrap"><img class="chat-img dm-img" src="${u2}" alt="image" loading="lazy" draggable="false" referrerpolicy="no-referrer"></a>`;
    }
    return wrapMentions(esc(part));
  }).join('');
}
function dmMsgHTML(m, peer) {
  // Show the sender's avatar before the bubble (own avatar on the right).
  // The timestamp is rendered inline at the end of the bubble so the avatar
  // stays vertically centred with the message TEXT (not with the time below).
  const u = m.mine ? (state.user || {}) : (peer || {});
  const av = u && (u.avatar || u.username) ? avatarHTML(u, 'avatar dm-av') : '';
  const voice = parseVoice(m.content);
  const body = voice ? voiceBubbleInner(voice.url, voice.dur) : dmTextHTML(m.content);
  return `<div class="dm-msg ${m.mine ? 'mine' : ''}">
    ${!m.mine ? av : ''}
    <div class="dm-col">
      <div class="dm-bubble ${voice ? 'dm-voice-bubble' : ''}">${body}<span class="dm-time">${timeStr(m.createdAt)}</span></div>
    </div>
    ${m.mine ? av : ''}
  </div>`;
}
async function renderDM(app, target) {
  if (!state.user) { app.innerHTML = '<div class="error">🔒 Log in to read messages.</div>'; return; }
  window.__onDmMessage = null; // cleared for the list view; set below for a live conversation
  const name = target ? decodeURIComponent(target) : null;
  if (!name) {
    let convs = [];
    try { convs = (await API.dmConversations()).conversations || []; } catch (e) {}
    app.innerHTML = `
      <h1>Messages</h1>
      <div class="card dm-list">
        ${convs.length ? convs.map(c => `
          <a class="dm-row" href="#/dm/${encodeURIComponent(c.other.username)}">
            ${avatarHTML(c.other, 'avatar')}
            <div class="dm-row-body">
              <div class="dm-row-top"><b style="color:${esc(nameColor(c.other))}">${esc(c.other.username)}</b><span class="muted">${c.last ? timeStr(c.last.createdAt) : ''}</span></div>
              <div class="dm-row-bot"><span class="dm-prev">${esc(c.last ? dmPreview(c.last.content) : 'No messages yet')}</span>${c.unread ? `<span class="nav-badge">${c.unread > 99 ? '99+' : c.unread}</span>` : ''}</div>
            </div>
          </a>`).join('') : '<p class="notice">No conversations yet. Open a profile and click “Send message”.</p>'}
      </div>`;
    emojiParse(app);
    return;
  }
  let data;
  try { data = await API.dmMessages(name); }
  catch (e) { app.innerHTML = '<div class="error">' + esc(e.message) + '</div>'; return; }
  mentionRolesMerge(data.mentionRoles);
  const o = data.other;
  app.innerHTML = `
    <div class="dm">
      <div class="dm-head">
        <a class="btn" href="#/dm">← Back</a>
        <a class="dm-peer" href="#/profile/${encodeURIComponent(o.username)}">${avatarHTML(o, 'avatar')}<b style="color:${esc(nameColor(o))}">${esc(o.username)}</b><span class="tag tag-${o.role}">${esc(o.role)}</span></a>
      </div>
      <div class="dm-thread" id="dm-thread">${data.messages.map(m => dmMsgHTML(m, o)).join('')}</div>
      <button class="dm-scrolldown" id="dm-scrolldown" title="New messages — scroll down" type="button">
        <span class="dm-scrolldown-count" id="dm-scrolldown-count"></span><span class="dm-scrolldown-arrow">↓</span>
      </button>
      <div class="dm-compose">
        <div id="dm-input" class="dm-input" contenteditable="true" data-placeholder="Message @${esc(o.username)}…" maxlength="2000"></div>
        <button class="btn btn-accent" id="dm-send">Send</button>
      </div>
    </div>`;
  emojiParse(app);
  const thread = document.getElementById('dm-thread');
  thread.scrollTop = thread.scrollHeight;
  wireVoicePlayers(thread);
  // Track message ids already on screen so live updates never duplicate a bubble.
  const seenIds = new Set((data.messages || []).map(m => m.id));

  /* ---- "Scroll to new messages" button + smooth auto-scroll ---- */
  let newCount = 0;          // new messages that arrived while scrolled up
  let stickToBottom = true;  // the view opens pinned to the latest message
  const scrollBtn = document.getElementById('dm-scrolldown');
  const scrollCount = document.getElementById('dm-scrolldown-count');
  const isNearBottom = (el) => el.scrollHeight - el.scrollTop - el.clientHeight < 120;
  function updateScrollBtn() {
    if (!scrollBtn) return;
    if (newCount > 0 && !stickToBottom) {
      scrollBtn.classList.add('show');
      if (scrollCount) scrollCount.textContent = newCount > 99 ? '99+' : String(newCount);
    } else {
      scrollBtn.classList.remove('show');
      if (scrollCount) scrollCount.textContent = '';
    }
  }
  // Append one bubble with a smooth entrance animation. If the user is at the
  // bottom (or `force`), keep them pinned there; otherwise bump the counter and
  // reveal the scroll-down arrow instead of yanking their scroll position.
  function appendDmMessage(m, force) {
    if (!thread) return;
    thread.insertAdjacentHTML('beforeend', dmMsgHTML(m, o));
    const node = thread.lastElementChild;
    if (node) node.classList.add('dm-msg-in'); // smooth fade/slide-in
    emojiParse(node);
    wireVoicePlayers(node);
    if (force || stickToBottom) {
      thread.scrollTop = thread.scrollHeight;
    } else {
      newCount++;
      updateScrollBtn();
    }
  }
  thread.addEventListener('scroll', () => {
    stickToBottom = isNearBottom(thread);
    if (stickToBottom && newCount > 0) newCount = 0; // user reached the bottom
    updateScrollBtn();
  });
  if (scrollBtn) scrollBtn.onclick = () => {
    thread.scrollTo({ top: thread.scrollHeight, behavior: 'smooth' });
    newCount = 0; stickToBottom = true; updateScrollBtn();
  };

  // Live incoming message for THIS conversation (driven by the Node socket in
  // chat.js, or set up here for parity). Appends the bubble and bumps the badge.
  window.__onDmMessage = (data) => {
    if (!data || data.from !== name) return;
    if (data.message && data.message.id) {
      if (seenIds.has(data.message.id)) return; // already shown
      seenIds.add(data.message.id);
    }
    appendDmMessage(data.message);
    refreshDmBadge();
  };
  const input = document.getElementById('dm-input');
  const send = async () => {
    let v = getTextValue(input);
    if (v.length > 2000) v = v.slice(0, 2000);
    if (!v.trim()) { input.innerHTML = ''; return; }
    input.innerHTML = '';
    try {
      const r = await API.dmSend(name, v);
      mentionRolesMerge(r.mentionRoles);
      if (r.message && r.message.id) seenIds.add(r.message.id); // don't let the poller re-add it
      newCount = 0; stickToBottom = true;   // your own message: jump to the bottom
      appendDmMessage(r.message, true);
      refreshDmBadge();
    } catch (e) { toast(e.message, 'error'); }
  };
  document.getElementById('dm-send').onclick = send;
  input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
  input.addEventListener('input', () => { if (input.textContent === '') input.innerHTML = ''; });
  input.addEventListener('paste', sanitizePaste);
  refreshDmBadge();
  // Emoji picker for the DM compose box.
  const dmCompose = document.querySelector('.dm-compose');
  let dmEmojiBtn = dmCompose.querySelector('.emoji-trigger');
  if (!dmEmojiBtn) {
    dmEmojiBtn = document.createElement('button');
    dmEmojiBtn.type = 'button'; dmEmojiBtn.className = 'btn emoji-trigger'; dmEmojiBtn.textContent = '😊';
    dmCompose.insertBefore(dmEmojiBtn, input);
  }
  dmEmojiBtn.addEventListener('mousedown', e => e.preventDefault());
  dmEmojiBtn.onclick = (e) => { e.preventDefault(); e.stopPropagation(); toggleEmoji(input, dmEmojiBtn); };
  bindEmojiHover(input, dmEmojiBtn);

  // ---- Voice messages: record with a Telegram-style animated waveform ----
  const recBar = document.createElement('div');
  recBar.className = 'dm-recbar';
  recBar.innerHTML = `<button type="button" class="btn dm-rec-cancel" title="Cancel recording">✕</button>
    <div class="dm-rec-waves"></div>
    <span class="dm-rec-time">0:00</span>
    <button type="button" class="btn btn-accent dm-rec-send" title="Send voice message">➤</button>`;
  dmCompose.appendChild(recBar);
  const recWaves = recBar.querySelector('.dm-rec-waves');
  const recTimeEl = recBar.querySelector('.dm-rec-time');
  const REC_BARS = 30;
  for (let i = 0; i < REC_BARS; i++) { const s = document.createElement('span'); s.className = 'dm-rec-bar'; recWaves.appendChild(s); }
  const recBarEls = Array.from(recWaves.children);
  let dmMicBtn = dmCompose.querySelector('.dm-mic');
  if (!dmMicBtn) {
    dmMicBtn = document.createElement('button');
    dmMicBtn.type = 'button'; dmMicBtn.className = 'btn dm-mic'; dmMicBtn.textContent = '🎙️'; dmMicBtn.title = 'Voice message';
    dmCompose.insertBefore(dmMicBtn, document.getElementById('dm-send'));
  }
  let mediaRec = null, recChunks = [], recStart = 0, recRAF = null, audioCtx = null, analyser = null, micStream = null, recMime = '', recExt = 'webm';
  function recCleanup() {
    if (recRAF) { cancelAnimationFrame(recRAF); recRAF = null; }
    if (mediaRec && mediaRec.state !== 'inactive') { try { mediaRec.stop(); } catch (e) {} }
    if (micStream) { micStream.getTracks().forEach(t => t.stop()); micStream = null; }
    if (audioCtx) { try { audioCtx.close(); } catch (e) {} audioCtx = null; }
    mediaRec = null; analyser = null; recChunks = [];
    dmCompose.classList.remove('recording');
    dmMicBtn.disabled = false;
    window.__dmRecCleanup = null;
  }
  window.__dmRecCleanup = recCleanup;
  function recTick() {
    recTimeEl.textContent = fmtVoiceTime((Date.now() - recStart) / 1000);
    if (analyser) {
      const data = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(data);
      const step = Math.max(1, Math.floor(data.length / REC_BARS));
      for (let i = 0; i < REC_BARS; i++) {
        let sum = 0; for (let j = 0; j < step; j++) sum += data[i * step + j] || 0;
        const lvl = Math.min(1, (sum / step / 255) * 1.7);
        recBarEls[i].style.height = (15 + lvl * 85) + '%';
      }
    } else {
      const t = Date.now() / 200;
      for (let i = 0; i < REC_BARS; i++) recBarEls[i].style.height = (25 + (Math.sin(t + i * 0.6) * 0.5 + 0.5) * 60) + '%';
    }
    recRAF = requestAnimationFrame(recTick);
  }
  dmMicBtn.addEventListener('click', async () => {
    if (dmCompose.classList.contains('recording')) return;
    if (!window.isSecureContext) { toast('Voice messages require HTTPS (a secure connection).', 'error'); return; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { toast('Recording is not supported in this browser.', 'error'); return; }
    try { micStream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) { toast('Microphone access denied or unavailable.', 'error'); return; }
    const pick = pickRecMime(); recMime = pick.mime; recExt = pick.ext;
    try { mediaRec = recMime ? new MediaRecorder(micStream, { mimeType: recMime }) : new MediaRecorder(micStream); }
    catch (e) { try { mediaRec = new MediaRecorder(micStream); } catch (e2) { toast('Recording is not supported.', 'error'); recCleanup(); return; } }
    recChunks = [];
    mediaRec.ondataavailable = (e) => { if (e.data && e.data.size) recChunks.push(e.data); };
    mediaRec.onstop = async () => {
      const sec = Math.max(1, Math.round((Date.now() - recStart) / 1000));
      const blob = new Blob(recChunks, { type: recMime || 'audio/webm' });
      const wantSend = !!mediaRec._send;
      recCleanup();
      if (!wantSend || blob.size === 0) return;
      try {
        const fd = new FormData(); fd.append('file', blob, 'voice.' + recExt);
        const up = await API.attachmentUpload(fd);
        const content = '[[voice:' + up.url + '|' + sec + ']]';
        const r = await API.dmSend(name, content);
        mentionRolesMerge(r.mentionRoles);
        if (r.message && r.message.id) seenIds.add(r.message.id);
        newCount = 0; stickToBottom = true;
        appendDmMessage(r.message, true);
        refreshDmBadge();
      } catch (e) { toast(e.message, 'error'); }
    };
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const srcNode = audioCtx.createMediaStreamSource(micStream);
      analyser = audioCtx.createAnalyser(); analyser.fftSize = 128; analyser.smoothingTimeConstant = 0.7;
      srcNode.connect(analyser);
    } catch (e) { analyser = null; }
    recStart = Date.now();
    mediaRec._send = false;
    mediaRec.start(100);
    dmCompose.classList.add('recording');
    dmMicBtn.disabled = true;
    recTimeEl.textContent = '0:00';
    recBarEls.forEach(b => b.style.height = '20%');
    recRAF = requestAnimationFrame(recTick);
    window.__dmRecCleanup = recCleanup;
  });
  recBar.querySelector('.dm-rec-cancel').addEventListener('click', () => {
    if (mediaRec) { mediaRec._send = false; try { mediaRec.stop(); } catch (e) {} } else recCleanup();
  });
  recBar.querySelector('.dm-rec-send').addEventListener('click', () => {
    if (mediaRec && mediaRec.state !== 'inactive') { mediaRec._send = true; try { mediaRec.stop(); } catch (e) {} }
  });

  // ---- Live DM updates (PHP/Beget: AJAX polling) ----
  // Node mode already pushes incoming messages via Socket.IO (__onDmMessage);
  // on the PHP deploy we poll this conversation every 3s and append only the
  // brand-new messages. Polling dm_messages also marks them as read server-side,
  // so the unread badge clears while the conversation stays open.
  if (API.mode !== 'node') {
    if (window.__dmPoll) { clearInterval(window.__dmPoll); window.__dmPoll = null; }
    async function pollDm() {
      // Stop automatically once the user leaves this conversation view.
      const threadNow = document.getElementById('dm-thread');
      if (!threadNow || typeof window.__onDmMessage !== 'function') {
        clearInterval(window.__dmPoll); window.__dmPoll = null; return;
      }
      try {
        const d = await API.dmMessages(name);
        mentionRolesMerge(d.mentionRoles);
        let added = 0;
        (d.messages || []).forEach(m => {
          if (seenIds.has(m.id)) return;
          seenIds.add(m.id);
          appendDmMessage(m); // animated; auto-scrolls only if pinned to bottom
          added++;
        });
        if (added) refreshDmBadge();
      } catch (e) { /* ignore transient errors */ }
    }
    window.__dmPoll = setInterval(pollDm, 3000);
  }
}

/* ---------------- Router ---------------- */
function parseHash() {
  const h = location.hash.replace(/^#\/?/, '');
  const [path, q] = h.split('?');
  // Percent-decode each segment: in-app links are built with
  // encodeURIComponent(), and location.hash does NOT decode them back, so any
  // Cyrillic username (or space/emoji) arrived here still %-encoded and every
  // API lookup for it failed with "User not found". Malformed sequences fall
  // back to the raw segment instead of throwing.
  const segs = path.split('/').filter(Boolean).map(s => {
    try { return decodeURIComponent(s); } catch (e) { return s; }
  });
  return { segs, q };
}
/* Password-reset page reached from the email link (#/reset?token=...). */
async function renderResetPassword(app, token) {
  app.innerHTML = `<div class="card form" style="max-width:420px;margin:40px auto">
    <h1>Reset password</h1>
    <div id="reset-body"><p class="muted">Checking reset link…</p></div>
  </div>`;
  const body = document.getElementById('reset-body');
  if (!token) { body.innerHTML = '<p class="error">Missing reset token.</p>'; return; }
  let valid = false;
  try { const r = await API.forgotCheck(token); valid = !!r.valid; } catch (e) { valid = false; }
  if (!valid) {
    body.innerHTML = `<p class="error">This reset link is invalid or has expired.</p>
      <p class="muted" style="margin-top:8px">Please request a new one from the <a class="auth-link" href="#" data-action="login" style="color:var(--accent-2)">login</a> screen.</p>`;
    return;
  }
  body.innerHTML = `<p class="muted" style="margin:0 0 12px">Choose a new password for your account.</p>
    <label>New password</label><input id="rs-pass" type="password" placeholder="At least 6 characters" autocomplete="new-password">
    <label>Confirm password</label><input id="rs-pass2" type="password" placeholder="Repeat new password" autocomplete="new-password">
    <button class="btn btn-accent" id="rs-go" style="width:100%;margin-top:10px">Set new password</button>`;
  const pass = document.getElementById('rs-pass');
  const go = () => {
    const p1 = document.getElementById('rs-pass').value;
    const p2 = document.getElementById('rs-pass2').value;
    if (p1.length < 6) { toast('Password must be at least 6 characters', 'warn'); return; }
    if (p1 !== p2) { toast('Passwords do not match', 'warn'); return; }
    const btn = document.getElementById('rs-go'); btn.disabled = true;
    API.forgotReset({ token: token, password: p1 })
      .then(() => {
        body.innerHTML = `<p style="color:var(--accent-2);font-weight:600">Password updated. You can log in now.</p>
          <button class="btn btn-accent" id="rs-login" style="width:100%;margin-top:10px">Log in</button>`;
        document.getElementById('rs-login').onclick = () => showAuth('login');
      })
      .catch(e => { toast(e.message, 'error'); btn.disabled = false; });
  };
  document.getElementById('rs-go').onclick = go;
  pass.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  setTimeout(() => pass.focus(), 60);
}

async function router() {
  const { segs, q } = parseHash();
  const app = document.getElementById('app');
  window.__onDmMessage = null; // a stale DM handler from a previous view must not fire
  if (window.__dmPoll) { clearInterval(window.__dmPoll); window.__dmPoll = null; } // stop any DM poller
  // Stop any playing voice message and any active recording (releases the mic).
  if (window.__voiceCurrent) { try { window.__voiceCurrent.pause(); } catch (e) {} window.__voiceCurrent = null; }
  if (typeof window.__dmRecCleanup === 'function') { try { window.__dmRecCleanup(); } catch (e) {} window.__dmRecCleanup = null; }
  // The password-reset page (reached from the email link) is a standalone public
  // page — hide the live chat sidebar there (and let the content go full width).
  // На главной-лендинге чат тоже убираем: hero разворачивается на всю ширину.
  // Прячем ОБЕ ноды — #chat и его обёртку .chat-column (иначе пустая колонка
  // 320px продолжает занимать место во flex и hero не растягивается).
  const __chatEl = document.getElementById('chat');
  const __chatCol = document.querySelector('.chat-column');
  const __hideChat = (segs[0] === 'reset' || segs.length === 0);
  if (__chatEl) __chatEl.style.display = __hideChat ? 'none' : '';
  if (__chatCol) __chatCol.style.display = __hideChat ? 'none' : '';
  // Footer only lives on the home page (renderHome injects it into
  // #footer-slot). Wipe it here on every route change so it doesn't
  // linger on other pages.
  if (segs.length !== 0) clearFooter();
  try {
    if (segs.length === 0) return renderHome(app);
    const params = queryParams(q);
    switch (segs[0]) {
      case 'forum': return renderForum(app);
      case 'tickets': return renderTickets(app);
      case 'ticket': return renderTicket(app, segs[1]);
      case 'newticket': return renderNewTicket(app);
      case 'category': return renderCategory(app, segs[1], params);
      case 'thread': return renderThread(app, segs[1]);
      case 'profile': return renderProfile(app, segs[1]);
      case 'downloads': return renderDownloads(app);
      case 'rules': return renderRules(app);
      case 'search': return renderSearch(app, params.q);
      case 'new': return renderNewThread(app, params.cat);
      case 'admin': return renderAdmin(app);
      case 'dm': return renderDM(app, segs[1]);
      case 'reset': return renderResetPassword(app, params.token);
      default: return renderHome(app);
    }
  } catch (e) { app.innerHTML = '<div class="error">Error: ' + esc(e.message) + '</div>'; }
}

/* ---------------- Emoji picker ---------------- */
/* Emoji picker categories — the picker shows tabs instead of one long wall
   of glyphs. (Plus an auto "Recent" tab built from localStorage.) */
const EMOJI_CATEGORIES = [
  { key: "smileys", icon: "😀", label: "Smileys", emojis: [
    "😀","😃","😄","😁","😆","😅","😂","🙂","😉","😊","😇","😍","😘","😗","😚","😙",
    "😋","😛","😜","😝","🤑","🤗","🤭","🤫","🤔","🤐","😐","😑","😶","😏","😒","🙄",
    "😬","🤥","😔","😪","🤤","😷","🤒","🤕","🤢","🤮","🥵","🥶","😵","🤯","🤠","🥳",
    "😎","🤓","😕","😟","🙁","😮","😯","😲","😳","🥺","😦","😧","😨","😰","😥","😢",
    "😭","😱","😖","😣","😞","😓","😩","😫"
  ] },
  { key: "gestures", icon: "👍", label: "Gestures", emojis: [
    "👍","👌","✌️","🤞","🤙","🙌","💪","👊","✊","🤛","🤜","🫶","👋","🤚","🖐️","✋"
  ] },
  { key: "hearts", icon: "❤️", label: "Hearts", emojis: [
    "❤️","🧡","💛","💚","💙","💜","🖤","🤍","💔","❣️","💞","💓","💗","💖","💘","💝"
  ] },
  { key: "symbols", icon: "✨", label: "Symbols", emojis: [
    "🔥","✨","⭐","🌟","💯","✅","❌","⚡"
  ] },
  { key: "food", icon: "🍕", label: "Food & Drink", emojis: [
    "🍕","🍔","🍟","🌭","🍿","🍩","🍪","🍰","🍫","🍬","🍭","🍺","🍻","🥂","🍷","☕",
    "🧃","🍎"
  ] },
  { key: "animals", icon: "🐱", label: "Animals", emojis: [
    "😺","😸","😹","😻","😼","😽","😿","😾","🐱","🐶","🐺","🦊","🐻","🐼","🐨","🐯",
    "🦁","🐮","🐷"
  ] },
  { key: "nature", icon: "🌸", label: "Nature", emojis: [
    "🌹","🌸","🌺","🌻","🌈","☀️","🌙"
  ] },
  { key: "activities", icon: "🎉", label: "Activities", emojis: [
    "🎉","🎊","🎮","🕹️","🏆","🎯","🏀","🧿"
  ] },
  { key: "objects", icon: "💡", label: "Objects", emojis: [
    "💡","🚀","🛡️","💀","👻","🤖","🔔","📌","📎","💬","📢","🔑"
  ] }
];;
const EMOJI_RECENT_KEY = 'wtech_emoji_recent';
function emojiRecent() {
  try { return (JSON.parse(localStorage.getItem(EMOJI_RECENT_KEY) || '[]')).filter(x => typeof x === 'string'); }
  catch (e) { return []; }
}
function emojiRecentAdd(ch) {
  try {
    const r = emojiRecent().filter(x => x !== ch);
    r.unshift(ch);
    localStorage.setItem(EMOJI_RECENT_KEY, JSON.stringify(r.slice(0, 28)));
  } catch (e) {}
}

let __emojiPop = null;
let __emojiTabs = null;
let __emojiGrid = null;
let __emojiInput = null;
let __emojiBtn = null;
let __hideTimer = null;
let __emojiActiveKey = null;

// Convert any emoji inside an element into colorful Twemoji images (VK-style).
// Falls back silently to native text emoji if Twemoji hasn't loaded yet.
// The bundled twemoji library (v14) doesn't recognize Unicode 15+ emojis
// (🩶 🫨 🪻 …) — those stayed plain text and showed as □ boxes on devices
// with an older OS emoji font. This pass wraps any REMAINING pictographic
// cluster into the same img.emoji pipeline (local bundle → CDN → glyph).
function emojiWrapUnknown(container) {
  let RE;
  try { RE = new RegExp('\\p{Extended_Pictographic}[\\u{1F3FB}-\\u{1F3FF}]?\\uFE0F?(?:\\u200D\\p{Extended_Pictographic}[\\u{1F3FB}-\\u{1F3FF}]?\\uFE0F?)*', 'gu'); }
  catch (e) { return; }
  const accept = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      if (!n.nodeValue) return NodeFilter.FILTER_REJECT;
      RE.lastIndex = 0;
      return RE.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  let node;
  while ((node = walker.nextNode())) accept.push(node);
  accept.forEach((n) => {
    RE.lastIndex = 0;
    const frag = document.createDocumentFragment();
    let last = 0, m;
    while ((m = RE.exec(n.nodeValue)) !== null) {
      if (m.index > last) frag.appendChild(document.createTextNode(n.nodeValue.slice(last, m.index)));
      frag.appendChild(makeEmojiImg(m[0]));
      last = m.index + m[0].length;
    }
    if (last < n.nodeValue.length) frag.appendChild(document.createTextNode(n.nodeValue.slice(last)));
    n.parentNode.replaceChild(frag, n);
  });
}
function emojiParse(el) {
  if (window.twemoji && el) {
    try {
      // Local emoji images (bundled in /assets/emoji/72x72) — no external CDN, works offline.
      window.twemoji.parse(el, {
        base: '/assets/emoji/',
        folder: '72x72',
        ext: '.svg',
        callback: function (icon) { return emojiResolveUrl(icon + '.svg'); }
      });
      // Catch Unicode 15+ glyphs the v14 library missed.
      emojiWrapUnknown(el);
      // Resilient fallback: the bundled SVGs sometimes store a glyph WITHOUT the
      // variation selector (e.g. 2764.svg) while Twemoji requests it WITH one
      // (2764-fe0f.svg), or vice-versa — that 404s and would show a mono glyph.
      // So on error we retry the OTHER variant; only if that also fails do we
      // fall back to the native text glyph. Keeps every emoji colorful.
      el.querySelectorAll('img.emoji').forEach(img => {
        img.onerror = function () {
          const src = this.getAttribute('src') || '';
          const m = src.match(/^(.*\/)([^\/?#]+?)(\.svg)(?:[?#].*)?$/i);
          const tries = this.dataset.fb ? parseInt(this.dataset.fb, 10) : 0;
          let alt = null;
          if (m && m[1].indexOf('/assets/emoji/') === 0) {
            const cp = m[2];
            // Local-bundle retry order: 1) the other VS16 variant, 2) fe0f in
            // a different sequence spot, then 3)+4) the same file from the
            // twemoji CDN — covers ANY emoji typed by users that isn't in the
            // 176-file bundle on devices whose OS font lacks the glyph
            // (CSP img-src allows https:). Text glyph is the last resort.
            if (tries === 0) alt = m[1] + (cp.indexOf('-fe0f') !== -1 ? cp.replace(/-fe0f/g, '') : (cp + '-fe0f')) + m[3];
            else if (tries === 1 && cp.indexOf('-fe0f') === -1) {
              const parts = cp.split('-');
              if (parts.length > 1) alt = m[1] + parts[0] + '-fe0f-' + parts.slice(1).join('-') + m[3];
            }
            if (alt === null && tries <= 3) {
              const CDN = 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/';
              alt = tries === 2 ? CDN + cp + m[3]
                                : CDN + (cp.indexOf('-fe0f') !== -1 ? cp.replace(/-fe0f/g, '') : cp) + m[3];
            }
          }
          if (alt === null) { const t = document.createTextNode(this.alt || ''); this.replaceWith(t); return; }
          this.dataset.fb = String(tries + 1);
          this.src = alt;
        };
      });
    } catch (e) {}
  }
}
function cancelHide() { if (__hideTimer) { clearTimeout(__hideTimer); __hideTimer = null; } }
function scheduleHide() { cancelHide(); __hideTimer = setTimeout(hideEmoji, 180); }
function hideEmoji() { if (__emojiPop) __emojiPop.classList.remove('open'); }
function showEmoji(input, btn) {
  const pop = buildEmojiPopover();
  // Guest inputs must never open the picker (belt-and-suspenders alongside
  // chat.php removing the trigger button on logout).
  if (input && input.classList && input.classList.contains('chat-input-disabled')) return;
  __emojiInput = input; __emojiBtn = btn;
  refreshEmojiPicker();   // rebuild tabs (refreshes the "Recent" tab) + grid
  cancelHide();
  pop.classList.add('open');
  const r = btn.getBoundingClientRect();
  let left = r.left;
  if (left + 312 > window.innerWidth) left = window.innerWidth - 312;
  if (left < 8) left = 8;
  pop.style.left = left + 'px';
  pop.style.bottom = (window.innerHeight - r.top + 8) + 'px';
}
function __emojiCatList() {
  const recent = emojiRecent();
  return recent.length
    ? [{ key: '__recent', icon: '🕒', label: 'Recent', emojis: recent }, ...EMOJI_CATEGORIES]
    : EMOJI_CATEGORIES;
}
function __emojiRenderGrid(list) {
  __emojiGrid.innerHTML = '';
  if (!list || !list.length) {
    __emojiGrid.innerHTML = '<div class="emoji-empty">Nothing here yet</div>';
    return;
  }
  list.forEach(e => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'emoji-cell'; b.textContent = e;
    b.addEventListener('click', (ev) => {
      ev.preventDefault(); ev.stopPropagation();
      emojiRecentAdd(e);
      insertEmoji(b.querySelector('img.emoji'), e);
    });
    __emojiGrid.appendChild(b);
  });
  emojiParse(__emojiGrid);
}
function __emojiSelectTab(key, tabEl) {
  __emojiActiveKey = key;
  __emojiTabs.querySelectorAll('.emoji-tab').forEach(t => t.classList.toggle('active', t === tabEl));
  const cat = __emojiCatList().find(c => c.key === key);
  __emojiRenderGrid(cat ? cat.emojis : []);
  if (__emojiPop) __emojiPop.scrollTop = 0;
  __emojiTabIntoView(tabEl);
}
// Category strip scrolling helpers: state of the ‹ › arrows + bringing the
// active tab into the visible window of the (horizontally scrollable) strip.
function __emojiTabsNavUpdate() {
  if (!__emojiTabs) return;
  const wrap = __emojiTabs.parentElement;
  if (!wrap || !wrap.classList || !wrap.classList.contains('emoji-tabswrap')) return;
  const max = __emojiTabs.scrollWidth - __emojiTabs.clientWidth;
  const can = max > 4;
  wrap.classList.toggle('no-scroll', !can);
  const prev = wrap.querySelector('.emoji-tabs-nav.prev');
  const next = wrap.querySelector('.emoji-tabs-nav.next');
  if (prev) prev.disabled = !can || __emojiTabs.scrollLeft <= 1;
  if (next) next.disabled = !can || __emojiTabs.scrollLeft >= max - 1;
}
function __emojiTabIntoView(t) {
  if (!t || !__emojiTabs) return;
  const el = __emojiTabs;
  const l = t.offsetLeft, r = l + t.offsetWidth;
  if (l < el.scrollLeft + 4) el.scrollTo({ left: Math.max(0, l - 6), behavior: 'smooth' });
  else if (r > el.scrollLeft + el.clientWidth - 4) el.scrollTo({ left: r - el.clientWidth + 6, behavior: 'smooth' });
}
// (Re)build the category tab bar and render the active category. Called on
// every open so the "Recent" tab stays up to date.
function refreshEmojiPicker() {
  if (!__emojiTabs || !__emojiGrid) return;
  const cats = __emojiCatList();
  __emojiTabs.innerHTML = '';
  const activeKey = (__emojiActiveKey && cats.some(c => c.key === __emojiActiveKey)) ? __emojiActiveKey : cats[0].key;
  cats.forEach(c => {
    const t = document.createElement('button');
    t.type = 'button';
    t.className = 'emoji-tab' + (c.key === activeKey ? ' active' : '');
    t.title = c.label; t.textContent = c.icon;
    t.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); __emojiSelectTab(c.key, t); });
    __emojiTabs.appendChild(t);
  });
  // Render the tab icons as colorful Twemoji images too (native glyph fonts
  // are monochrome on some systems, which made the tabs look grey).
  emojiParse(__emojiTabs);
  const cat = cats.find(c => c.key === activeKey) || cats[0];
  __emojiActiveKey = cat.key;
  __emojiRenderGrid(cat.emojis);
  // Tabs were rebuilt → refresh the ‹ › arrows and center the active tab.
  requestAnimationFrame(() => {
    __emojiTabsNavUpdate();
    const at = __emojiTabs.querySelector('.emoji-tab.active');
    if (at) {
      const el = __emojiTabs;
      el.scrollLeft = Math.max(0, at.offsetLeft - (el.clientWidth - at.offsetWidth) / 2);
      __emojiTabsNavUpdate();
    }
  });
}
function buildEmojiPopover() {
  if (__emojiPop) return __emojiPop;
  const pop = document.createElement('div');
  pop.id = 'emoji-popover';
  pop.className = 'emoji-popover';
  // Tab strip with ‹ › arrows: the categories row can be scrolled forward
  // and back via the arrows, drag, or the mouse wheel (wheel is translated
  // to horizontal scrolling below).
  const tabsWrap = document.createElement('div'); tabsWrap.className = 'emoji-tabswrap';
  const navPrev = document.createElement('button');
  navPrev.type = 'button'; navPrev.className = 'emoji-tabs-nav prev'; navPrev.textContent = '‹'; navPrev.tabIndex = -1;
  navPrev.title = 'Scroll back';
  const navNext = document.createElement('button');
  navNext.type = 'button'; navNext.className = 'emoji-tabs-nav next'; navNext.textContent = '›'; navNext.tabIndex = -1;
  navNext.title = 'Scroll forward';
  __emojiTabs = document.createElement('div'); __emojiTabs.className = 'emoji-tabs';
  tabsWrap.appendChild(navPrev); tabsWrap.appendChild(__emojiTabs); tabsWrap.appendChild(navNext);
  __emojiGrid = document.createElement('div'); __emojiGrid.className = 'emoji-grid';
  pop.appendChild(tabsWrap);
  pop.appendChild(__emojiGrid);
  const navStep = () => Math.max(96, __emojiTabs.clientWidth - 48);
  navPrev.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); __emojiTabs.scrollBy({ left: -navStep(), behavior: 'smooth' }); });
  navNext.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); __emojiTabs.scrollBy({ left: navStep(), behavior: 'smooth' }); });
  __emojiTabs.addEventListener('scroll', __emojiTabsNavUpdate, { passive: true });
  tabsWrap.addEventListener('wheel', (e) => {
    if (__emojiTabs.scrollWidth <= __emojiTabs.clientWidth) return;
    e.preventDefault(); // don't scroll the whole panel vertically while over the strip
    __emojiTabs.scrollLeft += (Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY);
  }, { passive: false });
  document.body.appendChild(pop);
  // Keep the panel open while the pointer is anywhere over it; hide shortly after it leaves.
  pop.addEventListener('mouseenter', cancelHide);
  pop.addEventListener('mouseleave', scheduleHide);
  pop.addEventListener('mousedown', e => e.preventDefault());
  document.addEventListener('click', (ev) => {
    if (!__emojiPop || !__emojiPop.classList.contains('open')) return;
    if (__emojiPop.contains(ev.target)) return;
    if (ev.target.closest('.emoji-trigger')) return;
    hideEmoji();
  });
  __emojiPop = pop;
  return pop;
}
let __lastRange = null;
document.addEventListener('selectionchange', () => {
  const sel = window.getSelection();
  if (!sel || !sel.rangeCount) return;
  const r = sel.getRangeAt(0);
  if (__emojiInput && __emojiInput.contains(r.commonAncestorContainer)) __lastRange = r.cloneRange();
});

// Plain-text value of an <input> or contenteditable element (emoji imgs -> their alt char).
function getTextValue(el) {
  if (!el) return '';
  if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return el.value;
  let out = '';
  el.childNodes.forEach(n => {
    if (n.nodeType === 3) out += n.nodeValue;
    else if (n.nodeName === 'BR') out += '\n';
    else if (n.nodeName === 'IMG' && n.classList.contains('emoji')) out += (n.alt || '');
    else out += n.textContent || '';
  });
  return out;
}
// Клиентская оптимизация картинок перед загрузкой: большие фото с телефона
// (2–8 МБ) упирались в upload_max_filesize=2M и НЕ отправлялись в чат/аттачи.
// Прогоняем через canvas: макс. сторона 1600px; png остаётся png (альфа),
// jpeg/webp → jpeg q0.86. GIF не трогаем (убила бы анимацию), лёгкие файлы
// (<1.4 МБ) идут как есть, при любой ошибке — оригинал.
window.wtechOptimizeImage = function (file) {
  return new Promise(resolve => {
    const ok = v => resolve(v);
    if (!file || !/^image\/(png|jpe?g|webp)$/i.test(file.type || '')) return ok(file);
    if (file.size < 1400 * 1024) return ok(file);
    try {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        try {
          const MAX = 1600;
          let w = img.width, h = img.height;
          URL.revokeObjectURL(url);
          if (!w || !h) return ok(file);
          const k = Math.min(1, MAX / Math.max(w, h));
          if (k >= 1 && file.size < 1900 * 1024) return ok(file); // мелкое и лёгкое
          w = Math.max(1, Math.round(w * k)); h = Math.max(1, Math.round(h * k));
          const cv = document.createElement('canvas');
          cv.width = w; cv.height = h;
          cv.getContext('2d').drawImage(img, 0, 0, w, h);
          const outType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
          cv.toBlob(b => {
            if (!b || !b.size || b.size >= file.size) return ok(file); // выигрыша нет
            const ext = outType === 'image/png' ? '.png' : '.jpg';
            ok(new File([b], (file.name || 'image').replace(/\.(png|jpe?g|webp)$/i, '') + ext, { type: outType }));
          }, outType, 0.86);
        } catch (e) { ok(file); }
      };
      img.onerror = () => { URL.revokeObjectURL(url); ok(file); };
      img.src = url;
    } catch (e) { ok(file); }
  });
};

// Единый резолвер emoji-URL: локальный файл берётся ТОЛЬКО если он реально
// есть в бандле (список строит PHP с диска — window.__EMOJI_LOCAL). Glyph вне
// бандла — сразу на twemoji CDN, БЕЗ слепого перебора локальных имён: 404
// с нашего сервера за emoji больше нет вообще (/1f441.svg, /2694.svg и т.д.).
const EMOJI_LOCAL_DIR = '/assets/emoji/72x72/';
const EMOJI_CDN = 'https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/';
function emojiResolveUrl(filename) {
  const set = window.__EMOJI_LOCAL;
  if (set) {
    if (set[filename]) return EMOJI_LOCAL_DIR + filename;
    // VS16-вариант: часть glyph лежит в бандле без -fe0f (или наоборот)
    const base = filename.replace(/\.svg$/i, '');
    const alt = base.indexOf('-fe0f') !== -1 ? base.replace(/-fe0f/g, '') : base + '-fe0f';
    if (set[alt + '.svg']) return EMOJI_LOCAL_DIR + alt + '.svg';
    return EMOJI_CDN + filename;
  }
  return EMOJI_LOCAL_DIR + filename; // манифест не подгрузился — старое поведение
}
function makeEmojiImg(ch) {
  const img = document.createElement('img');
  img.className = 'emoji';
  img.alt = ch;
  img.draggable = false;
  // Resolve the filename through twemoji's own parser: it NORMALIZES the
  // variation selector (❤️ → 2764.svg, ≠ hand-built 2764-fe0f.svg which
  // 404s and was the reason some picker emojis showed as □ boxes).
  let file = Array.from(ch).map(c => c.codePointAt(0).toString(16)).join('-') + '.svg';
  try {
    if (window.twemoji) {
      const html = window.twemoji.parse(ch, { folder: '72x72', ext: '.svg', base: '/assets/emoji/' });
      const m = html && html.match(/72x72\/([^\/?#"]+?\.svg)/);
      if (m) file = m[1];
    }
  } catch (e) {}
  img.src = emojiResolveUrl(file);
  // glyph, которого нет и на CDN (совсем экзотика) → текстовый символ
  img.onerror = function () { this.onerror = null; this.replaceWith(document.createTextNode(ch)); };
  return img;
}
function insertCharAtCaret(inp, ch) {
  const s = inp.selectionStart != null ? inp.selectionStart : inp.value.length;
  const e = inp.selectionEnd != null ? inp.selectionEnd : inp.value.length;
  inp.value = inp.value.slice(0, s) + ch + inp.value.slice(e);
  const pos = s + ch.length;
  inp.focus();
  try { inp.setSelectionRange(pos, pos); } catch (_) {}
}
function insertNodeAtCaret(el, node) {
  el.focus();
  let range = null;
  const sel = window.getSelection();
  if (__emojiInput === el && __lastRange && el.contains(__lastRange.commonAncestorContainer)) range = __lastRange.cloneRange();
  else if (sel && sel.rangeCount) range = sel.getRangeAt(0);
  if (!range) { el.appendChild(node); return; }
  range.deleteContents();
  const r = range.cloneRange();
  r.insertNode(node);
  r.setStartAfter(node);
  r.setEndAfter(node);
  if (sel) { sel.removeAllRanges(); sel.addRange(r); }
  __lastRange = r.cloneRange();
}
// Insert a colorful emoji image (contenteditable) or the raw char (plain input).
function insertEmoji(srcImg, ch) {
  const inp = __emojiInput;
  // Never insert into a node that was swapped out by a chat re-init (login /
  // logout / avatar refresh clone the input) — or into a disabled guest input.
  if (!inp || !document.contains(inp) || inp.classList.contains('chat-input-disabled')) return;
  if (inp.tagName === 'INPUT' || inp.tagName === 'TEXTAREA') {
    insertCharAtCaret(inp, ch);
  } else {
    const node = srcImg ? srcImg.cloneNode(true) : makeEmojiImg(ch);
    if (node && node.nodeType === 1) node.onerror = function () { const t = document.createTextNode(this.alt || ''); this.replaceWith(t); };
    insertNodeAtCaret(inp, node);
  }
  inp.focus();
}
// Paste as plain text into a contenteditable (no HTML injection).
function sanitizePaste(e) {
  e.preventDefault();
  const t = (e.clipboardData || window.clipboardData).getData('text/plain');
  const el = e.target;
  const sel = window.getSelection();
  if (sel && sel.rangeCount && el.contains(sel.getRangeAt(0).commonAncestorContainer)) {
    const r = sel.getRangeAt(0);
    r.deleteContents();
    r.insertNode(document.createTextNode(t));
    r.collapse(false);
    sel.removeAllRanges();
    sel.addRange(r);
  } else {
    el.appendChild(document.createTextNode(t));
  }
}
function toggleEmoji(input, btn) {
  const pop = buildEmojiPopover();
  const hoverDevice = window.matchMedia && window.matchMedia('(hover: hover)').matches;
  if (pop.classList.contains('open')) {
    if (hoverDevice) return; // on desktop the hover model controls visibility
    hideEmoji(); return;
  }
  showEmoji(input, btn);
}
// Desktop (real pointer): open on hover, stay while pointer is over trigger/panel, hide on leave.
function bindEmojiHover(input, btn) {
  if (!(window.matchMedia && window.matchMedia('(hover: hover)').matches)) return;
  // The chat input node is cloned+replaced on every initChat() run; resolve
  // the LIVE node at event time (trigger carries its id in data-emoji-for),
  // falling back to the originally bound element for other callers.
  const fresh = () => (btn.dataset && btn.dataset.emojiFor && document.getElementById(btn.dataset.emojiFor)) || input;
  btn.addEventListener('mouseenter', () => showEmoji(fresh(), btn));
  btn.addEventListener('mouseleave', scheduleHide);
}

/* ---------------- Custom dropdowns (styled <select>) ---------------- */
// Native <select> popups are OS-rendered and can't be styled or animated, so
// every select on the page is auto-upgraded: the REAL <select> stays in the
// DOM (visually hidden) and keeps its value + change events — existing logic
// (admin roles, ticket status, new-ticket category) is untouched — while a
// themed button + animated popup handles the interaction.
let __wdsOpenWrap = null; // the only dropdown open at a time

function enhanceSelect(sel) {
  if (sel.__wdsDone) return;
  sel.__wdsDone = 1;
  // Capture the intended width BEFORE hiding: computed style keeps '100%' /
  // '116px' semantics on the new wrapper (admin columns stay aligned).
  const csW = getComputedStyle(sel).width;
  const rectW = sel.getBoundingClientRect().width;
  sel.classList.add('wds-native');

  const wrap = document.createElement('div');
  wrap.className = 'wds';
  if (csW && (csW.endsWith('%') || csW.endsWith('px'))) wrap.style.width = csW;
  else if (rectW > 20) wrap.style.width = Math.round(rectW) + 'px';
  else wrap.style.width = '100%';

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'wds-btn';
  btn.innerHTML = '<span class="wds-label"></span><span class="wds-caret">▾</span>';

  sel.parentNode.insertBefore(wrap, sel.nextSibling);
  wrap.appendChild(sel);
  wrap.appendChild(btn);

  const labelEl = btn.querySelector('.wds-label');
  const syncLabel = () => {
    const o = sel.options[sel.selectedIndex];
    labelEl.textContent = o ? o.textContent : '';
    btn.disabled = sel.disabled;
  };
  syncLabel();
  sel.addEventListener('change', syncLabel);

  let pop = null, popOpen = false, closing = false;

  const ensurePop = () => {
    if (pop) return pop;
    pop = document.createElement('div');
    pop.className = 'wds-pop';
    pop.innerHTML = '<div class="wds-list"></div>';
    document.body.appendChild(pop);
    return pop;
  };

  const buildOptions = () => {
    const list = pop.querySelector('.wds-list');
    list.innerHTML = '';
    Array.from(sel.options).forEach((o, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'wds-opt' + (o.selected ? ' active' : '');
      b.style.animationDelay = (i * 18) + 'ms';
      b.disabled = !!o.disabled;
      b.innerHTML = '<span>' + esc(o.textContent) + '</span>' + (o.selected ? '<span class="wds-check">✓</span>' : '');
      b.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        sel.value = o.value;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        syncLabel();
        closePop();
      });
      list.appendChild(b);
    });
  };

  const placePop = () => {
    const r = btn.getBoundingClientRect();
    const estH = Math.min(220, sel.options.length * 34 + 12);
    pop.style.width = Math.max(r.width, 140) + 'px';
    pop.style.left = Math.max(6, Math.min(r.left, window.innerWidth - 146)) + 'px';
    if (window.innerHeight - r.bottom < estH + 12 && r.top > estH + 12) {
      pop.style.top = 'auto';
      pop.style.bottom = (window.innerHeight - r.top + 6) + 'px';
      pop.classList.add('wds-up');      // opens upward
    } else {
      pop.style.bottom = 'auto';
      pop.style.top = (r.bottom + 6) + 'px';
      pop.classList.remove('wds-up');
    }
  };

  const openPop = () => {
    if (popOpen) return;
    if (__wdsOpenWrap && __wdsOpenWrap !== wrap && __wdsOpenWrap.__wdsClose) __wdsOpenWrap.__wdsClose();
    // The popup lives in <body>; if the owner select was re-rendered away,
    // drop the orphan before opening a fresh one.
    if (pop && !document.contains(sel)) { pop.remove(); pop = null; }
    ensurePop();
    buildOptions();
    placePop();
    pop.classList.add('open');
    wrap.classList.add('open');
    popOpen = true;
    __wdsOpenWrap = wrap;
  };

  const closePop = () => {
    if (!popOpen || closing) return;
    closing = true;
    pop.classList.remove('open');
    pop.classList.add('closing');
    wrap.classList.remove('open');
    if (__wdsOpenWrap === wrap) __wdsOpenWrap = null;
    setTimeout(() => { pop.classList.remove('closing'); closing = false; }, 180);
    popOpen = false;
  };
  wrap.__wdsClose = closePop;

  btn.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    if (sel.disabled) return;
    popOpen ? closePop() : openPop();
  });
  btn.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!popOpen) openPop(); }
  });

  document.addEventListener('mousedown', (e) => {
    if (!popOpen) return;
    if (wrap.contains(e.target) || (pop && pop.contains(e.target))) return;
    closePop();
  });
  document.addEventListener('keydown', (e) => { if (popOpen && e.key === 'Escape') closePop(); });
  window.addEventListener('resize', () => { if (popOpen) closePop(); });
  window.addEventListener('scroll', () => { if (popOpen) closePop(); }, true);
}

// Auto-upgrade every <select> present now or added later (renders are
// innerHTML-based, so selects keep appearing on each route change).
function wdsScan(root) {
  (root || document).querySelectorAll('select:not(.wds-native)').forEach(enhanceSelect);
}
if (document.body) wdsScan(document.body);
new MutationObserver((records) => {
  for (const r of records) {
    for (const n of r.addedNodes) {
      if (n.nodeType !== 1) continue;
      if (n.matches && n.matches('select:not(.wds-native)')) enhanceSelect(n);
      else if (n.querySelector) n.querySelectorAll('select:not(.wds-native)').forEach(enhanceSelect);
    }
  }
}).observe(document.body, { childList: true, subtree: true });

/* ---------------- Ban screen (full lockout) ---------------- */
// Full-screen, non-dismissable overlay shown to a banned user. The only action
// available is logging out. Idempotent (won't stack if called twice).
/* Custom, on-theme confirmation dialog (replaces the native browser confirm()).
   Returns a Promise<boolean>. The destructive/OK button uses the danger style
   by default; for a non-destructive confirmation pass { danger: false }. */
function wtechConfirm(message, opts) {
  opts = opts || {};
  const okText = opts.okText || 'OK';
  const cancelText = opts.cancelText || 'Cancel';
  const title = opts.title || 'Confirm action';
  const danger = opts.danger !== false;
  return new Promise((resolve) => {
    const scrim = document.createElement('div');
    scrim.className = 'wtc-scrim';
    scrim.innerHTML = `
      <div class="wtc-modal" role="dialog" aria-modal="true" aria-labelledby="wtc-m-title">
        <div class="wtc-modal-head"><h3 id="wtc-m-title">${esc(title)}</h3></div>
        <div class="wtc-modal-body"><p class="wtc-modal-msg">${esc(message)}</p></div>
        <div class="wtc-modal-foot">
          <button type="button" class="btn wtc-cancel" data-act="cancel">${esc(cancelText)}</button>
          <button type="button" class="btn ${danger ? 'btn-danger' : 'btn-accent'} wtc-ok" data-act="ok">${esc(okText)}</button>
        </div>
      </div>`;
    document.body.appendChild(scrim);
    const okBtn = scrim.querySelector('[data-act="ok"]');
    const cancelBtn = scrim.querySelector('[data-act="cancel"]');
    const onKey = (e) => { if (e.key === 'Escape') close(false); };
    function close(val) {
      document.removeEventListener('keydown', onKey);
      scrim.classList.remove('show');
      setTimeout(() => scrim.remove(), 140);
      resolve(val);
    }
    okBtn.onclick = () => close(true);
    cancelBtn.onclick = () => close(false);
    scrim.addEventListener('mousedown', (e) => { if (e.target === scrim) close(false); });
    document.addEventListener('keydown', onKey);
    requestAnimationFrame(() => scrim.classList.add('show'));
    // For destructive actions focus the safe (cancel) button so an accidental
    // Enter doesn't confirm; native button behaviour handles Enter/Space.
    (danger ? cancelBtn : okBtn).focus();
  });
}

function showBanScreen(user) {
  if (document.getElementById('ban-screen')) return;
  // Stop any background polling so a locked-out user generates no traffic.
  ['__pollInterval', '__dmPoll', '__dmWatch', '__statsWatch'].forEach(k => {
    if (window[k]) { clearInterval(window[k]); window[k] = null; }
  });
  const u = user || {};
  const reasonRaw = (u.banReason || '').trim();
  const reasonHtml = reasonRaw ? esc(reasonRaw).replace(/\n/g, '<br>') : '';
  const el = document.createElement('div');
  el.id = 'ban-screen';
  el.className = 'ban-screen';
  el.innerHTML = `
    <div class="ban-card">
      <div class="ban-icon">🚫</div>
      <h1 class="ban-title">Account banned</h1>
      <p class="ban-sub">Your access to this community has been suspended by the staff.</p>
      ${reasonHtml
        ? `<div class="ban-reason"><span class="ban-reason-label">Reason</span><div class="ban-reason-text">${reasonHtml}</div></div>`
        : `<p class="ban-reason-empty">No specific reason was provided.</p>`}
      <p class="ban-hint">If you believe this is a mistake, please contact the administration through another channel.</p>
      <button class="btn btn-danger ban-logout" id="ban-logout" type="button">Log out</button>
    </div>`;
  document.body.appendChild(el);
  document.getElementById('ban-logout').onclick = async () => {
    const b = document.getElementById('ban-logout');
    if (b) { b.disabled = true; b.textContent = '…'; }
    try { await API.logout(); } catch (e) {}
    location.reload();
  };
}

// Modal that asks a staff member for a ban reason before banning someone.
// Returns the entered reason string, or null if the admin cancels.
function askBanReason(username) {
  return new Promise((resolve) => {
    const scrim = document.createElement('div');
    scrim.className = 'modal-root';
    scrim.style.display = 'flex';
    scrim.innerHTML = `
      <div class="modal-backdrop"></div>
      <div class="modal" style="width:min(420px, calc(94vw / var(--ui-scale, 1)))">
        <div class="modal-head"><h3>Ban ${esc(username)}</h3><button class="modal-x" type="button" aria-label="Close">✕</button></div>
        <div class="modal-body">
          <label style="display:block;margin-bottom:6px;font-size:13px;color:var(--muted)">Reason (will be shown to the user)</label>
          <textarea id="ban-reason-input" class="ban-reason-input" rows="3" maxlength="500" placeholder="e.g. Spam / toxicity / cheating…"></textarea>
          <div style="display:flex;gap:8px;margin-top:14px">
            <button class="btn" id="ban-reason-cancel" type="button" style="flex:1;width:auto;margin-top:0">Cancel</button>
            <button class="btn btn-danger" id="ban-reason-ok" type="button" style="flex:1;width:auto;margin-top:0">Confirm ban</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(scrim);
    const close = (val) => { scrim.remove(); resolve(val); };
    scrim.querySelector('.modal-x').onclick = () => close(null);
    scrim.querySelector('.modal-backdrop').onclick = () => close(null);
    scrim.querySelector('#ban-reason-cancel').onclick = () => close(null);
    scrim.querySelector('#ban-reason-ok').onclick = () => close(scrim.querySelector('#ban-reason-input').value);
    const ta = scrim.querySelector('#ban-reason-input');
    ta.addEventListener('keydown', e => { if (e.key === 'Escape') close(null); });
    setTimeout(() => ta.focus(), 30);
  });
}

/* ---------------- Boot ---------------- */
function clickHandler(e) {
  const a = e.target.closest('[data-action]');
  if (!a) return;
  const act = a.getAttribute('data-action');
  if (act === 'login') { e.preventDefault(); showAuth('login'); }
  if (act === 'register') { e.preventDefault(); showAuth('register'); }
  // Same logout flow as the topbar button — used by the footer link.
  if (act === 'logout') {
    e.preventDefault();
    const btn = document.getElementById('logout-btn');
    if (btn) { btn.click(); return; }
    // Fallback in case the topbar button isn't rendered right now.
    (async () => {
      try { await API.logout(); } catch (_) {}
      state.user = null; await refreshQuickUser(); updateAuth(); closeAdminDropdown();
      if (window.initChat) window.initChat();
      router();
      if (typeof refreshStats === 'function') refreshStats();
    })();
  }
}
async function boot() {
  try {
    renderTopbar();
    try {
      const r = await API.me();
      state.user = r.user;
      if (typeof r.unreadNotif === 'number') setNotifCount(r.unreadNotif);
    } catch (e) {}
    // Banned account: show the full-screen ban lockout and stop here — no forum,
    // no chat, no polling; only the "Log out" button on the ban screen works.
    if (state.user && state.user.banned) { showBanScreen(state.user); return; }
    await refreshQuickUser();
    updateAuth();
    startDmWatcher();
    startNotifWatcher();
    startStatsWatcher();
    await router();
    // Don't start the chat on the standalone reset page (it's hidden there).
    if (parseHash().segs[0] !== 'reset' && window.initChat) window.initChat();
    document.addEventListener('click', clickHandler);
    document.addEventListener('click', (e) => {
      const dd = document.getElementById('admin-dropdown');
      if (!dd || !dd.classList.contains('open')) return;
      if (dd.contains(e.target) || e.target.closest('#admin-trigger')) return;
      closeAdminDropdown();
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { hideAuth(); closeAdminDropdown(); } });
  } finally {
    // Hide the preloader once boot is done (or bailed out early on ban).
    // Wait one frame so the first paint of the app is on-screen before the
    // fade-out starts — avoids a visible "flash of nothing".
    requestAnimationFrame(function () {
      if (typeof window.__wtcHidePreloader === 'function') window.__wtcHidePreloader();
    });
  }
}
window.addEventListener('hashchange', router);
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
