local DEBUG = 1

local http = require "gamesense/http"
local base64 = require "gamesense/base64"
local webhooks = require "gamesense/discord_webhooks"
local md5 = require "gamesense/md5"
local pui = require "gamesense/pui"

local ffi = require "ffi"

-- panorama
local hud = panorama.open("CSGOHud")
local MyPersonaAPI = hud.MyPersonaAPI

-- vars
local current_stage = 0
local total_stages = 0

-- render settings
local fade_in_time = 120
local fill_time = 720
local hold_time = 240
local fade_out_time = 120

-- render data
local w, h = client.screen_size()

local alpha = 0
local y_offset = 50
local scale = 0.8

local anim_timer = 0
local animation_ended = false
local force_fade_out = false

local loader_state = "fade_in" -- fade_in / active / fade_out

local visual_progress = 0

local fade_out_from_alpha = 255
local fade_out_from_y = 0
local fade_out_from_scale = 1.0

local dots_timer = 0
local dots_count = 0

-- packet data
local ip_data = {}
local main_data = {}

local user_data = nil

local init_packet_num = 0

-- personal data
local username = "L41337"
local repository = "-W.tech1337"
local token = "REPLACE_WITH_YOUR_GITHUB_TOKEN"
local github_branch = "main"

local gateway_link = "REPLACE_WITH_YOUR_DISCORD_WEBHOOK"

-- guards
local version_guard = true
local users_guard = true
local load_guard = true
local menu_guard = true

-- refs
local menu_key = pui.reference("MISC", "Settings", "Menu key")

-- blacklist
local blacklisted_processes = {
    "httpdebugger", "httpdebuggerui", "httpdebuggerservice", "httpdebuggerproui",
    "fiddler", "fiddlereverywhere",
    "charles", "charlesproxy",
    "mitmproxy", "mitmweb", "mitmdump",
    "wireshark", "tshark", "rawcap", "networkminer",
    "burpsuite", "burp", "burploader", "burploaderpro",
    "proxyman",
    "smartsniff", "smsniff",
    "httpanalyzer", "httpanalyzerstd", "httpanalyzerfull",
    "reqable", "postman", "insomnia", "httpwatch",
    "ollydbg", "x64dbg", "x32dbg",
    "ida", "ida64", "idaq", "idaq64", "idaw", "idaw64",
    "dnspy", "de4dot",
    "cheatengine", "cheatengine-x86_64",
    "procmon", "procmon64", "procexp", "procexp64",
    "apimonitor", "api_monitor",
}

local blacklisted_windows = {
    "HTTP Debugger", "Fiddler", "Fiddler Everywhere",
    "Charles Web Debugging", "Charles Proxy",
    "mitmproxy", "Wireshark", "Burp Suite",
    "Proxyman", "SmartSniff", "HTTP Analyzer",
    "HTTP Watch", "Telerik Fiddler",
}

-- structs
ffi.cdef[[
    typedef struct {
        uint32_t dwLength;
        uint32_t dwMemoryLoad;
        uint64_t ullTotalPhys;
        uint64_t ullAvailPhys;
        uint64_t ullTotalPageFile;
        uint64_t ullAvailPageFile;
        uint64_t ullTotalVirtual;
        uint64_t ullAvailVirtual;
        uint64_t ullAvailExtendedVirtual;
    } MEMORYSTATUSEX;

    typedef struct {
        uint32_t dwSize;
        uint32_t cntUsage;
        uint32_t th32ProcessID;
        uintptr_t th32DefaultHeapID;
        uint32_t th32ModuleID;
        uint32_t cntThreads;
        uint32_t th32ParentProcessID;
        long pcPriClassBase;
        uint32_t dwFlags;
        char szExeFile[260];
    } PROCESSENTRY32;
]]

-- exports
ffi.cdef[[
    typedef void* (__thiscall* GetModuleHandle)(void* this, const char* szModuleName);
    typedef void* (__thiscall* GetProcAddress)(void* this, void* hModule, const char* szProcName);

    // registry
    typedef int32_t (__thiscall* RegOpenKeyExA)(void* this, void* hKey, const char* lpSubKey, uint32_t ulOptions, uint32_t samDesired, void** phkResult);
    typedef int32_t (__thiscall* RegQueryValueExA)(void* this, void* hKey, const char* lpValueName, uint32_t* lpReserved, uint32_t* lpType, void* lpData, uint32_t* lpcbData);
    typedef int32_t (__thiscall* RegCloseKey)(void* this, void* hKey);

    // hwid
    typedef int (__thiscall* GetVolumeInformationA)(void* this, const char*, char*, unsigned long, unsigned long*, unsigned long*, unsigned long*, char*, unsigned long);
    typedef bool (__thiscall* GlobalMemoryStatusEx)(void* this, MEMORYSTATUSEX* lpBuffer);

    // process
    typedef void* (__thiscall* GetCurrentProcess)(void* this);

    typedef int (__thiscall* Process32First)(void* this, void* hSnapshot, PROCESSENTRY32* lppe);
    typedef int (__thiscall* Process32Next)(void* this, void* hSnapshot, PROCESSENTRY32* lppe);

    typedef bool (__thiscall* TerminateProcess)(void* this, void* hProcess, uint32_t uExitCode);

    // input
    typedef void (__thiscall* keybd_event)(void* this, char bVk, char bScan, int dwFlags, int dwExtraInfo);

    // handle
    typedef void* (__thiscall* CreateToolhelp32Snapshot)(void* this, uint32_t dwFlags, uint32_t th32ProcessID);
    typedef int (__thiscall* CloseHandle)(void* this, void* hObject);

    // debugger
    typedef int (__thiscall* IsDebuggerPresent)(void* this);
    typedef int (__thiscall* CheckRemoteDebuggerPresent)(void* this, void* hProcess, int* pbDebuggerPresent);
    
    typedef uint32_t (__thiscall* GetEnvironmentVariableA)(void* this, const char* lpName, char* lpBuffer, uint32_t nSize);
    
    typedef void* (__thiscall* FindWindowA)(void* this, const char* lpClassName, const char* lpWindowName);

    // message
    typedef int (__thiscall *MessageBoxA)(void* this, void* hWnd, const char* lpText, const char* lpCaption, uint32_t uType);
]]

local GetModuleHandle = ffi.cast("void***", ffi.cast("char*", client.find_signature("client.dll", string.char(0xC6, 0x06, 0x00, 0xFF, 0x15, 0xCC, 0xCC, 0xCC, 0xCC, 0x50))) + 5)[0][0]
local GetProcAddress = ffi.cast("void***", ffi.cast("char*", client.find_signature("client.dll", string.char(0x50, 0xFF, 0x15, 0xCC, 0xCC, 0xCC, 0xCC, 0x85, 0xC0, 0x0F, 0x84, 0xCC, 0xCC, 0xCC, 0xCC, 0x6A, 0x00))) + 3)[0][0]
local CallStub = client.find_signature("client.dll", string.char(0x51, 0xC3))

function create_export(dll, name)
    local module_handle = ffi.cast("GetModuleHandle", CallStub)(GetModuleHandle, dll)
    local proc_address = ffi.cast("GetProcAddress", CallStub)(GetProcAddress, module_handle, name)
    return ffi.cast(name, proc_address)
end

function call_export(name, export, ...)
    return ffi.cast(name, CallStub)(export, ...)
end

-- creating exports
local fnRegOpen = create_export("advapi32.dll", "RegOpenKeyExA")
local fnRegQuery = create_export("advapi32.dll", "RegQueryValueExA")
local fnRegClose = create_export("advapi32.dll", "RegCloseKey")
local fnGetVolumeInformation = create_export("kernel32.dll", "GetVolumeInformationA", "GetVolumeInformationA")
local fnMemStatus = create_export("kernel32.dll", "GlobalMemoryStatusEx")
local fnkeybd_event = create_export("user32.dll", "keybd_event")
local fnCreateToolhelp32Snapshot = create_export("kernel32.dll", "CreateToolhelp32Snapshot")
local fnProcess32First = create_export("kernel32.dll", "Process32First")
local fnProcess32Next = create_export("kernel32.dll", "Process32Next")
local fnCloseHandle = create_export("kernel32.dll", "CloseHandle")
local fnIsDebuggerPresent = create_export("kernel32.dll", "IsDebuggerPresent")
local fnCheckRemoteDebuggerPresent = create_export("kernel32.dll", "CheckRemoteDebuggerPresent")
local fnGetCurrentProcess = create_export("kernel32.dll", "GetCurrentProcess")
local fnGetEnvironmentVariableA = create_export("kernel32.dll", "GetEnvironmentVariableA")
local fnFindWindowA = create_export("user32.dll", "FindWindowA")
local fnMessageBoxA = create_export("user32.dll", "MessageBoxA")
local fnTerminateProcess = create_export("kernel32.dll", "TerminateProcess")

-- math
function clamp(x, min_val, max_val)
    if x < min_val then return min_val end
    if x > max_val then return max_val end
    return x
end

function lerp(a, b, t)
    return a + (b - a) * t
end

function ease_out_cubic(t)
    t = clamp(t, 0, 1)
    t = t - 1
    return t * t * t + 1
end

function ease_in_cubic(t)
    t = clamp(t, 0, 1)
    return t * t * t
end

-- http
function github_headers()
    return {
        Authorization = "token " .. token,
        ["Accept"] = "application/vnd.github+json"
    }
end

function github_contents_url(path)
    return "https://api.github.com/repos/" .. username .. "/" .. repository .. "/contents/" .. path .. "?ref=" .. github_branch
end

function trim_string(value)
    if not value then
        return nil
    end

    return tostring(value):gsub("^%s+", ""):gsub("%s+$", "")
end

function github_get_file(path, callback, timeout_seconds)
    local finished = false
    local timeout = timeout_seconds or 10

    local function finish(result, err)
        if finished then
            return
        end

        finished = true

        client.delay_call(0.01, function()
            callback(result, err)
        end)
    end

    client.delay_call(timeout, function()
        finish(nil, "request timeout")
    end)

    http.get(github_contents_url(path), {
        headers = github_headers()
    }, function(success, response)
        if not success then
            finish(nil, "request failed")
            return
        end

        if not response then
            finish(nil, "empty response")
            return
        end

        if response.status ~= 200 then
            finish(nil, "http status " .. tostring(response.status))
            return
        end

        local ok, api_data = pcall(json.parse, response.body)
        if not ok or not api_data then
            finish(nil, "failed to parse github api response")
            return
        end

        if not api_data.content then
            finish(nil, "missing content field")
            return
        end

        local ok2, decoded = pcall(base64.decode, api_data.content)
        if not ok2 or not decoded then
            finish(nil, "failed to decode base64 content")
            return
        end

        finish(decoded, nil)
    end)
end

function http_get_ip(callback)
    local finished = false

    local function finish(result)
        if finished then
            return
        end

        finished = true

        client.delay_call(0.01, function()
            callback(result)
        end)
    end

    client.delay_call(10, function()
        finish(nil)
    end)

    http.get("https://ipwho.is/", function(success, response)
        if not success or not response or response.status ~= 200 then
            finish(nil)
            return
        end

        local ok, data = pcall(json.parse, response.body)
        if not ok or not data then
            finish(nil)
            return
        end

        local result = {}
        result.ip = data.ip or "Unknown"
        result.country = data.country or "Unknown"
        result.code = "Unknown"

        if data.country_code then
            result.code = ":flag_" .. tostring(data.country_code):lower() .. ":"
        end

        finish(result)
    end)
end

function wait_for_response(request_id, callback)
    local attempts = 0
    local max_attempts = 10
    local poll_delay = 2
    local finished = false
    local target_hwid = main_data and main_data.hwid or nil

    local function finish(user, err)
        if finished then
            return
        end

        finished = true
        callback(user, err)
    end

    local function retry(reason)
        if finished then
            return
        end

        if attempts >= max_attempts then
            finish(nil, reason or ("response timeout after " .. max_attempts .. " attempts"))
            return
        end

        print("[Loader] Internal error, retrying... (" .. attempts .. "/" .. max_attempts .. ")")
        client.delay_call(poll_delay, check)
    end

    function check()
        if finished then
            return
        end

        attempts = attempts + 1

        if not target_hwid or target_hwid == "" then
            finish(nil, "hwid is empty")
            return
        end

        github_get_file("data/users.json", function(decoded, err)
            if finished then
                return
            end

            if not decoded then
                retry("failed to fetch users.json: " .. tostring(err))
                return
            end

            local ok, data = pcall(json.parse, decoded)
            if not ok or not data then
                retry("failed to parse users.json")
                return
            end

            local user = data[target_hwid]
            if not user then
                retry("user not found in mirror")
                return
            end

            if tostring(user.last_request_id) ~= tostring(request_id) then
                retry("request_id mismatch, got " .. tostring(user.last_request_id) .. ", expected " .. tostring(request_id))
                return
            end

            finish(user, nil)
        end, 8)
    end

    check()
end

-- hwid
function get_registry_value(path, key)
    local HKEY_LOCAL_MACHINE = ffi.cast("void*", 0x80000002)
    local phkResult = ffi.new("void*[1]")
    
    -- KEY_READ = 0x20019
    if call_export("RegOpenKeyExA", fnRegOpen, HKEY_LOCAL_MACHINE, path, 0, 0x20019, phkResult) == 0 then
        local lpData = ffi.new("char[256]")
        local lpcbData = ffi.new("uint32_t[1]", 256)
        
        if call_export("RegQueryValueExA", fnRegQuery, phkResult[0], key, nil, nil, lpData, lpcbData) == 0 then
            local res = ffi.string(lpData)
            call_export("RegCloseKey", fnRegClose, phkResult[0])
            return res
        end
        
        call_export("RegCloseKey", fnRegClose, phkResult[0])
    end

    return "unknown"
end

function get_hwid()
    local machine_guid = get_registry_value("SOFTWARE\\Microsoft\\Cryptography", "MachineGuid")
    local cpu_id = get_registry_value("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", "ProcessorNameString")
    
    local mem = ffi.new("MEMORYSTATUSEX")
    mem.dwLength = ffi.sizeof("MEMORYSTATUSEX")
    call_export("GlobalMemoryStatusEx", fnMemStatus, mem)
    local total_ram = tostring(math.floor(tonumber(mem.ullTotalPhys) / (1024 * 1024 * 1024)))

    local disk_serial = ffi.new("unsigned long[1]")
    call_export("GetVolumeInformationA", fnGetVolumeInformation, "C:\\", nil, 0, disk_serial, nil, nil, nil, 0)

    local seed = machine_guid .. cpu_id .. total_ram .. tostring(disk_serial[0])
    local hash_hex = md5.sumhexa(seed)
    
    return string.format("%s-%s-%s-%s", 
        hash_hex:sub(1, 8), 
        hash_hex:sub(9, 16), 
        hash_hex:sub(17, 24), 
        hash_hex:sub(25, 32)
    ):upper()
end

-- webhooks
function send_packet(packet)
    local packet_num = tonumber(database.read("pw_packet_num")) or 0
    packet_num = packet_num + 1

    database.write("pw_packet_num", packet_num)

    packet.request_id = tostring(packet_num)

    -- process webhook
    local webhook = webhooks.new(gateway_link)

    local ok, compressed = pcall(json.stringify, packet)
    if not ok or not compressed then
        return 0
    end

    local ok2, encoded = pcall(base64.encode, compressed)
    if not ok2 or not encoded then
        return 0
    end

    webhook:send(encoded, function(success, response)
        if not success then
            print("[Gateway] Failed to send packet.")
            return
        end

        if response and response.status ~= 204 then
            print("[Gateway] Unexpected status: " .. tostring(response.status))
        end
    end)

    return packet.request_id
end

-- anti-debug
function check_processes()
    local TH32CS_SNAPPROCESS = 0x00000002
    local INVALID_HANDLE_VALUE = ffi.cast("void*", -1)

    local snapshot = call_export("CreateToolhelp32Snapshot", fnCreateToolhelp32Snapshot, TH32CS_SNAPPROCESS, 0)
    if snapshot == nil or snapshot == INVALID_HANDLE_VALUE then
        return false, ""
    end

    local pe = ffi.new("PROCESSENTRY32")
    pe.dwSize = ffi.sizeof("PROCESSENTRY32")

    local result = call_export("Process32First", fnProcess32First, snapshot, pe)

    while result ~= 0 do
        local name = ffi.string(pe.szExeFile):lower():gsub("%.exe$", "")

        for _, blocked in ipairs(blacklisted_processes) do
            if name == blocked:lower() or name:find(blocked:lower(), 1, true) then
                call_export("CloseHandle", fnCloseHandle, snapshot)
                return true, ffi.string(pe.szExeFile)
            end
        end

        result = call_export("Process32Next", fnProcess32Next, snapshot, pe)
    end

    call_export("CloseHandle", fnCloseHandle, snapshot)
    return false, ""
end

function check_windows()
    for _, title in ipairs(blacklisted_windows) do
        local hwnd = call_export("FindWindowA", fnFindWindowA, nil, title)
        if hwnd ~= nil and hwnd ~= ffi.cast("void*", 0) then
            return true, title
        end
    end
    return false, ""
end

function check_native_debugger()
    local result = call_export("IsDebuggerPresent", fnIsDebuggerPresent)
    return result ~= 0, "IsDebuggerPresent"
end

function check_remote_debugger()
    local process = call_export("GetCurrentProcess", fnGetCurrentProcess)
    local flag = ffi.new("int[1]", 0)
    local result = call_export("CheckRemoteDebuggerPresent", fnCheckRemoteDebuggerPresent, process, flag)
    return (result ~= 0 and flag[0] ~= 0), "RemoteDebugger"
end

function check_proxy_env()
    local vars = {"HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY", "all_proxy"}

    for _, name in ipairs(vars) do
        local buf = ffi.new("char[512]")
        local result = call_export("GetEnvironmentVariableA", fnGetEnvironmentVariableA, name, buf, 512)

        if result ~= nil and tonumber(result) ~= nil and tonumber(result) > 0 then
            local value = ffi.string(buf)
            if value ~= "" then
                return true, name .. "=" .. value
            end
        end
    end

    return false, ""
end

function check_suspicious_modules()
    local modules = {"fiddlercore", "fiddler.certmaker", "titanium", "bouncycastle"}

    for _, name in ipairs(modules) do
        local handle = ffi.cast("GetModuleHandle", CallStub)(GetModuleHandle, name .. ".dll")
        if handle ~= nil and handle ~= ffi.cast("void*", 0) then
            return true, name
        end
    end

    return false, ""
end

function debugger_crash()
    -- create messagebox
    call_export(
        "MessageBoxA",
        fnMessageBoxA,
        nil,
        "Security violation detected.\nThe loader cannot continue.",
        "W.TECH Security",
        0x00000010
    )

    -- crash game
    local hProcess = call_export("GetCurrentProcess", fnGetCurrentProcess)
    call_export("TerminateProcess", fnTerminateProcess, hProcess, 1)
end

function on_debugger_detected(reason)
    if current_stage == -2 then
        return
    end

    database.write("pw_debugger", 1)

    current_stage = -2
    client.unset_event_callback("paint_ui", handler)

    -- send anti-debug packet
    local anti_debug_packet = {}
    anti_debug_packet.main = main_data
    anti_debug_packet.type = "anti_debug"
    
    anti_debug_packet.reason = reason

    send_packet(anti_debug_packet)

    -- crash game
    debugger_crash()
end

function anti_debug()
    local detected, reason

    detected, reason = check_processes()
    if detected then
        on_debugger_detected("Blocked process: " .. reason)
        return
    end

    detected, reason = check_windows()
    if detected then
        on_debugger_detected("Debugger window: " .. reason)
        return
    end

    detected, reason = check_native_debugger()
    if detected then
        on_debugger_detected("Native debugger")
        return
    end

    detected, reason = check_remote_debugger()
    if detected then
        on_debugger_detected("Remote debugger")
        return
    end

    detected, reason = check_proxy_env()
    if detected then
        on_debugger_detected("Proxy: " .. reason)
        return
    end

    detected, reason = check_suspicious_modules()
    if detected then
        on_debugger_detected("Suspicious module: " .. reason)
        return
    end
end

-- ban system
function ban_handler()
    if not user_data then
        return
    end

    if user_data.status ~= "banned" then
        return
    end

    if current_stage == -2 then
        return
    end

    current_stage = -2
    client.unset_event_callback("paint_ui", handler)
    client.set_event_callback("paint_ui", draw_ban)
end

function draw_ban()
    if current_stage ~= -2 then
        return
    end

    local alpha = 255
    local reason = user_data and user_data.ban_reason or "No reason provided."

    renderer.rectangle(0, 0, w, h, 0, 0, 0, 200)
    renderer.text(w / 2, h / 2 - 30, 255, 0, 0, alpha, "c", 0, "YOU ARE BANNED")
    renderer.text(w / 2, h / 2 + 0, 255, 200, 200, alpha, "c", 0, "Your HWID has been banned.")
    renderer.text(w / 2, h / 2 + 25, 255, 180, 180, alpha, "c", 0, "Reason: " .. tostring(reason))
    renderer.text(w / 2, h / 2 + 50, 200, 200, 200, alpha, "c", 0, "Contact support for more information.")
end

-- infinity loop
function loop()
    if current_stage == -2 then
        return
    end

    anti_debug()

    http.get("https://api.github.com/repos/" .. username .. "/" .. repository .. "/contents/data/users.json", {
        headers = { Authorization = "token " .. token }
    }, function(success, response)
        if not success or not response or response.status ~= 200 then
            return
        end

        local ok, api_data = pcall(json.parse, response.body)
        if not ok or not api_data or not api_data.content then
            return
        end

        local ok2, decoded = pcall(base64.decode, api_data.content)
        if not ok2 or not decoded then
            return
        end

        local ok3, data = pcall(json.parse, decoded)
        if not ok3 or not data then
            return
        end

        local user = data[main_data.hwid]
        if user then
            user_data = user
        end
    end)

    ban_handler()

    if current_stage ~= -2 then
        client.delay_call(5, loop)
    end
end

-- render
function get_target_progress()
    return clamp(current_stage / total_stages, 0, 1)
end

function update_visual_progress()
    local target = get_target_progress()

    visual_progress = lerp(visual_progress, target,  0.10)

    if math.abs(visual_progress - target) < 0.001 then
        visual_progress = target
    end

    return visual_progress
end

function start_fade_out()
    if loader_state == "fade_out" or animation_ended then
        return
    end

    loader_state = "fade_out"
    anim_timer = 0

    fade_out_from_alpha = alpha
    fade_out_from_y = y_offset
    fade_out_from_scale = scale
end

function draw_loader(alpha_value, y_off, scale_value)
    if alpha_value <= 0 then
        return
    end

    local current_y = h / 2 + y_off

    renderer.rectangle(0, 0, w, h, 0, 0, 0, alpha_value * 0.85)
    renderer.text(w / 2, current_y - 40, 255, 50, 50, alpha_value, "c+", 0, "(◣ _ ◢)")
    renderer.text(w / 2, current_y - 15, 255, 255, 255, alpha_value, "c+", 0, "+W.TECH FREE LOADER")
    
    local welcome_text

    if user_data and user_data.owner and user_data.owner ~= "" then
        welcome_text = "Welcome back, " .. user_data.owner
    else
        dots_timer = dots_timer + 1

        if dots_timer >= 30 then
            dots_timer = 0
            dots_count = (dots_count % 3) + 1
        end

        welcome_text = "Loading" .. string.rep(".", dots_count)
    end

    renderer.text(w / 2, current_y + 10, 200, 200, 200, alpha_value, "c", 0, welcome_text)

    local build_text = " loader version "
    local version_text = database.read("pw_version") or "unknown"

    local build_width = renderer.measure_text(nil, build_text)
    local version_width = renderer.measure_text(nil, version_text)

    local total_width = build_width + version_width
    local start_x = w / 2 - total_width / 2

    renderer.text(start_x, current_y + 35, 255, 255, 255, alpha_value, nil, 0, build_text)
    renderer.text(start_x + build_width, current_y + 35, 255, 50, 50, alpha_value, nil, 0, version_text)
    
    local progress = update_visual_progress()

    local radius = 10 * scale_value
    local circle_y = current_y + 60

    renderer.circle_outline(w / 2, circle_y, 60, 60, 60, alpha_value, radius, 0, 1, 2 * scale_value)

    if progress > 0 then
        renderer.circle_outline(w / 2, circle_y, 255, 50, 50, alpha_value, radius, 0, progress, 2.5 * scale_value)
    end

    local percent = math.floor(progress * 100 + 0.5)
    renderer.text(w / 2, circle_y + radius + 15, 255, 255, 255, alpha_value, "c", 0, percent .. "%")
end

function update_animation()
    if animation_ended then
        return
    end

    if force_fade_out then
        start_fade_out()
    end

    anim_timer = anim_timer + 1

    if loader_state == "fade_in" then
        local t = math.min(anim_timer / fade_in_time, 1.0)
        local e = ease_out_cubic(t)

        alpha = lerp(0, 255, e)
        y_offset = lerp(50, 0, e)
        scale = lerp(0.8, 1.0, e)

        if t >= 1.0 then
            loader_state = "active"
            anim_timer = 0
            alpha = 255
            y_offset = 0
            scale = 1.0
        end

    elseif loader_state == "active" then
        alpha = 255
        y_offset = 0
        scale = 1.0

    elseif loader_state == "fade_out" then
        local t = math.min(anim_timer / fade_out_time, 1.0)
        local e = ease_in_cubic(t)

        alpha = lerp(fade_out_from_alpha, 0, e)
        y_offset = lerp(fade_out_from_y, -30, e)
        scale = lerp(fade_out_from_scale, 0.9, e)

        if t >= 1.0 or alpha <= 0 then
            animation_ended = true
            return
        end
    end

    draw_loader(alpha, y_offset, scale)
end

-- menu
function close_menu()
    local state, mode, key = menu_key:get()
    call_export("keybd_event", fnkeybd_event, key, 0, 0, 0)
    call_export("keybd_event", fnkeybd_event, key, 0, 2, 0)
end

-- INITIALIZE

-- check instant ban
if database.read("pw_debugger") == 1 then
    debugger_crash()
end

-- init user info
http_get_ip(function(result)
    if result then
        ip_data = result
        current_stage = 1

        if DEBUG == 1 then
            print("[Loader] IP: " .. tostring(result.ip) .. " / " .. tostring(result.country))
        end
    else
        print("[Loader] Failed to fetch IP data.")
        current_stage = -1
    end
end)

-- main handler
function handler()
    if menu_guard then
        menu_guard = false

        -- close menu
        close_menu()
    end

    if current_stage == -1 then -- oops, error!
        return
    elseif current_stage == 1 then -- construct main data
        if DEBUG == 1 then
            print("[Loader] Building main_data...")
        end

        -- build main packet
        main_data.hwid = get_hwid()
        main_data.xuid = MyPersonaAPI.GetXuid()
        main_data.name = MyPersonaAPI.GetName()
        main_data.version = database.read("pw_version") or "unknown"

        main_data.ip = ip_data

        if DEBUG == 1 then
            print("[Loader] HWID: " .. tostring(main_data.hwid))
            print("[Loader] XUID: " .. tostring(main_data.xuid))
            print("[Loader] Name: " .. tostring(main_data.name))
        end

        -- send init packet
        local init_packet = {}
        init_packet.main = main_data
        init_packet.type = "init"
        
        init_packet_num = send_packet(init_packet)

        if DEBUG == 1 then
            print("[Loader] Init packet sent, request_id: " .. tostring(init_packet_num))
        end

        if init_packet_num == 0 then
            print("[Loader] Failed to send initialization packet to gateway.")
            current_stage = -1
            return
        end

        current_stage = 2
    elseif current_stage == 2 then -- start loop & anti-debug
        if DEBUG == 1 then
            print("[Loader] Starting anti_debug and loop...")
        end

        anti_debug()
        loop()

        current_stage = 3
    elseif current_stage == 3 and version_guard then -- fetching new version
        version_guard = false

        if DEBUG == 1 then
            print("[Loader] Fetching version...")
        end

        github_get_file("version", function(version, err)
            version = trim_string(version)

            if version and version ~= "" then
                database.write("pw_version", version)
                if DEBUG == 1 then
                    print("[Loader] Version: " .. tostring(version))
                end
            else
                print("[Loader] Failed to fetch version, using cached. " .. tostring(err))
            end

            current_stage = 4
        end, 8)
    elseif current_stage == 4 and users_guard then -- parse users
        users_guard = false

        if DEBUG == 1 then
            print("[Loader] Waiting for server response...")
        end

        wait_for_response(init_packet_num, function(user, err)
            if not user then
                print("[Loader] Failed to get response from server: " .. tostring(err))
                current_stage = -1
                return
            end

            user_data = user
            current_stage = 5
        end)
    elseif current_stage == 5 then -- process current user
        if not user_data then
            current_stage = -1
            return
        end

        if DEBUG == 1 then
            print("[Loader] Processing user, status: " .. tostring(user_data.status))
        end

        -- first protection hack!
        ban_handler()

        if current_stage == -2 then
            return
        end

        if user_data.status == "unregistered" then
            print("[Loader] Access denied: your HWID is not registered. Use /getlua in Discord.")
            current_stage = -1
            return
        end

        current_stage = 6
    elseif current_stage == 6 and load_guard then -- load script
        load_guard = false

        if DEBUG == 1 then
            print("[Loader] Loading W-TECH.lua...")
        end

        github_get_file("W-TECH.lua", function(code, err)
            if not code or code == "" then
                print("[Loader] Failed to get script: " .. tostring(err))
                current_stage = -1
                return
            end

            local func, compile_err = load(code, "WTECH", "t")

            if not func then
                print("[Loader] Failed to compile script: " .. tostring(compile_err))
                current_stage = -1
                return
            end

            local success, runtime_err = pcall(func)

            if not success then
                print("[Loader] Script runtime error: " .. tostring(runtime_err))
                current_stage = -1
                return
            end

            current_stage = 7
        end, 10)
    elseif current_stage == 7 then -- finalize animation
        force_fade_out = true
        
        if animation_ended then
            if DEBUG == 1 then
                print("[Loader] Animation ended, unloading handler.")
            end

            client.unset_event_callback("paint_ui", handler)
            return
        end
    end

    -- update animation
    update_animation()
end

-- set total stages
total_stages = 7

-- setup handler
client.set_event_callback("paint_ui", handler)