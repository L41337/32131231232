<?php
require_once __DIR__ . '/security.php';
sec_headers();
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: public, max-age=0, must-revalidate');
?>
'use strict';

function initChat() {
  // tear down any previous instance (so login can re-init chat in place)
  if (window.__pollInterval) { clearInterval(window.__pollInterval); window.__pollInterval = null; }
  if (window.__chatSocket) { try { window.__chatSocket.disconnect(); } catch (e) {} window.__chatSocket = null; }

  const messagesEl = document.getElementById('chat-messages');
  const presence = document.getElementById('chat-presence');
  const typingEl = document.getElementById('chat-typing');
  let input = document.getElementById('chat-input');
  let sendBtn = document.getElementById('chat-send');

  // reset + drop old event listeners by cloning the nodes
  input.setAttribute('contenteditable', 'true');
  input.dataset.placeholder = 'Message…';
  input.classList.remove('chat-input-disabled');
  input.innerHTML = '';
  sendBtn.disabled = false;
  const ni = input.cloneNode(true); input.parentNode.replaceChild(ni, input); input = ni;
  const ns = sendBtn.cloneNode(true); sendBtn.parentNode.replaceChild(ns, sendBtn); sendBtn = ns;
  messagesEl.innerHTML = '';

  const appended = new Set();
  let lastId = 0;
  let typingTimer = null;
  // Прикреплённая картинка живёт ТОЛЬКО здесь (и в чипе-превью). URL больше
  // не вставляется в поле ввода — сырый «/assets/uploads/…» юзер не видит.
  let pendingImage = null;

  // Текст сообщения + автопревью картинок по ссылке. Картинкой считается
  // слово-URL (http://, https://, //host/ или /assets/uploads/…, то есть и
  // загруженные на сайт файлы тоже) с расширением png/jpg/jpeg/gif/webp.
  // Прочие ссылки остаются обычным текстом, как и раньше. Всё собирается
  // через DOM-ноды (никакого innerHTML) → XSS исключён.
  function renderChatText(body, content) {
    body.appendChild(document.createTextNode(' '));
    const imgUrl = /^((?:https?:)?\/\/|\/)[^\s'"<>]+?\.(png|jpe?g|gif|webp)(\?[^\s'"<>]*)?$/i;
    // split с захватом: чётные элементы — текст, нечётные — разделители.
    for (const part of content.split(/(\s+)/)) {
      if (!part) continue;
      if (imgUrl.test(part)) {
        const a = document.createElement('a');
        a.href = part; a.target = '_blank'; a.rel = 'noopener nofollow ugc'; a.className = 'chat-imgwrap';
        const img = document.createElement('img');
        img.className = 'chat-img'; img.loading = 'lazy'; img.alt = 'image'; img.draggable = false;
        img.referrerPolicy = 'no-referrer';
        img.src = part;
        a.appendChild(img);
        body.appendChild(a);
      } else {
        // @упоминания: ролевой цвет (роли присылает сервер в mentionRoles;
        // неизвестный ник остаётся обычным текстом). Якоря создаются нодами —
        // XSS по-прежнему исключён.
        for (const seg of part.split(/(@[A-Za-z0-9_][A-Za-z0-9_.\-]{2,19})(?![A-Za-z0-9_.\-])/)) {
          if (!seg) continue;
          const mm = /^@([A-Za-z0-9_][A-Za-z0-9_.\-]{2,19})$/.exec(seg);
          const mnode = mm && typeof mentionAnchor === 'function' ? mentionAnchor(mm[1]) : null;
          body.appendChild(mnode || document.createTextNode(seg));
        }
      }
    }
  }

  function appendMessage(m) {
    if (m.id && appended.has(m.id)) return;
    if (m.id) appended.add(m.id);
    // Bot notices ("Антиспам") don't belong to a real account: they must not
    // link to #/profile/<botname> — that route 404s into a broken page.
    const isBot = m.role === 'bot';
    const div = document.createElement('div');
    div.className = 'chat-msg';
    const tmp = document.createElement('div');
    tmp.innerHTML = avatarHTML({ username: m.username, role: m.role, avatar: m.avatar, avatarBorder: m.avatarBorder, color: m.color }, 'avatar sm');
    const av = tmp.firstElementChild;
    if (!isBot) {
      av.style.cursor = 'pointer';
      av.title = 'View profile';
      av.onclick = () => { location.hash = '#/profile/' + encodeURIComponent(m.username); };
    }
    const text = document.createElement('div');
    text.className = 'chat-textwrap';
    const name = document.createElement(isBot ? 'span' : 'a');
    name.className = 'chat-name'; name.style.color = nameColor({ color: m.color, role: m.role }); name.textContent = m.username + ':';
    if (!isBot) name.href = '#/profile/' + encodeURIComponent(m.username);
    const body = document.createElement('span');
    body.className = 'chat-text';
    renderChatText(body, m.content);
    text.appendChild(name); text.appendChild(body);
    div.appendChild(av);
    div.appendChild(text);
    messagesEl.appendChild(div);
    emojiParse(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    if (m.id > lastId) lastId = m.id;
  }

  const loggedIn = window.state && window.state.user;
  if (!loggedIn) {
    input.setAttribute('contenteditable', 'false');
    input.dataset.placeholder = 'Log in to chat';
    input.classList.add('chat-input-disabled');
    sendBtn.disabled = true;
    // Guests get NO emoji picker: remove a trigger button that may be left
    // over from a previous logged-in session (logout re-inits the chat in
    // place) and close the popover if it was open. Was the source of a
    // broken, stretched input row when a logged-out user clicked it.
    const wrapGuest = input.parentNode;
    const leftover = wrapGuest && wrapGuest.querySelector('.emoji-trigger');
    if (leftover) leftover.remove();
    if (typeof hideEmoji === 'function') hideEmoji();
    const info = document.createElement('div');
    info.className = 'chat-info';
    info.textContent = '🔒 Log in to join the conversation.';
    messagesEl.appendChild(info);
    return;
  }

  // Emoji picker button (left of the chat input).
  if (typeof toggleEmoji === 'function') {
    const wrap = input.parentNode;
    let emojiBtn = wrap.querySelector('.emoji-trigger');
    if (!emojiBtn) {
      emojiBtn = document.createElement('button');
      emojiBtn.type = 'button'; emojiBtn.className = 'btn emoji-trigger'; emojiBtn.textContent = '😊';
      wrap.insertBefore(emojiBtn, input);
    }
    // Re-bind on EVERY init: the live input node gets cloned+replaced on each
    // initChat() run (login/logout/avatar refresh), so a handler that closed
    // over the old node would insert emojis into a DETACHED element and the
    // picker would open for a stale target. Always resolve the CURRENT node.
    emojiBtn.dataset.emojiFor = 'chat-input';
    emojiBtn.onmousedown = e => e.preventDefault();
    emojiBtn.onclick = (e) => {
      e.preventDefault(); e.stopPropagation();
      toggleEmoji(document.getElementById('chat-input') || input, emojiBtn);
    };
    if (!emojiBtn.__hoverBound) { emojiBtn.__hoverBound = 1; bindEmojiHover(input, emojiBtn); }
  }

  // ---- Кнопка 📎: загрузка картинки в чат ----
  // Используем готовый безопасный attachment_upload (mime+magic-проверка,
  // случайное имя, .htaccess в uploads). После загрузки URL кладётся в поле
  // ввода, а над ним появляется превью-чип (можно отменить крестиком).
  (function setupImageUpload() {
    // API — это top-level const (НЕ window.*), поэтому проверяем через typeof.
    if (typeof API === 'undefined' || typeof API.attachmentUpload !== 'function') return;
    const wrap2 = input.parentNode;
    const old = wrap2.querySelector('.chat-imgbtn'); if (old) old.remove();
    const oldF = wrap2.querySelector('.chat-fileinp'); if (oldF) oldF.remove();
    const imgBtn = document.createElement('button');
    imgBtn.type = 'button'; imgBtn.className = 'btn chat-imgbtn'; imgBtn.textContent = '📎';
    imgBtn.title = 'Send an image (png / jpg / gif / webp)';
    wrap2.insertBefore(imgBtn, input);
    const fileInp = document.createElement('input');
    fileInp.type = 'file'; fileInp.className = 'chat-fileinp';
    fileInp.accept = 'image/png,image/jpeg,image/gif,image/webp';
    fileInp.style.display = 'none';
    wrap2.appendChild(fileInp);
    imgBtn.onclick = (e) => { e.preventDefault(); fileInp.click(); };
    fileInp.onchange = async () => {
      const f = fileInp.files && fileInp.files[0];
      fileInp.value = '';
      if (!f) return;
      if (f.size > 15 * 1024 * 1024) { toast('Image is too large (max 15 MB)', 'warn'); return; }
      imgBtn.textContent = '⏳'; imgBtn.classList.add('busy');
      try {
        const fd = new FormData();
        // Большие фото сжимаем на клиенте (canvas до 1600px) — иначе сервер
        // с upload_max_filesize=2M отвергал файл, картинка не отправлялась.
        const upFile = (typeof window.wtechOptimizeImage === 'function') ? await window.wtechOptimizeImage(f) : f;
        fd.append('file', upFile);
        const r = await API.attachmentUpload(fd);
        pendingImage = r.url;          // в текст поля ввода путь НЕ попадает
        showUploadChip(r.url);
        input.focus();
      } catch (e2) { toast(e2.message || 'Upload failed', 'error'); }
      finally { imgBtn.textContent = '📎'; imgBtn.classList.remove('busy'); }
    };
    function showUploadChip(url) {
      const oldChip = document.getElementById('chat-upload-chip');
      if (oldChip) oldChip.remove();
      const chip = document.createElement('div');
      chip.id = 'chat-upload-chip'; chip.className = 'chat-upload-chip';
      const im = document.createElement('img'); im.src = url; im.alt = '';
      const lbl = document.createElement('span'); lbl.className = 'muted'; lbl.textContent = 'ready to send';
      const x = document.createElement('button'); x.type = 'button'; x.title = 'Remove'; x.textContent = '✕';
      x.onclick = () => {
        if (pendingImage === url) pendingImage = null;
        chip.remove();
        if (input.textContent === '') input.innerHTML = '';
      };
      chip.appendChild(im); chip.appendChild(lbl); chip.appendChild(x);
      const wrapEl = document.querySelector('#chat .chat-input-wrap');
      if (wrapEl) wrapEl.parentNode.insertBefore(chip, wrapEl);
      // Чип — не вечный: через минуту бездействия убираем аттач. отправка
      // (send) снимает его сразу после успешной отправки, не дожидаясь таймера.
      setTimeout(() => { if (chip.isConnected) { chip.remove(); if (pendingImage === url) pendingImage = null; } }, 60000);
    }
  })();

  function showTyping(names) {
    typingEl.textContent = (names && names.length) ? names.join(', ') + ' typing…' : '';
  }

  // ---- Node.js: real-time via Socket.IO ----
  if (API.mode === 'node' && typeof io !== 'undefined') {
    const socket = io();
    window.__chatSocket = socket;
    socket.on('chat:message', appendMessage);
    socket.on('chat:presence', p => {
      const n = p.count || 0;
      // Push the fresh count into BOTH the chat pill and the hero-stats
      // "Online" number in one call, and cache it so refreshStats() doesn't
      // overwrite it with a slightly-stale value from the general stats endpoint.
      window.__lastOnline = n;
      if (typeof window.setOnlineCount === 'function') window.setOnlineCount(n);
      else presence.textContent = n + ' online';
      const names = (p.users || []).map(u => u.username);
      presence.title = 'Online: you' + (names.length ? ', ' + names.join(', ') : '');
    });
    socket.on('chat:typing', d => { typingEl.textContent = (d.username || 'Someone') + ' is typing…'; clearTimeout(typingTimer); typingTimer = setTimeout(() => typingEl.textContent = '', 1500); });
    // Live DM delivery: bump the unread badge immediately, and if we're viewing
    // that conversation, append the message in place.
    socket.on('dm:message', (data) => {
      refreshDmBadge();
      if (typeof window.__onDmMessage === 'function') window.__onDmMessage(data);
    });
    API.chatHistory().then(d => { if (typeof mentionRolesMerge === 'function') mentionRolesMerge(d.mentionRoles); (d.messages || []).forEach(appendMessage); }).catch(() => {});

    function send() {
      let v = getTextValue(input).trim();
      const url = pendingImage;
      if (!v && !url) return;
      if (url) v = (v ? v + ' ' : '') + url;
      socket.emit('chat:message', v);
      input.innerHTML = '';
      // Чип «ready to send» исчезает сразу после отправки.
      pendingImage = null;
      const c0 = document.getElementById('chat-upload-chip'); if (c0) c0.remove();
    }
    sendBtn.onclick = send;
    input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } else socket.emit('chat:typing'); });
    input.addEventListener('input', () => { if (input.textContent === '') input.innerHTML = ''; });
    input.addEventListener('paste', sanitizePaste);
    return;
  }

  // ---- PHP/Beget: AJAX polling ----
  API.chatHistory().then(d => { if (typeof mentionRolesMerge === 'function') mentionRolesMerge(d.mentionRoles); (d.messages || []).forEach(appendMessage); }).catch(() => {});

  async function poll() {
    try {
      const d = await API.chatPoll(lastId);
      // Карту ролей сливаем ДО рендера — иначе свежие @ники останутся серыми.
      if (typeof mentionRolesMerge === 'function') mentionRolesMerge(d.mentionRoles);
      (d.messages || []).forEach(appendMessage);
      if (d.presence) {
        const n = d.presence.count || 0;
        // Update both the chat pill AND the hero-stats "Online" counter at
        // the same time — no more waiting for the slower stats poll.
        window.__lastOnline = n;
        if (typeof window.setOnlineCount === 'function') window.setOnlineCount(n);
        else presence.textContent = n + ' online';
        const names = (d.presence.users || []).map(u => u.username);
        presence.title = 'Online: you' + (names.length ? ', ' + names.join(', ') : '');
      }
      showTyping(d.typing);
      // Колокольчик уведомлений: chat_poll таскает актуальный счётчик.
      if (typeof window.setNotifCount === 'function' && typeof d.notif === 'number') window.setNotifCount(d.notif);
    } catch (e) { /* ignore transient errors */ }
  }
  poll();
  // 1.5 s poll (was 2.5 s) — keeps chat + the live Online counter close to
  // real-time without meaningful extra server load (one small GET per user).
  window.__pollInterval = setInterval(poll, 1500);
  // Instant refresh when the user comes back to the tab, so the counter
  // catches up the moment they look at it again.
  document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });

  function send() {
    let v = getTextValue(input);
    const url = pendingImage;
    // Лимит 500 считаем с учётом URL картинки (+1 на пробел между ними),
    // чтобы сервер не обрезал хвост ссылки.
    const cap = url ? 500 - url.length - 1 : 500;
    if (v.length > cap) v = v.slice(0, cap);
    const text = v.trim();
    if (!text && !url) { input.innerHTML = ''; return; }
    input.innerHTML = '';
    API.chatSend(url ? (text ? text + ' ' : '') + url : v)
      .then(m => {
        if (typeof mentionRolesMerge === 'function') mentionRolesMerge(m && m.mentionRoles);
        if (m && m.message) appendMessage(m.message);
        // Успешная отправка — чип «ready to send» исчезает сразу.
        pendingImage = null;
        const c0 = document.getElementById('chat-upload-chip'); if (c0) c0.remove();
      })
      .catch(e => {
        // Blocked by anti-spam (or another error): вернуть только текст (чип
        // с картинкой остаётся на месте — аттач не теряется, сырой путь в
        // поле не показываем).
        if (text) input.textContent = text;
        toast(e.message || 'Message blocked (anti-spam).', 'error');
      });
  }
  sendBtn.onclick = send;
  let typingThrottle = 0;
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
    else { const now = Date.now(); if (now - typingThrottle > 2000) { typingThrottle = now; API.chatTyping().catch(() => {}); } }
  });
  input.addEventListener('input', () => { if (input.textContent === '') input.innerHTML = ''; });
  input.addEventListener('paste', sanitizePaste);
}
window.initChat = initChat;
