<?php
// Prevent direct web access (this file is only meant to be included)
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(403);
    exit('Forbidden');
}

/* =====================================================================
   EDIT THESE TO MATCH THE DATABASE YOU CREATE IN THE BEGET PANEL
   ---------------------------------------------------------------------
   !!! SECURITY WARNING — TREAT THE PASSWORD BELOW AS COMPROMISED !!!
   This file (with the real DB password) was published in a PUBLIC GitHub
   repository. Anyone could have read it. Do BOTH of these now:
     1. In the Beget panel change the MySQL user's PASSWORD, then update
        DB_PASS here (the site will break until the two match).
     2. Log into the forum as the owner and change the seeded forum
        account passwords from the README as well.
   Each value can also be supplied via environment variable (WTECH_DB_HOST,
   WTECH_DB_NAME, WTECH_DB_USER, WTECH_DB_PASS) — it wins when set; the
   literal fallback keeps the current deploy working unchanged.
   ===================================================================== */
define('DB_HOST', getenv('WTECH_DB_HOST') ?: 'localhost');          // usually 'localhost' on Beget shared
define('DB_NAME', getenv('WTECH_DB_NAME') ?: 'l43087cr_1337');      // name of the DB you create
define('DB_USER', getenv('WTECH_DB_USER') ?: 'l43087cr_1337');      // DB user you create
define('DB_PASS', getenv('WTECH_DB_PASS') ?: 'grec3772123@');       // DB user password — ROTATE IT (see warning above)
/* ===================================================================== */

define('SITE_NAME', '+W.TECH FORUM');

/* =====================================================================
   SITE / MAIL SETTINGS — used for password-reset emails. EDIT THESE.
   SITE_URL  : public base URL of the forum, NO trailing slash. Used to
               build the reset link. NEVER build this from the request
               Host header (that would allow host-header injection into
               the reset email and leak the token).
   MAIL_FROM : the "From" address. On Beget this should be a REAL mailbox
               on this server (create e.g. noreply@your-domain in the
               Beget mail section), otherwise mail() can be rejected.
   RESET_TTL : how long a reset link stays valid, in seconds.
   ===================================================================== */
// If you enable the free SSL certificate in the Beget panel, switch this to
// https:// AND uncomment the HTTPS redirect at the bottom of .htaccess.
define('SITE_URL',  'http://l43087cr.beget.tech');
define('MAIL_FROM', 'noreply@l43087cr.beget.tech');
define('MAIL_NAME', '+W.TECH FORUM');
define('RESET_TTL', 300);
