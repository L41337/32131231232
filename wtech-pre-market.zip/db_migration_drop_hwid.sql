-- ============================================================
-- Migration: drop the legacy HWID column from `users`
-- ============================================================
-- The site no longer uses HWID anywhere (registration, profile,
-- API). Existing rows keep working whether or not you run this —
-- the code falls back automatically if the column still exists.
--
-- Run this ONCE in phpMyAdmin (database l43087cr_1337, tab SQL)
-- after uploading the updated api.php and functions.php.
--
-- If you already dropped the column, MySQL will reply with error
-- #1091 "Can't DROP 'hwid'; check that it exists" — that is fine,
-- it just means the migration is already applied.
-- ============================================================

ALTER TABLE `users` DROP COLUMN `hwid`;
