-- ============================================================
-- Миграция: Центр уведомлений (колокольчик в шапке)
-- Запустить ОДИН раз в phpMyAdmin поверх существующей базы.
-- Идемпотентно: CREATE TABLE IF NOT EXISTS.
-- ============================================================
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,                  -- получатель
  `type`       VARCHAR(24)  NOT NULL,                  -- reply_thread/mention/mention_chat/dm/ticket_*/config_like
  `actor_name` VARCHAR(32)  NOT NULL DEFAULT '',       -- ник вызвавшего событие (снимок)
  `title`      VARCHAR(190) NOT NULL DEFAULT '',       -- тема / тикет / превью ЛС
  `link`       VARCHAR(190) NOT NULL DEFAULT '',       -- куда вести (#-маршрут без '#')
  `cnt`        INT UNSIGNED NOT NULL DEFAULT 1,        -- одинаковые непрочитанные схлопываются
  `unread`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_notif_user` (`user_id`, `unread`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
