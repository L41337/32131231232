<?php
// Prevent direct web access
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(403);
    exit('Forbidden');
}
require_once __DIR__ . '/config.php';

/* ---------------- Database ---------------- */
function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE          => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function db_val($sql, $params = []) { $s = db()->prepare($sql); $s->execute($params); return $s->fetchColumn(); }
function db_row($sql, $params = []) { $s = db()->prepare($sql); $s->execute($params); return $s->fetch(); }
function db_all($sql, $params = []) { $s = db()->prepare($sql); $s->execute($params); return $s->fetchAll(); }

/* ---------------- Request helpers ---------------- */
function param($k, $default = null) {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $ct = $_SERVER['CONTENT_TYPE'] ?? '';
        if (stripos($ct, 'application/json') !== false) {
            static $body = null;
            if ($body === null) {
                // Cap the read length so a huge body can't exhaust memory
                // (also covers chunked transfers that omit Content-Length).
                $max = defined('SEC_MAX_BODY') ? (int)SEC_MAX_BODY + 4096 : 20 * 1024 * 1024;
                $raw = file_get_contents('php://input', false, null, 0, $max);
                $body = json_decode($raw, true) ?: [];
            }
            if (isset($body[$k])) return $body[$k];
        }
        if (isset($_POST[$k])) return $_POST[$k];
    }
    return $_GET[$k] ?? $default;
}
function json_out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function esc($s) { return htmlspecialchars((string)($s ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8'); }
// UTF-8-safe length limit without requiring the mbstring extension.
function utf8_limit($s, $n) { $s = (string)($s ?? ''); if (preg_match('/^(.{' . (int)$n . '})/su', $s, $m)) return $m[1]; return $s; }

/* ---------------- Auth / users ---------------- */
function current_user() {
    if (empty($_SESSION['user_id'])) return null;
    $u = db_row('SELECT * FROM users WHERE id=?', [$_SESSION['user_id']]);
    return $u ?: null;
}
function is_staff($u) { return $u && in_array($u['role'], ['owner', 'admin'], true); }
// Moderation level: owner, admin AND moderator. Moderators manage threads
// (pin/lock/delete) and tickets (view all, reply, change status, delete) but
// CANNOT ban users, change roles or edit categories — those require is_staff().
function is_mod($u) { return $u && in_array($u['role'], ['owner', 'admin', 'moderator'], true); }
// Ticket desk level: owner, admin, moderator AND support. The support role
// answers and closes tickets only — no thread moderation, no admin powers.
function is_ticket_staff($u) { return $u && in_array($u['role'], ['owner', 'admin', 'moderator', 'support'], true); }
// Loader download access: the "customer" role is the key; owner/admin keep
// access as well. Everyone else (member/support/moderator) gets 403.
function can_download($u) { return $u && ($u['role'] === 'customer' || in_array($u['role'], ['owner', 'admin'], true)); }

// The on-disk loader file. Canonical name is `loader.lua` — the admin-upload
// endpoint always saves under this name no matter how the uploaded file was
// called, and the download endpoint serves it as "loader.lua". `W-TECH.lua`
// remains only as a legacy fallback so an existing deploy keeps working
// until the first admin upload replaces it.
function loader_file_path() {
    $dir = __DIR__ . '/assets/lua';
    if (is_file($dir . '/loader.lua')) return $dir . '/loader.lua';
    if (is_file($dir . '/W-TECH.lua')) return $dir . '/W-TECH.lua';
    return null;
}

// Returns the user remembered by the "Remember me" cookie, or null.
// Verifies the token against the hashed remember_token column.
function quick_user_from_cookie() {
    if (empty($_COOKIE['wtech_remember'])) return null;
    $parts = explode(':', (string)$_COOKIE['wtech_remember'], 2);
    if (count($parts) !== 2) return null;
    $id = (int)$parts[0];
    $token = $parts[1];
    $u = db_row('SELECT * FROM users WHERE id=?', [$id]);
    if (!$u || empty($u['remember_token'])) return null;
    if (!hash_equals($u['remember_token'], hash('sha256', $token))) {
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        setcookie('wtech_remember', '', ['expires' => 1, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
        return null;
    }
    return $u;
}

function public_user($u, $private = false) {
    $o = [
        'id'          => (int)$u['id'],
        'username'    => $u['username'],
        'role'        => $u['role'],
        'color'       => $u['color'],
        'avatar'      => !empty($u['avatar_url']) ? $u['avatar_url'] : null,
        'avatarBorder'=> $u['avatar_border'] ?? '',
        'profileBg'   => $u['profile_bg'] ?? '',
        'status'      => $u['status'] ?? '',
        'linkYoutube' => $u['link_youtube'] ?? '',
        'linkDiscord' => $u['link_discord'] ?? '',
        'linkTelegram'=> $u['link_telegram'] ?? '',
        'joined_at'   => (int)$u['joined_at'],
        'banned'      => (int)$u['banned'],
        'banReason'   => $u['ban_reason'] ?? '',
    ];
    if ($private) { $o['email'] = $u['email']; $o['bio'] = $u['bio']; }
    return $o;
}
function public_thread($t) {
    $author = db_row('SELECT username,color,role,avatar_url FROM users WHERE id=?', [$t['author_id']]);
    $postCount = (int)db_val('SELECT COUNT(*) FROM posts WHERE thread_id=?', [$t['id']]);
    $last = db_row('SELECT p.created_at, u.username FROM posts p LEFT JOIN users u ON u.id=p.author_id WHERE p.thread_id=? ORDER BY p.id DESC LIMIT 1', [$t['id']]);
    return [
        'id'         => (int)$t['id'],
        'categoryId' => $t['category_id'],
        'title'      => $t['title'],
        'pinned'     => (int)$t['pinned'],
        'locked'     => (int)$t['locked'],
        'views'      => (int)$t['views'],
        'postCount'  => $postCount,
        'author'     => $author ? ['username' => $author['username'], 'color' => $author['color'], 'role' => $author['role'], 'avatar' => !empty($author['avatar_url']) ? $author['avatar_url'] : null] : ['username' => 'unknown'],
        'createdAt'  => (int)$t['created_at'],
        'updatedAt'  => (int)$t['updated_at'],
        'lastPost'   => $last ? ['at' => (int)$last['created_at'], 'by' => $last['username']] : null,
    ];
}

/* ---------------- Chat helpers ---------------- */
function chat_msg($m) {
    // Bot notices (role 'bot', e.g. "Антиспам") have no user account. Never let
    // the JOIN against whatever user_id happens to be stored on the row leak
    // a real user's avatar/border/nick-color onto the bot message — older rows
    // were saved with the spammer's id, so this is enforced here at render time
    // (fixes the already-sent history too, not just new notices).
    $isBot = (string)($m['role'] ?? '') === 'bot';
    return [
        'id'        => (int)$m['id'],
        'userId'    => $isBot ? 0 : (int)$m['user_id'],
        'username'  => $m['username'],
        'role'      => $m['role'],
        'avatar'    => (!$isBot && !empty($m['avatar_url'])) ? $m['avatar_url'] : null,
        'avatarBorder' => (!$isBot && !empty($m['avatar_border'])) ? $m['avatar_border'] : '',
        'color'     => $isBot ? '#ff3232' : (!empty($m['color']) ? $m['color'] : '#444'),
        'content'   => $m['content'],
        'createdAt' => (int)$m['created_at'],
    ];
}
function update_presence($u) {
    $now = time();
    db()->prepare('INSERT INTO online (user_id,username,role,last_seen) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE username=VALUES(username),role=VALUES(role),last_seen=VALUES(last_seen)')
       ->execute([$u['id'], $u['username'], $u['role'], $now]);
    db()->prepare('DELETE FROM online WHERE last_seen < ?')->execute([$now - 60]);
}
function presence_list($me) {
    $rows = db_all('SELECT username,role FROM online WHERE user_id<>? ORDER BY username ASC', [$me['id']]);
    // The count is the REAL number of people online right now, including the
    // current user (the rows above exclude self only so the name list doesn't
    // show "you"). Updated live by the chat poll every few seconds.
    return ['count' => count($rows) + 1, 'users' => $rows];
}
function typing_list($me) {
    $rows = db_all('SELECT username FROM typing WHERE user_id<>? AND updated_at > ?', [$me['id'], time() - 4]);
    $out = [];
    foreach ($rows as $r) $out[] = $r['username'];
    return $out;
}

/* =====================================================================
   Chat anti-spam (server-side, file-backed)
   ---------------------------------------------------------------------
   Normal anti-spam must NOT depend only on the PHP session: a spammer can
   reset a session cookie and bypass session-only counters. This limiter is
   stored in data/throttle/chat_*.json and is keyed by account id, so it
   survives page reloads, logout/login, cookie/session resets and IP changes.

   Layers:
     1. minimum gap between sends;
     2. duplicate / near-duplicate repeated message block;
     2b. letter-by-letter keyboard-mash block (streak of 1-2 char messages);
     3. sliding-window message cap;
     4. burst cap for very short intervals;
     5. escalating temporary mute with a quiet-period reset.

   Usage in api.php (chat_send):
     $spam = chat_antispam_check($user, $content);
     if ($spam) json_out(['error' => $spam['error']], $spam['code']);
     ... insert message ...
     chat_antispam_record($user, $content);
   ===================================================================== */
function chat_antispam_cfg($is_staff) {
    // NOTE: the staff tier must STILL block spam. The old values (35 msgs/10 s,
    // burst 8/2 s, min gap 0.15 s) let an admin type single letters as fast as
    // the keyboard allows without ever getting a cooldown — the limits below
    // are looser than the member tier, but fast "different text" spam (letter-
    // by-letter keyboard mashing) now triggers the same escalating mute.
    return $is_staff
        ? [
            'min_gap' => 0.6, 'window' => 12, 'max_msgs' => 10,
            'burst_window' => 2, 'burst_max' => 4,
            'dup_window' => 10, 'base_mute' => 10, 'max_mute' => 300,
            'short_window' => 15, 'short_max' => 6,
          ]
        : [
            'min_gap' => 1.2, 'window' => 12, 'max_msgs' => 5,
            'burst_window' => 3, 'burst_max' => 3,
            'dup_window' => 30, 'base_mute' => 20, 'max_mute' => 600,
            'short_window' => 15, 'short_max' => 5,
          ];
}
function chat_antispam_file($uid) {
    $dir = __DIR__ . '/data/throttle';
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    // Per-account limiter: changing/clearing cookies or switching IPs must not
    // reset the mute/counters for the same logged-in account.
    return $dir . '/chat_user_' . sha1((string)(int)$uid) . '.json';
}
function chat_antispam_default_bag() {
    return [
        'times'          => [],
        'muted_until'    => 0.0,
        'strikes'        => 0,
        'quiet_reset'    => 0,
        'last_sent'      => 0.0,
        'last_norm'      => null,
        'last_norm_at'   => 0,
        'recent_norms'   => [],
        'short_times'    => [],
    ];
}
function chat_antispam_load($uid) {
    $f = chat_antispam_file($uid);
    $bag = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    if (!is_array($bag)) $bag = [];
    $bag = array_merge(chat_antispam_default_bag(), $bag);
    if (!is_array($bag['times'])) $bag['times'] = [];
    if (!is_array($bag['recent_norms'])) $bag['recent_norms'] = [];
    if (!is_array($bag['short_times'])) $bag['short_times'] = [];
    return $bag;
}
function chat_antispam_save($uid, $bag) {
    $f = chat_antispam_file($uid);
    @file_put_contents($f, json_encode($bag, JSON_UNESCAPED_UNICODE), LOCK_EX);
}
function chat_antispam_norm($content) {
    $s = (string)$content;
    $s = preg_replace('/\s+/u', ' ', trim($s));
    if (function_exists('mb_strtolower')) $s = mb_strtolower($s, 'UTF-8');
    else $s = strtolower($s);
    // Collapse repeated punctuation/characters enough to catch "!!!!!" spam,
    // without damaging normal Russian/English text.
    $s = preg_replace('/([!?\.])\1{2,}/u', '$1$1', $s);
    return $s;
}
function chat_antispam_announce($user, $mute, $reason) {
    // Public bot message: the client already receives the same text as an API error,
    // while everyone in the room can see why the flood was stopped.
    // user_id 0 (NOT the spammer's id): the chat queries LEFT JOIN users on
    // user_id for avatar/color/border — with the spammer's id the bot message
    // was rendered wearing the spammer's avatar and nick color.
    try {
        db()->prepare('INSERT INTO chat (user_id,username,role,content,created_at) VALUES (?,?,?,?,?)')
            ->execute([0, 'Антиспам', 'bot', "@{$user['username']}: {$reason}. Выдан кулдаун на {$mute} сек. Не спамьте сообщениями.", time()]);
    } catch (Throwable $e) { /* moderation must not break message sending */ }
}
function chat_antispam_violate($user, $bag, $reason, $base = null) {
    $cfg  = chat_antispam_cfg(is_mod($user));
    $now  = microtime(true);
    $nowI = time();
    $bag['strikes'] = (int)$bag['strikes'] + 1;
    $baseMute = $base !== null ? (int)$base : (int)$cfg['base_mute'];
    $mute = (int)min($baseMute * pow(2, max(0, $bag['strikes'] - 1)), (int)$cfg['max_mute']);
    $bag['muted_until'] = $now + $mute;
    $bag['quiet_reset'] = $nowI + max(300, $mute * 3);
    chat_antispam_save($user['id'], $bag);
    chat_antispam_announce($user, $mute, $reason);
    return ['error' => $reason . " Подожди {$mute} сек.", 'code' => 429];
}
// Returns ['error'=>..., 'code'=>...] when the message must be rejected,
// or null when it is allowed. Call chat_antispam_record() AFTER a successful
// insert so blocked attempts don't pollute the sliding window.
function chat_antispam_check($user, $content) {
    $cfg  = chat_antispam_cfg(is_mod($user));
    $now  = microtime(true);
    $nowI = time();
    $bag  = chat_antispam_load($user['id']);

    // Reset escalation after a quiet period.
    if ((int)$bag['strikes'] > 0 && $nowI > (int)$bag['quiet_reset']) $bag['strikes'] = 0;

    if ($now < (float)$bag['muted_until']) {
        $left = max(1, (int)ceil((float)$bag['muted_until'] - $now));
        chat_antispam_save($user['id'], $bag);
        return ['error' => "Антиспам: слишком часто отправляешь сообщения. Подожди {$left} сек.", 'code' => 429];
    }

    if ((float)$bag['last_sent'] > 0 && ($now - (float)$bag['last_sent']) < (float)$cfg['min_gap']) {
        // Count rapid-fire attempts as a strike even when every message is
        // different; otherwise a spammer can bypass duplicate detection by
        // changing one character each time.
        return chat_antispam_violate($user, $bag, 'Антиспам: слишком быстро отправляешь разные сообщения');
    }

    $norm = chat_antispam_norm($content);
    if ($norm !== '' && $bag['last_norm'] === $norm && ($nowI - (int)$bag['last_norm_at']) < (int)$cfg['dup_window']) {
        return chat_antispam_violate($user, $bag, 'Антиспам: одинаковые сообщения запрещены', 10);
    }

    // Repeating the same normalized text multiple times inside the duplicate
    // window is blocked even if another message was sent between duplicates.
    $recent = [];
    foreach ((array)$bag['recent_norms'] as $r) {
        if (!is_array($r)) continue;
        $at = (int)($r['at'] ?? 0);
        if ($at > $nowI - (int)$cfg['dup_window']) $recent[] = $r;
    }
    foreach ($recent as $r) {
        if (($r['text'] ?? null) === $norm) {
            $bag['recent_norms'] = $recent;
            return chat_antispam_violate($user, $bag, 'Антиспам: не повторяй одно и то же', 10);
        }
    }
    $bag['recent_norms'] = $recent;

    // Letter-by-letter / keyboard-mash spam: a streak of very SHORT messages
    // (1-2 chars containing at least one letter/digit, e.g. "g" "h" "j" "k")
    // inside a small window gets a cooldown even though every message is
    // technically "different text". A normal-length message resets the streak
    // (handled in chat_antispam_record()).
    $shortLen = function_exists('mb_strlen') ? mb_strlen($norm, 'UTF-8') : strlen($norm);
    if ($norm !== '' && $shortLen <= 2 && preg_match('/[\p{L}\p{N}]/u', $norm)) {
        $shortWin = (float)$cfg['short_window'];
        $shorts = array_values(array_filter((array)$bag['short_times'], function ($t) use ($now, $shortWin) { return (float)$t > $now - $shortWin; }));
        $bag['short_times'] = $shorts;
        // +1: the message being checked right now is part of the streak too.
        if (count($shorts) + 1 >= (int)$cfg['short_max']) {
            return chat_antispam_violate($user, $bag, 'Антиспам: не спамь одиночными символами', 15);
        }
    }

    $win = (float)$cfg['window'];
    $times = array_values(array_filter((array)$bag['times'], function ($t) use ($now, $win) { return (float)$t > $now - $win; }));
    $bag['times'] = $times;

    $burstWin = (float)$cfg['burst_window'];
    $burstCount = 0;
    foreach ($times as $t) if ((float)$t > $now - $burstWin) $burstCount++;
    if ($burstCount >= (int)$cfg['burst_max']) {
        return chat_antispam_violate($user, $bag, 'Антиспам: слишком быстрый спам в чат');
    }

    if (count($times) >= (int)$cfg['max_msgs']) {
        return chat_antispam_violate($user, $bag, 'Антиспам: слишком много сообщений подряд');
    }

    chat_antispam_save($user['id'], $bag);
    return null;
}
// Record a successful send into the sliding window / duplicate tracker.
function chat_antispam_record($user, $content) {
    $bag = chat_antispam_load($user['id']);
    $now = microtime(true);
    $nowI = time();
    $norm = chat_antispam_norm($content);
    $bag['times'][]      = $now;
    // Keep the file tiny.
    $bag['times']        = array_slice((array)$bag['times'], -80);
    $bag['last_sent']    = $now;
    $bag['last_norm']    = $norm;
    $bag['last_norm_at'] = $nowI;
    $bag['recent_norms'][] = ['text' => $norm, 'at' => $nowI];
    $bag['recent_norms'] = array_slice((array)$bag['recent_norms'], -30);
    // Letter-by-letter streak tracker (see chat_antispam_check()): append the
    // send when it is a 1-2 char letter/digit message, reset the streak on any
    // normal-length message so regular conversation never false-triggers.
    $shortLen = function_exists('mb_strlen') ? mb_strlen($norm, 'UTF-8') : strlen($norm);
    if ($norm !== '' && $shortLen <= 2 && preg_match('/[\p{L}\p{N}]/u', $norm)) {
        $bag['short_times'][] = $now;
        $bag['short_times'] = array_slice((array)$bag['short_times'], -30);
    } else {
        $bag['short_times'] = [];
    }
    chat_antispam_save($user['id'], $bag);
}

// Build a unique, URL-safe category id (slug) from a human-readable name.
// Transliterates Cyrillic so Russian category names still get clean ids.
function make_category_slug($name) {
    $s = strtolower(trim((string)$name));
    $map = ['а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'yo','ж'=>'zh','з'=>'z',
            'и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r',
            'с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sch',
            'ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya'];
    $s = strtr($s, $map);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim($s, '-');
    if ($s === '') $s = 'category';
    $base = substr($s, 0, 24);
    $id = $base; $n = 2;
    while (db_row('SELECT id FROM categories WHERE id=?', [$id])) {
        $suf = '-' . $n;
        $id = substr($base, 0, 32 - strlen($suf)) . $suf;
        $n++;
    }
    return $id;
}

/* =====================================================================
   PASSWORD RESET — token store (file-based, no DB schema change),
   IP throttle, branded email template and mailer.
   Tokens live in data/reset/<token>.json ; the data/ folder is denied to
   the web via data/.htaccess. Filenames are unguessable random tokens.
   ===================================================================== */
function reset_dir() {
    $d = __DIR__ . '/data/reset';
    if (!is_dir($d)) @mkdir($d, 0700, true);
    return $d;
}
function reset_save($user_id, $ttl) {
    $token = bin2hex(random_bytes(32));
    $file = reset_dir() . '/' . $token . '.json';
    @file_put_contents($file, json_encode(['user_id' => (int)$user_id, 'expires' => time() + (int)$ttl]), LOCK_EX);
    @chmod($file, 0600);
    return $token;
}
function reset_load($token) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string)$token)) return null; // strict shape
    $file = reset_dir() . '/' . $token . '.json';
    if (!is_file($file)) return null;
    $j = json_decode((string)@file_get_contents($file), true);
    if (!is_array($j) || empty($j['user_id']) || empty($j['expires'])) return null;
    if (time() > (int)$j['expires']) { @unlink($file); return null; }
    return $j;
}
function reset_consume($token) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string)$token)) return false;
    $file = reset_dir() . '/' . $token . '.json';
    if (is_file($file)) @unlink($file);
    return true;
}
/* =====================================================================
   EMAIL-VERIFIED REGISTRATION — pending signup store.
   ---------------------------------------------------------------------
   When someone submits the sign-up form we do NOT create the account
   right away. Instead we stash the requested username / email / hashed
   password + a 6-digit code in data/pending/<token>.json and email the
   code to the address. The account is only created after the user
   submits the correct code (register_verify).

   Same on-disk convention as the reset store: unguessable filenames,
   0600 perms, the whole data/ tree is denied to the web by .htaccess.
   ===================================================================== */
function pending_dir() {
    $d = __DIR__ . '/data/pending';
    if (!is_dir($d)) @mkdir($d, 0700, true);
    return $d;
}
// Save a new pending signup. Returns [token, code].
function pending_save($username, $email, $password_hash, $ttl = 900) {
    $token = bin2hex(random_bytes(32));
    $code  = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $file  = pending_dir() . '/' . $token . '.json';
    @file_put_contents($file, json_encode([
        'username'       => (string)$username,
        'email'          => (string)$email,
        'password_hash'  => (string)$password_hash,
        'code_hash'      => hash('sha256', $code),
        'expires'        => time() + (int)$ttl,
        'attempts'       => 0,
        'created_at'     => time(),
        'last_sent_at'   => time(),
    ]), LOCK_EX);
    @chmod($file, 0600);
    return [$token, $code];
}
function pending_load($token) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string)$token)) return null;
    $file = pending_dir() . '/' . $token . '.json';
    if (!is_file($file)) return null;
    $j = json_decode((string)@file_get_contents($file), true);
    if (!is_array($j) || empty($j['username']) || empty($j['code_hash']) || empty($j['expires'])) return null;
    if (time() > (int)$j['expires']) { @unlink($file); return null; }
    return $j;
}
function pending_write($token, $data) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string)$token)) return false;
    $file = pending_dir() . '/' . $token . '.json';
    @file_put_contents($file, json_encode($data), LOCK_EX);
    @chmod($file, 0600);
    return true;
}
function pending_consume($token) {
    if (!preg_match('/^[a-f0-9]{64}$/', (string)$token)) return false;
    $file = pending_dir() . '/' . $token . '.json';
    if (is_file($file)) @unlink($file);
    return true;
}
// Regenerate the 6-digit code for an existing pending token (Resend).
function pending_new_code($token) {
    $j = pending_load($token);
    if (!$j) return null;
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $j['code_hash']    = hash('sha256', $code);
    $j['attempts']     = 0;
    $j['last_sent_at'] = time();
    // Extend the expiry so the resent code is usable for the full TTL again.
    $j['expires']      = time() + 900;
    pending_write($token, $j);
    return $code;
}
// Small GC to keep the folder tidy.
function pending_gc() {
    $d = pending_dir(); $now = time(); $n = 0;
    foreach ((array)@glob($d . '/*.json') as $f) {
        if ($n++ > 50) break;
        $j = json_decode((string)@file_get_contents($f), true);
        if (!is_array($j) || $now > (int)($j['expires'] ?? 0)) @unlink($f);
    }
}
// Mask an email for display: j***@example.com
function mask_email($email) {
    $email = (string)$email;
    $at = strpos($email, '@');
    if ($at === false || $at < 1) return $email;
    $name = substr($email, 0, $at);
    $rest = substr($email, $at);
    if (strlen($name) <= 1) return $name . '***' . $rest;
    return substr($name, 0, 1) . str_repeat('*', max(1, strlen($name) - 1)) . $rest;
}

// Build the branded email carrying the 6-digit sign-up confirmation code.
function build_signup_code_email($username, $code) {
    $user = esc($username);
    $code = esc($code);
    $site = esc('+W.TECH FORUM');
    $year = date('Y');
    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Confirm your email</title></head>'
        . '<body style="margin:0;padding:0;background:#0a0a0c;font-family:Arial,Helvetica,sans-serif;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0c;"><tr><td align="center" style="padding:32px 16px;">'
        . '<table role="presentation" width="480" cellpadding="0" cellspacing="0" style="width:100%;max-width:480px;background:#141418;border:1px solid #232328;border-radius:14px;overflow:hidden;">'
        . '<tr><td style="padding:20px 24px;border-bottom:1px solid #232328;background:#0f0f13;">'
        . '<div style="font-size:12px;color:#8a8a92;letter-spacing:2px;">(&#9699; _ &#9698;)</div>'
        . '<div style="font-size:22px;font-weight:800;color:#e8e8ea;">+W.TECH <span style="color:#ff3232;">FORUM</span></div>'
        . '</td></tr>'
        . '<tr><td style="padding:26px 24px;">'
        . '<h1 style="margin:0 0 12px;font-size:20px;color:#e8e8ea;">Confirm your email</h1>'
        . '<p style="margin:0 0 8px;color:#e8e8ea;font-size:15px;line-height:1.5;">Hi <b style="color:#ff5a5a;">' . $user . '</b>,</p>'
        . '<p style="margin:0 0 18px;color:#8a8a92;font-size:14px;line-height:1.55;">To finish creating your account on ' . $site . ', enter this 6-digit confirmation code in the sign-up window. The code is valid for 15 minutes.</p>'
        . '<div style="text-align:center;margin:6px 0 4px;">'
        . '<div style="display:inline-block;padding:14px 26px;font-family:Consolas,Menlo,monospace;font-size:34px;font-weight:800;letter-spacing:10px;color:#ffffff;background:#0f0f13;border:1px solid #ff3232;border-radius:12px;">' . $code . '</div>'
        . '</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:18px 0 0;"><tr><td style="background:#0f0f13;border:1px solid #232328;border-left:3px solid #ff3232;border-radius:8px;padding:12px 14px;font-size:13px;line-height:1.5;color:#c9c9d1;"><b style="color:#e8e8ea;">Cannot see this email in your inbox?</b> If it does not appear within a few minutes, please check your <b style="color:#ff5a5a;">Spam</b> / <b style="color:#ff5a5a;">Junk</b> folder - automated messages sometimes land there.</td></tr></table>'
        . '<p style="margin:18px 0 0;color:#5f5f66;font-size:12px;line-height:1.5;">Did not try to sign up? You can safely ignore this email - no account will be created.</p>'
        . '</td></tr>'
        . '<tr><td style="padding:16px 24px;border-top:1px solid #232328;background:#0f0f13;color:#5f5f66;font-size:11px;text-align:center;">&copy; ' . $year . ' ' . $site . ' &middot; Automated message, please do not reply.</td></tr>'
        . '</table></td></tr></table></body></html>';
    $text = "Hi " . $username . ",\n\n"
        . "Your +W.TECH FORUM confirmation code is: " . $code . "\n\n"
        . "Enter it in the sign-up window within 15 minutes to finish creating your account.\n\n"
        . "If you cannot see this email in your inbox, please check your Spam / Junk folder.\n\n"
        . "Did not try to sign up? You can safely ignore this email - no account will be created.\n";
    return ['html' => $html, 'text' => $text];
}

// Cheap, bounded garbage collection of expired token files.
function reset_gc() {
    $d = reset_dir(); $now = time(); $n = 0;
    foreach ((array)@glob($d . '/*.json') as $f) {
        if ($n++ > 50) break;
        $j = json_decode((string)@file_get_contents($f), true);
        if (!is_array($j) || $now > (int)($j['expires'] ?? 0)) @unlink($f);
    }
}
// Human-readable validity period derived from RESET_TTL (keeps email + UI in sync).
function reset_ttl_label() {
    $s = (int)(defined('RESET_TTL') ? RESET_TTL : 300);
    if ($s >= 3600 && $s % 3600 === 0) { $n = $s / 3600; return $n . ' hour' . ($n > 1 ? 's' : ''); }
    if ($s >= 60 && $s % 60 === 0)     { $n = $s / 60;   return $n . ' minute' . ($n > 1 ? 's' : ''); }
    return $s . ' second' . ($s !== 1 ? 's' : '');
}

// File-based, per-IP throttle that works even for clients without cookies
// (the session-based limiter cannot). Returns an error string when blocked.
function sec_ip_throttle($key, $max, $window) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $d = __DIR__ . '/data/throttle';
    if (!is_dir($d)) @mkdir($d, 0700, true);
    $file = $d . '/' . sha1($ip . '|' . $key) . '.txt';
    $now = time();
    $times = [];
    if (is_file($file)) {
        $times = array_values(array_filter(array_map('intval', explode(',', (string)@file_get_contents($file))), function ($t) use ($now, $window) { return $t > $now - $window; }));
    }
    if (count($times) >= $max) return 'Too many attempts. Please wait a few minutes and try again.';
    $times[] = $now;
    @file_put_contents($file, implode(',', $times), LOCK_EX);
    @chmod($file, 0600);
    return null;
}

// Build the branded (forum-styled) password-reset email. Returns html + text.
function build_reset_email($username, $reset_url) {
    $user = esc($username);
    $url  = esc($reset_url);
    $site = esc('+W.TECH FORUM');
    $year = date('Y');
    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Password reset</title></head>'
        . '<body style="margin:0;padding:0;background:#0a0a0c;font-family:Arial,Helvetica,sans-serif;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0c;"><tr><td align="center" style="padding:32px 16px;">'
        . '<table role="presentation" width="480" cellpadding="0" cellspacing="0" style="width:100%;max-width:480px;background:#141418;border:1px solid #232328;border-radius:14px;overflow:hidden;">'
        . '<tr><td style="padding:20px 24px;border-bottom:1px solid #232328;background:#0f0f13;">'
        . '<div style="font-size:12px;color:#8a8a92;letter-spacing:2px;">(&#9699; _ &#9698;)</div>'
        . '<div style="font-size:22px;font-weight:800;color:#e8e8ea;">+W.TECH <span style="color:#ff3232;">FORUM</span></div>'
        . '</td></tr>'
        . '<tr><td style="padding:26px 24px;">'
        . '<h1 style="margin:0 0 12px;font-size:20px;color:#e8e8ea;">Password reset</h1>'
        . '<p style="margin:0 0 8px;color:#e8e8ea;font-size:15px;line-height:1.5;">Hi <b style="color:#ff5a5a;">' . $user . '</b>,</p>'
        . '<p style="margin:0 0 20px;color:#8a8a92;font-size:14px;line-height:1.55;">We received a request to reset your password on ' . $site . '. Use the button below to choose a new password. This link is valid for ' . reset_ttl_label() . '.</p>'
        . '<table role="presentation" cellpadding="0" cellspacing="0" align="center" style="margin:0 auto;"><tr><td align="center" style="border-radius:10px;background:#ff3232;"><a href="' . $url . '" target="_blank" style="display:inline-block;padding:13px 28px;font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:10px;">Reset password</a></td></tr></table>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:18px 0 0;"><tr><td style="background:#0f0f13;border:1px solid #232328;border-left:3px solid #ff3232;border-radius:8px;padding:12px 14px;font-size:13px;line-height:1.5;color:#c9c9d1;"><b style="color:#e8e8ea;">Cannot see this email in your inbox?</b> If it does not appear within a few minutes, please check your <b style="color:#ff5a5a;">Spam</b> / <b style="color:#ff5a5a;">Junk</b> folder - automated messages sometimes land there.</td></tr></table>'
        . '<p style="margin:20px 0 0;color:#8a8a92;font-size:12px;line-height:1.5;">If the button does not work, copy this link:<br><a href="' . $url . '" style="color:#ff5a5a;word-break:break-all;">' . $url . '</a></p>'
        . '<p style="margin:18px 0 0;color:#5f5f66;font-size:12px;line-height:1.5;">Did not request this? You can safely ignore this email and your password will stay unchanged.</p>'
        . '</td></tr>'
        . '<tr><td style="padding:16px 24px;border-top:1px solid #232328;background:#0f0f13;color:#5f5f66;font-size:11px;text-align:center;">&copy; ' . $year . ' ' . $site . ' &middot; Automated message, please do not reply.</td></tr>'
        . '</table></td></tr></table></body></html>';
    $text = "Hi " . $username . ",\n\n"
        . "We received a request to reset your password on +W.TECH FORUM.\n\n"
        . "Open this link within " . reset_ttl_label() . " to set a new password:\n" . $reset_url . "\n\n"
        . "If you cannot see this email in your inbox, please check your Spam / Junk folder.\n\n"
        . "If you did not request this, ignore this email - your password stays unchanged.\n";
    return ['html' => $html, 'text' => $text];
}

// Send a multipart (text + html) email via PHP mail(). Validates the recipient
// to prevent header injection; sets the envelope sender for deliverability.
function sec_send_mail($to, $subject, $html, $text) {
    $to = trim((string)$to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
    $from = defined('MAIL_FROM') ? MAIL_FROM : 'noreply@localhost';
    $name = defined('MAIL_NAME') ? MAIL_NAME : (defined('SITE_NAME') ? SITE_NAME : 'Forum');
    // Strip any CR/LF from configured values (defence in depth).
    $from = str_replace(["\r", "\n"], '', $from);
    $name = str_replace(["\r", "\n"], '', $name);
    $subject = str_replace(["\r", "\n"], '', (string)$subject);
    $eol = "\r\n";
    $boundary = 'wtech_' . bin2hex(random_bytes(12));
    $headers = 'From: ' . $name . ' <' . $from . '>' . $eol
             . 'Reply-To: ' . $from . $eol
             . 'MIME-Version: 1.0' . $eol
             . 'Content-Type: multipart/alternative; boundary="' . $boundary . '"' . $eol
             . 'X-Mailer: WTECH-Forum' . $eol
             . 'X-Auto-Response-Suppress: All' . $eol
             . 'Auto-Submitted: auto-generated' . $eol;
    $body = '--' . $boundary . $eol
          . 'Content-Type: text/plain; charset=UTF-8' . $eol
          . 'Content-Transfer-Encoding: 8bit' . $eol . $eol
          . $text . $eol
          . '--' . $boundary . $eol
          . 'Content-Type: text/html; charset=UTF-8' . $eol
          . 'Content-Transfer-Encoding: 8bit' . $eol . $eol
          . $html . $eol
          . '--' . $boundary . '--' . $eol;
    $params = '-f ' . escapeshellarg($from);
    return @mail($to, $subject, $body, $headers, $params);
}

/* ---------------- Notification center ---------------- */

// Найти @упоминания ников в тексте. Возвращает строки users (id, username)
// упомянутых, кроме $exceptId и забаненных.
function find_mentions($text, $exceptId = 0) {
    if (!preg_match_all('/@([A-Za-z0-9_][A-Za-z0-9_.\-]{2,19})(?![A-Za-z0-9_.\-])/', (string)$text, $m)) return [];
    $names = array_values(array_unique($m[1]));
    if (!$names) return [];
    $in = implode(',', array_fill(0, count($names), '?'));
    $sql = "SELECT id, username FROM users WHERE username IN ($in) AND banned=0";
    $params = $names;
    if ($exceptId) { $sql .= ' AND id<>?'; $params[] = (int)$exceptId; }
    return db_all($sql, $params);
}

// Карта «ник → роль» для всех @упоминаний в пачке текстов (один запрос на
// весь экран сообщений). Клиент раскрашивает @ник цветом роли упомянутого.
// (object) — чтобы пустая карта ушла в JSON как {}, а не []: там ждут словарь.
function mention_roles_map($texts) {
    $names = [];
    foreach ((array)$texts as $t) {
        if (preg_match_all('/@([A-Za-z0-9_][A-Za-z0-9_.\-]{2,19})(?![A-Za-z0-9_.\-])/', (string)$t, $m)) {
            foreach ($m[1] as $n) $names[$n] = true;
        }
    }
    if (!$names) return (object)[];
    $list = array_keys($names);
    if (count($list) > 20) $list = array_slice($list, 0, 20); // защита от экрана из 100 @ников
    $in = implode(',', array_fill(0, count($list), '?'));
    $rows = db_all("SELECT username, role FROM users WHERE username IN ($in) AND banned=0", $list);
    $out = [];
    foreach ($rows as $r) $out[$r['username']] = $r['role'];
    return (object)$out;
}

// Положить уведомление юзеру. Одинаковые непрочитанные (тип+ссылка)
// схлопываются в одно: обновляем время и увеличиваем счётчик cnt.
function notify_user($uid, $type, $actorName, $title, $link) {
    $uid = (int)$uid;
    if ($uid <= 0) return;
    $now = time();
    $type  = utf8_limit((string)$type, 24);
    $actorName = utf8_limit((string)$actorName, 32);
    $title = utf8_limit((string)$title, 190);
    $link  = utf8_limit((string)$link, 190);
    $row = db_row('SELECT id FROM notifications WHERE user_id=? AND type=? AND link=? AND unread=1 ORDER BY id DESC LIMIT 1',
                  [$uid, $type, $link]);
    if ($row) {
        db()->prepare('UPDATE notifications SET cnt=cnt+1, actor_name=?, title=?, created_at=? WHERE id=?')
           ->execute([$actorName, $title, $now, $row['id']]);
        return;
    }
    db()->prepare('INSERT INTO notifications (user_id,type,actor_name,title,link,cnt,unread,created_at) VALUES (?,?,?,?,?,1,1,?)')
       ->execute([$uid, $type, $actorName, $title, $link, $now]);
    // Не раздуваем историю: храним максимум 200 последних на юзера.
    db()->prepare('DELETE FROM notifications WHERE user_id=? AND id NOT IN (SELECT id FROM (SELECT id FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 200) x)')
       ->execute([$uid, $uid]);
}

function notif_unread_count($uid) {
    return (int)db_val('SELECT COUNT(*) FROM notifications WHERE user_id=? AND unread=1', [(int)$uid]);
}

function public_notif($n) {
    return [
        'id'      => (int)$n['id'],
        'type'    => $n['type'],
        'actor'   => $n['actor_name'],
        'title'   => $n['title'],
        'link'    => $n['link'],
        'cnt'     => (int)$n['cnt'],
        'unread'  => (bool)$n['unread'],
        'created' => (int)$n['created_at'],
    ];
}

// id всего тикет-деска (кроме $exceptId) — получатели нотифов о тикетах.
function ticket_staff_ids($exceptId = 0) {
    $rows = db_all("SELECT id FROM users WHERE role IN ('owner','admin','moderator','support') AND banned=0" . ($exceptId ? ' AND id<>' . (int)$exceptId : ''), []);
    return array_map(function ($r) { return (int)$r['id']; }, $rows);
}
