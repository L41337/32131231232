<?php
declare(strict_types=1);

/**
 * ============================================================================
 *  go-backend.php — защищённый «переход» во внешнюю админ-панель бэкенда.
 * ============================================================================
 *
 *  Кнопка «⚙ Backend» ведёт сюда (а не на внешний URL с ключом).
 *  Скрипт:
 *    1) тем же путём, что и форум, спрашивает /api.php?action=me,
 *       передавая ваши cookie (т.е. проверяет ВХОД ровно как клиент);
 *    2) если пришёл owner/admin и не забанен — 302-редирект на админку;
 *    3) иначе — 403.
 *
 *  Секретный ?key= живёт ТОЛЬКО в этом файле и не попадает в браузер/JS.
 *
 *  ДИАГНОСТИКА: если снова 403, откройте /go-backend.php?debug=1
 *  будучи залогиненным админом и пришлите мне вывод — там видно, что
 *  вернул action=me и почему проверка не прошла.
 * ============================================================================
 */

/* --- 1. URL для самовызова action=me (тот же домен, те же cookie) -------- */
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
$meUrl  = $scheme . '://' . $host . '/api.php?action=me&_=' . time();

$cookie = $_SERVER['HTTP_COOKIE'] ?? '';   // проброс cookie в самовызов

/* --- 2. Запрос к action=me (cURL, с запасным вариантом file_get_contents) */
function _gb_fetch($url, $cookie) {
    $hdr = ['X-Requested-With: XMLHttpRequest'];
    if ($cookie !== '') array_unshift($hdr, 'Cookie: ' . $cookie);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_HTTPHEADER     => $hdr,
            CURLOPT_SSL_VERIFYPEER => false, // внутренний самовызов — ок
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        return [$body, $code, $err ? 'curl: ' . $err : ''];
    }
    $ctx = stream_context_create([
        'http' => ['method' => 'GET', 'header' => $hdr, 'timeout' => 10, 'ignore_errors' => true],
        'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    return [$body, '200', $body === false ? 'file_get_contents failed' : ''];
}

list($body, $code, $err) = _gb_fetch($meUrl, $cookie);

/* --- 3. Разбор ответа --------------------------------------------------- */
$user      = null;
$parseErr  = '';
if ($body !== false && $body !== null && $body !== '') {
    $data = json_decode($body, true);
    if (is_array($data) && isset($data['user'])) {
        $user = $data['user'];
    } elseif (json_last_error() !== JSON_ERROR_NONE) {
        $parseErr = 'JSON error: ' . json_last_error_msg();
    }
}

$role   = is_array($user) ? ($user['role']   ?? null) : null;
$banned = is_array($user) ? !empty($user['banned']) : false;
$ok     = ($role === 'owner' || $role === 'admin') && !$banned;

/* --- 4. РЕЖИМ ОТЛАДКИ (?debug=1) ---------------------------------------- */
if (isset($_GET['debug'])) {
    header('Content-Type: text/plain; charset=utf-8');
    echo "=== go-backend.php debug ===\n";
    echo "me url:    $meUrl\n";
    echo "http code: $code\n";
    echo "curl/fetch err: " . ($err ?: '(нет)') . "\n";
    echo "parse err: " . ($parseErr ?: '(нет)') . "\n";
    echo "role:      " . ($role   ?? '(null)') . "\n";
    echo "banned:    " . ($banned ? 'yes' : 'no') . "\n";
    echo "verdict:   " . ($ok ? 'OK -> redirect' : 'DENY -> 403') . "\n";
    echo "\n--- raw body (первые 1500 символов) ---\n";
    echo substr((string)$body, 0, 1500) . "\n";
    exit;
}

/* --- 5. ИТОГ: либо редирект, либо 403 ----------------------------------- */
if (!$ok) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "403 Forbidden\n\nНет доступа. Если вы залогинены как owner/admin,\n";
    echo "откройте /go-backend.php?debug=1 и пришлите вывод администратору.";
    exit;
}

// Секретный URL — только на сервере. (Ротация ключа см. ниже в комментарии.)
$BACKEND_ADMIN_URL = 'http://l43087cr.beget.tech/backend/admin/?key=11eeadf1a44ded7f627ec793554c69d867967ce278aea1caa7b031bc0a45e95e';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Referrer-Policy: no-referrer');
header('Location: ' . $BACKEND_ADMIN_URL, true, 302);
exit;

/* ============================================================================
 *  ЕСЛИ СНОВА 403
 *  =========================================================================
 *  Откройте в браузере (залогиненным админом):
 *      /go-backend.php?debug=1
 *  и пришлите мне вывод. Там будет видно:
 *    - что вернул /api.php?action=me (есть ли там user и role);
 *    - какая роль пришла (owner/admin или что-то другое);
 *    - возможно, action=me требует ещё какой-то заголовок/CSRF — тогда
 *      добавим.
 *
 *  ВАЖНО: старый ключ (86736ff0…) уже был в публичном app.js — смените его
 *  в админ-панели beget.tech и впишите сюда НОВОЕ значение.
 * ========================================================================= */
