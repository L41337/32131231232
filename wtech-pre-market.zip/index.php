<?php
// Cache-busting: append each asset's modification time as ?v= so the browser
// re-downloads CSS/JS the instant the file changes on disk — no hard refresh.
function asset_ver($url) {
    $file = __DIR__ . $url; // $url is like /assets/css/style.css
    return file_exists($file) ? $url . '?v=' . filemtime($file) : $url;
}
// Aggressive no-store on the HTML shell itself: browsers were happily
// serving a stale index.php (with its old inline scaler script that
// applied CSS `zoom` on <html>), which made the interface look totally
// different depending on the user's browser zoom setting. Force a full
// refetch on every navigation so the inline script version we ship today
// is the one that runs.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Security headers for the HTML shell (clickjacking, MIME-sniffing, CSP, …).
require_once __DIR__ . '/security.php';
sec_headers();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>+W.TECH FORUM — Community Forum</title>
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ctext x='32' y='41' font-family='Consolas,Menlo,monospace' font-size='30' font-weight='bold' fill='%23ff3232' text-anchor='middle' textLength='46' lengthAdjust='spacingAndGlyphs'%3E(%E2%97%A3_%E2%97%A2)%3C/text%3E%3C/svg%3E">
  <link rel="stylesheet" href="<?php echo asset_ver('/assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo asset_ver('/assets/css/animations.css'); ?>">
  <style>
  /* =====================================================================
     PRELOADER — inline in <head> so it's the very first thing the user
     sees, before any external CSS/JS parsed. Removed by app.js once boot()
     finishes (falls back to a 6 s safety timeout below in case JS breaks).
     ===================================================================== */
  #wtc-preloader {
    position: fixed; inset: 0; z-index: 9999;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 22px;
    background:
      radial-gradient(1200px 600px at 50% -10%, rgba(255,50,50,.18) 0%, transparent 55%),
      radial-gradient(900px 500px at 50% 110%, rgba(255,50,50,.10) 0%, transparent 55%),
      #0a0a0c;
    color: #e8e8ea;
    font-family: "Inter", "Segoe UI", system-ui, -apple-system, sans-serif;
    opacity: 1;
    transition: opacity .45s ease, visibility 0s linear .45s;
  }
  #wtc-preloader.hide { opacity: 0; visibility: hidden; pointer-events: none; }
  .wtc-pre-logo {
    display: flex; align-items: center; justify-content: center; gap: 12px;
    font-weight: 800; letter-spacing: 1px;
    filter: drop-shadow(0 6px 24px rgba(255, 50, 50, .35));
    animation: wtcPreFloat 3.2s ease-in-out infinite;
    text-align: center;
  }
  .wtc-pre-mark {
    color: #ff3232; font-family: ui-monospace, Menlo, Consolas, monospace;
    font-size: 26px; letter-spacing: 0; white-space: nowrap; line-height: 1;
  }
  .wtc-pre-text { font-size: 26px; color: #e8e8ea; white-space: nowrap; line-height: 1; }
  .wtc-pre-text b { color: #ff3232; }
  /* Progress bar: a hollow pill with a red comet chasing itself. */
  .wtc-pre-bar {
    position: relative; width: min(240px, 60vw); height: 4px;
    background: #1a1a20; border: 1px solid #232328; border-radius: 999px; overflow: hidden;
  }
  .wtc-pre-bar::before {
    content: ""; position: absolute; top: 0; left: -40%; height: 100%; width: 40%;
    background: linear-gradient(90deg, transparent 0%, #ff3232 45%, #ff5a5a 55%, transparent 100%);
    border-radius: 999px; filter: blur(.3px);
    animation: wtcPreSlide 1.15s cubic-bezier(.6,.05,.4,.95) infinite;
  }
  .wtc-pre-hint { color: #5f5f66; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; }
  @keyframes wtcPreSlide { 0% { left: -40%; } 100% { left: 100%; } }
  @keyframes wtcPreFloat { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
  /* Respect user's OS "reduce motion" preference. */
  @media (prefers-reduced-motion: reduce) {
    .wtc-pre-logo { animation: none; }
    .wtc-pre-bar::before { animation-duration: 1.8s; }
  }
  </style>
  <script>
  /* =====================================================================
     GLOBAL UI SCALING + MODAL "FIT-TO-VIEWPORT"
     ---------------------------------------------------------------------
     Two independent helpers live here:

     1. UI SCALER — scales the whole interface via CSS `zoom` on <html>
        so cards, fonts, avatars, gaps etc. grow/shrink together with the
        window. The design was drawn at ~1280×800 (see .layout max-width
        in style.css). On mobile widths (< 900px) scaling is disabled and
        the responsive @media rules take over.

     2. MODAL FIT — every element with class .auth-panel, .modal, .wtc-modal
        or .ban-card gets its `--fit` CSS variable set to a shrink factor
        so the whole modal — including the last button — always fits the
        visible viewport without ANY internal scrolling. If the modal is
        naturally smaller than the viewport, --fit stays at 1 (no scaling).
     ===================================================================== */
  // ---- Hard reset any stale `zoom` inherited from an older cached version
  //      of this page (bfcache / disk cache could otherwise keep it alive).
  //      Also nukes it on every history navigation (back/forward).
  document.documentElement.style.zoom = '1';
  document.documentElement.style.setProperty('--ui-scale', '1');
  window.__uiScale = 1;
  window.__wtcBuild = <?php echo (int)filemtime(__FILE__); ?>;
  console.info('[+W.TECH FORUM] build ' + window.__wtcBuild + ' — UI-scaler DISABLED');
  window.addEventListener('pageshow', function () {
    document.documentElement.style.zoom = '1';
    document.documentElement.style.setProperty('--ui-scale', '1');
  });

  (function () {
    /* ---- 1. UI scaler (DISABLED) ------------------------------------
       We used to apply CSS `zoom` to <html> so the whole UI would grow
       and shrink with the window. In practice that mixed badly with the
       browser's own zoom (e.g. 90% / 110%) and made the same site look
       different on two identically-sized monitors depending on browser
       settings — which is exactly the bug the user reported.

       The interface is now rendered at natural pixel size on every PC.
       Users who want it larger can use the built-in browser zoom
       (Ctrl+wheel / Ctrl± / mobile pinch). We still write --ui-scale = 1
       so any CSS that references it keeps working. */
    function applyUiScale() {
      document.documentElement.style.zoom = '1';
      document.documentElement.style.setProperty('--ui-scale', '1');
      window.__uiScale = 1;
    }

    /* ---- 2. Modal fit-to-viewport ---- */
    var SELECTOR = '.auth-panel.show, .modal, .wtc-modal, .ban-card';
    // Safety margin so modals don't touch the very edges of the viewport.
    var MARGIN_X = 16, MARGIN_Y = 16;
    function fitOne(el) {
      if (!el || !el.isConnected) return;
      // Temporarily reset --fit so we measure the modal's NATURAL size.
      var prev = el.style.getPropertyValue('--fit');
      el.style.setProperty('--fit', '1');
      // The UI-scaler zoom is already applied to <html>, so getBoundingClientRect
      // returns already-zoomed pixels — that's exactly what "fits the viewport".
      var r = el.getBoundingClientRect();
      var w = r.width, h = r.height;
      if (w <= 0 || h <= 0) { if (prev) el.style.setProperty('--fit', prev); return; }
      var availW = window.innerWidth  - MARGIN_X * 2;
      var availH = window.innerHeight - MARGIN_Y * 2;
      var fit = Math.min(1, availW / w, availH / h);
      // Snap to 0.01 so we don't churn the style repeatedly on tiny deltas.
      fit = Math.max(0.35, Math.round(fit * 100) / 100);
      el.style.setProperty('--fit', String(fit));
    }
    function fitAll() {
      var nodes = document.querySelectorAll(SELECTOR);
      for (var i = 0; i < nodes.length; i++) fitOne(nodes[i]);
    }

    /* ---- 3. Topbar-height tracker --------------------------------
       The chat sidebar (see .chatbar in style.css) is `position: sticky`
       and pins itself under the topbar. If we hard-code `top: 76px`, the
       chat visibly moves out from under the topbar the moment the user
       zooms the browser (Ctrl± / Ctrl+wheel), because at a different zoom
       the topbar is no longer exactly 76 physical pixels tall.
       So: measure the real topbar height and expose it as --topbar-h. */
    function applyTopbarHeight() {
      var tb = document.getElementById('topbar');
      if (!tb) return;
      var h = Math.round(tb.getBoundingClientRect().height);
      if (h > 0) document.documentElement.style.setProperty('--topbar-h', h + 'px');
    }

    /* ---- 4. Chat-height sync ------------------------------------
       The chat panel must be EXACTLY the height of the left column
       (.content), but never taller than the visible viewport. Doing this
       purely in CSS with `height: min(100%, …)` was unreliable across
       browsers: on some PCs (Firefox, older Chromium) `100%` on a sticky
       child of a flex-stretched parent resolves to 0, so the chat would
       fall back to viewport height and overflow the cards next to it.
       Measuring in JS gives a pixel-exact value that works everywhere. */
    function applyChatHeight() {
      var app = document.getElementById('app');
      if (!app) return;
      var contentH = Math.round(app.getBoundingClientRect().height);
      var topH = parseInt(getComputedStyle(document.documentElement)
                            .getPropertyValue('--topbar-h')) || 76;
      // Mirror of .layout's top padding (see --chat-gap in style.css): the
      // chat's pinned position equals its rest position, so it never moves
      // while scrolling; the same gap is kept below the panel for symmetry.
      var gap = 22;
      var chatEl = document.getElementById('chat');
      if (chatEl) {
        var g = parseFloat(getComputedStyle(chatEl).getPropertyValue('--chat-gap'));
        if (g > 0) gap = g;
      }
      // По пожеланию: при переходе по вкладкам высота чата подгоняется
      // ТОЧНО под высоту открытого основного раздела — верхняя и нижняя
      // кромки панели совпадают с кромками контента (без ограничения
      // окном). ИСКЛЮЧЕНИЕ — страница Downloads: её не трогаем, там
      // остаётся прежняя логика (не выше видимого окна).
      var isDownloads = /^#\/downloads/i.test(location.hash || '');
      var h = isDownloads
        ? Math.max(320, Math.min(contentH, Math.max(320, window.innerHeight - topH - gap * 2)))
        : Math.max(320, contentH);
      document.documentElement.style.setProperty('--chat-h', h + 'px');
    }

    applyUiScale();
    applyTopbarHeight();
    applyChatHeight();

    var raf = 0;
    function schedule() {
      if (raf) return;
      raf = requestAnimationFrame(function () {
        raf = 0; applyUiScale(); applyTopbarHeight(); applyChatHeight(); fitAll();
      });
    }
    window.addEventListener('resize', schedule);
    window.addEventListener('orientationchange', function () {
      applyUiScale(); applyTopbarHeight(); applyChatHeight(); fitAll();
    });
    // Browser-zoom is not a resize event in every browser — some (Firefox)
    // only fire it on window resize, but Chrome fires it on zoom too. To
    // be safe, poll the devicePixelRatio and re-run on any change.
    var lastDpr = window.devicePixelRatio || 1;
    setInterval(function () {
      var dpr = window.devicePixelRatio || 1;
      if (dpr !== lastDpr) { lastDpr = dpr; applyTopbarHeight(); applyChatHeight(); fitAll(); }
    }, 400);
    // Expose so app.js can force a resync after re-rendering the page
    // (renderHome / renderProfile etc. all change #app's height).
    window.syncChatHeight = applyChatHeight;
    // Also re-measure once the topbar has actually been rendered by app.js
    // (renderTopbar() writes into #topbar after boot, so the first measure
    // above sees an empty element). This script runs in <head>, so we have
    // to wait for the #topbar element to exist first.
    function attachTopbarObserver() {
      var tb = document.getElementById('topbar');
      var app = document.getElementById('app');
      if (!tb || !app) return false;
      applyTopbarHeight();
      applyChatHeight();
      // Topbar: re-measure whenever its contents change (login/logout swap,
      // Admin button appearing, etc.) or its rendered size changes on zoom.
      new MutationObserver(function () { applyTopbarHeight(); applyChatHeight(); })
        .observe(tb, { childList: true, subtree: true, attributes: true });
      if (typeof ResizeObserver !== 'undefined') {
        new ResizeObserver(function () { applyTopbarHeight(); applyChatHeight(); }).observe(tb);
        // #app: re-measure whenever the page contents render / re-render
        // (renderHome, renderForum, image loads, etc.) so the chat panel
        // matches its column exactly, at any zoom, on any PC.
        new ResizeObserver(applyChatHeight).observe(app);
      }
      // Also refresh once every image inside #app has loaded, otherwise a
      // late image reveal could stretch .content after our measurement.
      window.addEventListener('load', applyChatHeight);
      return true;
    }
    if (!attachTopbarObserver()) {
      document.addEventListener('DOMContentLoaded', attachTopbarObserver);
    }

    // Re-fit whenever the DOM changes (modals are inserted/updated by app.js
    // and chat.js — they don't need to know about this helper).
    function bootObserver() {
      var mo = new MutationObserver(function (records) {
        var needsFit = false;
        for (var i = 0; i < records.length; i++) {
          var r = records[i];
          if (r.type === 'attributes') { needsFit = true; break; }
          for (var j = 0; j < r.addedNodes.length; j++) {
            var n = r.addedNodes[j];
            if (n.nodeType !== 1) continue;
            if (n.matches && n.matches(SELECTOR)) { needsFit = true; break; }
            if (n.querySelector && n.querySelector(SELECTOR)) { needsFit = true; break; }
          }
          if (needsFit) break;
        }
        if (needsFit) requestAnimationFrame(fitAll);
      });
      mo.observe(document.body, {
        childList: true, subtree: true,
        attributes: true, attributeFilter: ['class', 'style'],
      });
      // First pass — in case a modal is already in the DOM at boot.
      fitAll();
    }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', bootObserver);
    } else {
      bootObserver();
    }
    // Expose so app code can request a manual refit (e.g. after injecting
    // a modal that changes size on user input).
    window.fitModals = fitAll;
  })();
  </script>
</head>
<body>
  <!-- Preloader: shown immediately (styles are inline in <head>) and hidden
       by app.js after boot() completes. Safety timeout kills it after 6 s in
       case the JS bundle fails to load, so the site is never stuck on it. -->
  <div id="wtc-preloader" role="status" aria-live="polite" aria-label="Loading">
    <div class="wtc-pre-logo">
      <span class="wtc-pre-mark">(◣ _ ◢)</span>
      <span class="wtc-pre-text">+W.TECH <b>FORUM</b></span>
    </div>
    <div class="wtc-pre-bar" aria-hidden="true"></div>
    <div class="wtc-pre-hint">Loading…</div>
  </div>
  <script>
    /* Preloader control.
       - Minimum on-screen time: MIN_MS. Even if boot() finishes instantly the
         splash stays visible for at least this long, so the animation isn't a
         one-frame flash on a warm cache.
       - Safety cap: MAX_MS. If the JS bundle fails / boot() hangs, the splash
         disappears anyway and the user isn't stuck on the loading screen. */
    (function () {
      var MIN_MS = 4500;   // requested: a little longer, ~4-5 seconds
      var MAX_MS = 9000;
      var startedAt = Date.now();
      var boothookFired = false;
      function reallyHide() {
        var el = document.getElementById('wtc-preloader');
        if (!el || el.classList.contains('hide')) return;
        el.classList.add('hide');
        setTimeout(function () { if (el && el.parentNode) el.parentNode.removeChild(el); }, 600);
      }
      // Called by app.js the moment boot() completes. It's honoured only after
      // MIN_MS has elapsed so the splash never blinks.
      window.__wtcHidePreloader = function () {
        boothookFired = true;
        var elapsed = Date.now() - startedAt;
        var wait = Math.max(0, MIN_MS - elapsed);
        setTimeout(reallyHide, wait);
      };
      // Hard cap in case boot() never calls us back.
      setTimeout(function () { if (!boothookFired) reallyHide(); }, MAX_MS);
    })();
  </script>

  <div id="topbar" class="topbar"></div>

  <div class="layout">
    <main id="app" class="content"></main>

    <!-- Chat column: the outer wrapper is `align-self: stretch` so it takes
         the CONTENT's height (never longer than the page). The <aside> chat
         itself is `position: sticky` INSIDE the wrapper — sticky needs a
         taller parent to work, so it pins to the top of the viewport while
         the page scrolls and does not move at all. -->
    <div class="chat-column">
      <aside id="chat" class="chatbar">
        <div class="chat-head">
          <h3>💬 Live Chat</h3>
          <span id="chat-presence" class="presence">0 online</span>
        </div>
        <div id="chat-messages" class="chat-messages"></div>
        <div id="chat-typing" class="chat-typing"></div>
        <div class="chat-input-wrap">
          <div id="chat-input" class="chat-input" contenteditable="true" data-placeholder="Message…" maxlength="500"></div>
          <button id="chat-send" class="btn btn-accent">Send</button>
        </div>
      </aside>
    </div>
  </div>

  <!-- Footer lives OUTSIDE .layout on purpose: if it stayed inside .content
       the chat column would stretch (align-self: stretch) all the way down
       past the footer, and the sticky chat panel would visibly slide with
       the scroll instead of standing still. Rendered by renderHome() only. -->
  <div id="footer-slot"></div>

  <div id="modal" class="modal-root"></div>

  <script>window.API_MODE = 'php';</script>
  <script src="<?php echo asset_ver('/assets/js/twemoji.min.js'); ?>"></script>
  <!-- Main frontend code is served by PHP endpoints, not .js files. -->
  <script src="<?php echo asset_ver('/app.php'); ?>"></script>
  <script src="<?php echo asset_ver('/chat.php'); ?>"></script>
</body>
</html>
