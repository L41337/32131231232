<?php
// Prevent direct web access
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(403);
    exit('Forbidden');
}

/* =====================================================================
   On-the-fly Lua obfuscator (targets LuaJIT / Lua 5.1)
   ---------------------------------------------------------------------
   Pipeline:  source → tokenizer → FULL Lua 5.1 recursive-descent parser
   with real scope tracking → re-emit:

     1. comments & whitespace stripped (minify);
     2. every LOCAL binding (local vars, local functions, params, for
        vars) renamed to junk — PER BINDING, so shadowing semantics are
        preserved exactly (no naive text rename that breaks globals);
     3. globals DEFINED inside the file (function name() / name = ...)
        renamed uniformly at every use;
     4. every string literal replaced by _D("<escaped bytes>", key) with
        a tiny arithmetic-cipher decoder injected at the top — the code
        gets byte-identical strings at runtime (ffi.cdef, URLs, JSON…);
     5. multi-digit integers hex-mangled;
     6. junk statements + a hidden per-download build tag watermark.

   If anything unexpected is met, lua_obfuscate() THROWS — the download
   endpoint catches it and serves the original file (never breaks).
   ===================================================================== */

class LuaObfException extends Exception {}

/* ---------------- Tokenizer ---------------- */

function lua_long_bracket_level($src, $i, $n) {
    // $src[$i] === '[' — returns long-bracket level (0 for "[[") or -1.
    $j = $i + 1; $lvl = 0;
    while ($j < $n && $src[$j] === '=') { $lvl++; $j++; }
    if ($j < $n && $src[$j] === '[') return $lvl;
    return -1;
}

function lua_unescape($src, &$j, $n) {
    // $src[$j] === '\\' — decode ONE escape sequence, advance $j past it.
    $e = $src[$j + 1];
    static $simple = ['a' => "\a", 'b' => "\b", 'f' => "\f", 'n' => "\n",
                      'r' => "\r", 't' => "\t", 'v' => "\v",
                      '\\' => '\\', '"' => '"', "'" => "'"];
    if (isset($simple[$e])) { $j += 2; return $simple[$e]; }
    if ($e === "\n") { $j += 2; return "\n"; }
    if ($e === "\r") { $j += ($j + 2 < $n && $src[$j + 2] === "\n") ? 3 : 2; return "\n"; }
    if (ctype_digit($e)) {
        $d = 0; $k = $j + 1; $cnt = 0;
        while ($k < $n && $cnt < 3 && ctype_digit($src[$k])) { $d = $d * 10 + (int)$src[$k]; $k++; $cnt++; }
        $j = $k;
        return chr($d & 0xFF);
    }
    $j += 2; // anything else: Lua 5.1 would have rejected the source already
    return $e;
}

function lua_tokenize($src) {
    static $kw = ['and'=>1,'break'=>1,'do'=>1,'else'=>1,'elseif'=>1,'end'=>1,
                  'false'=>1,'for'=>1,'function'=>1,'goto'=>1,'if'=>1,'in'=>1,
                  'local'=>1,'nil'=>1,'not'=>1,'or'=>1,'repeat'=>1,'return'=>1,
                  'then'=>1,'true'=>1,'until'=>1,'while'=>1];
    $n = strlen($src); $i = 0; $out = [];
    while ($i < $n) {
        $c = $src[$i];
        if ($c === ' ' || $c === "\t" || $c === "\n" || $c === "\r" || $c === "\v" || $c === "\f") { $i++; continue; }
        // comments
        if ($c === '-' && $i + 1 < $n && $src[$i + 1] === '-') {
            $i += 2;
            if ($i < $n && $src[$i] === '[' && ($lvl = lua_long_bracket_level($src, $i, $n)) >= 0) {
                $close = ']' . str_repeat('=', $lvl) . ']';
                $end = strpos($src, $close, $i + 2 + $lvl);
                if ($end === false) throw new LuaObfException('unterminated long comment');
                $i = $end + strlen($close);
                continue;
            }
            while ($i < $n && $src[$i] !== "\n") $i++;
            continue;
        }
        // quoted strings — DECODED value is stored and re-encoded on output
        if ($c === '"' || $c === "'") {
            $q = $c; $j = $i + 1; $buf = '';
            while (true) {
                if ($j >= $n) throw new LuaObfException('unterminated string');
                $ch = $src[$j];
                if ($ch === $q) { $j++; break; }
                if ($ch === "\n" || $ch === "\r") throw new LuaObfException('unterminated string');
                if ($ch === '\\') { $buf .= lua_unescape($src, $j, $n); continue; }
                $buf .= $ch; $j++;
            }
            $out[] = ['t' => 'string', 's' => '', 'dec' => $buf]; $i = $j; continue;
        }
        // long string [[ ]] / [=[ ]=] ...
        if ($c === '[' && ($lvl = lua_long_bracket_level($src, $i, $n)) >= 0) {
            $start = $i + 2 + $lvl;
            // first newline immediately after the opening bracket is skipped
            if ($start < $n && $src[$start] === "\r" && $start + 1 < $n && $src[$start + 1] === "\n") $start += 2;
            elseif ($start < $n && ($src[$start] === "\n" || $src[$start] === "\r")) $start += 1;
            $close = ']' . str_repeat('=', $lvl) . ']';
            $end = strpos($src, $close, $start);
            if ($end === false) throw new LuaObfException('unterminated long string');
            $raw = substr($src, $start, $end - $start);
            // Lua normalizes every end-of-line variant inside strings to a
            // plain "\n" (CRLF in the file must NOT survive into the value).
            $raw = str_replace(["\r\n", "\n\r", "\r"], "\n", $raw);
            $out[] = ['t' => 'string', 's' => '', 'dec' => $raw];
            $i = $end + strlen($close); continue;
        }
        // numbers
        if (ctype_digit($c) || ($c === '.' && $i + 1 < $n && ctype_digit($src[$i + 1]))) {
            if (!preg_match('/\G(?:0[xX][0-9a-fA-F]+(?:\.[0-9a-fA-F]*)?(?:[pP][+-]?\d+)?|\d+(?:\.\d*)?(?:[eE][+-]?\d+)?|\.\d+(?:[eE][+-]?\d+)?)/', $src, $m, 0, $i)) {
                throw new LuaObfException('bad number @' . $i);
            }
            $out[] = ['t' => 'number', 's' => $m[0]]; $i += strlen($m[0]); continue;
        }
        // names / keywords
        if (ctype_alpha($c) || $c === '_') {
            $j = $i + 1;
            while ($j < $n && (ctype_alnum($src[$j]) || $src[$j] === '_')) $j++;
            $w = substr($src, $i, $j - $i);
            $out[] = ['t' => isset($kw[$w]) ? 'kw' : 'name', 's' => $w]; $i = $j; continue;
        }
        // symbols — longest match first
        $three = substr($src, $i, 3);
        if ($three === '...') { $out[] = ['t' => 'symbol', 's' => '...']; $i += 3; continue; }
        $two = substr($src, $i, 2);
        if ($two === '..' || $two === '==' || $two === '~=' || $two === '<=' || $two === '>=' || $two === '::') {
            $out[] = ['t' => 'symbol', 's' => $two]; $i += 2; continue;
        }
        if (strpos('+-*/%^#=<>(){}[];:,._', $c) !== false) { $out[] = ['t' => 'symbol', 's' => $c]; $i++; continue; }
        throw new LuaObfException('unexpected char ' . var_export($c, true) . ' @' . $i);
    }
    $out[] = ['t' => 'eof', 's' => ''];
    return $out;
}

/* ---------------- Parser (Lua 5.1) with scope tracking ---------------- */

class LuaObfParser {
    public $toks; public $i = 0; public $n;
    public $out = [];          // emitted, annotated tokens
    public $scopes = [];       // stack of [name => bindingId]
    public $bindings = [];     // bindingId => orig name
    public $bindNames = [];    // orig name => true (name has ≥1 local binding)
    public $unresolved = [];   // name => true (used with NO local binding)
    public $gdefs = [];        // name => true (defined globally in this file)
    public $srcNames = [];     // all identifiers appearing in source
    public $forceOrig = [];    // bindingId => true (must keep its original name)

    public function __construct($toks) { $this->toks = $toks; $this->n = count($toks); $this->pushScope(); }

    /* ----- token helpers ----- */
    function cur() { return $this->toks[$this->i]; }
    function peek($kw) { return $this->cur()['t'] === 'kw' && $this->cur()['s'] === $kw; }
    function sym($s) { return $this->cur()['t'] === 'symbol' && $this->cur()['s'] === $s; }
    function take() {
        if ($this->i >= $this->n - 1) throw new LuaObfException('unexpected EOF');
        return $this->toks[$this->i++];
    }
    function takeKw($kw) {
        if (!$this->peek($kw)) throw new LuaObfException("expected '$kw', got '" . $this->cur()['s'] . "'");
        $this->i++; $this->emit('kw', $kw);
    }
    function takeSym($s) {
        if (!$this->sym($s)) throw new LuaObfException("expected '$s', got '" . $this->cur()['s'] . "'");
        $this->i++; $this->emit('symbol', $s);
    }
    function emit($t, $s, $x = null) { $tok = ['t' => $t, 's' => $s]; if ($x !== null) $tok['x'] = $x; $this->out[] = $tok; }

    /* ----- scope handling ----- */
    function pushScope() { $this->scopes[] = []; }
    function popScope() { array_pop($this->scopes); if (!$this->scopes) throw new LuaObfException('scope underflow'); }
    function reserveLocal($name) {           // id exists, but NOT in scope yet
        $id = count($this->bindings);
        $this->bindings[$id] = $name;
        $this->bindNames[$name] = true;
        return $id;
    }
    function activateLocal($name, $id) { $this->scopes[count($this->scopes) - 1][$name] = $id; }
    function bindLocal($name) { $id = $this->reserveLocal($name); $this->activateLocal($name, $id); return $id; }
    function resolve($name) {
        for ($s = count($this->scopes) - 1; $s >= 0; $s--) {
            if (array_key_exists($name, $this->scopes[$s])) return $this->scopes[$s][$name];
        }
        return null;
    }
    // Identifier USED as a value (or assignment target).
    function useName() {
        $tok = $this->take();
        if ($tok['t'] !== 'name') throw new LuaObfException("expected name, got '" . $tok['s'] . "'");
        $name = $tok['s'];
        $this->srcNames[$name] = true;
        $b = $this->resolve($name);
        if ($b !== null) { $this->emit('name', $name, ['bind' => $b]); return $b; }
        $this->unresolved[$name] = true;
        $this->emit('name', $name, ['glob' => $name]);
        return null;
    }
    // Field name (after . or :) — never renamed.
    function fieldName() {
        $tok = $this->take();
        if ($tok['t'] !== 'name') throw new LuaObfException("expected field name, got '" . $tok['s'] . "'");
        $this->srcNames[$tok['s']] = true;
        $this->emit('name', $tok['s']);
    }

    /* ----- statements ----- */
    function parseChunk() {
        $this->parseBlock();
        if ($this->cur()['t'] !== 'eof') throw new LuaObfException("trailing tokens: '" . $this->cur()['s'] . "'");
    }
    function blockEnded() {
        $c = $this->cur();
        if ($c['t'] === 'eof') return true;
        return $c['t'] === 'kw' && in_array($c['s'], ['end', 'else', 'elseif', 'until'], true);
    }
    function parseBlock() {
        while (!$this->blockEnded()) {
            if ($this->parseStat()) return; // return-statement ends a block
        }
    }
    function parseStat() {
        $c = $this->cur();
        if ($c['t'] === 'symbol' && $c['s'] === ';') { $this->take(); $this->emit('symbol', ';'); return false; }
        if ($c['t'] !== 'kw') { $this->exprStat(); return false; }
        switch ($c['s']) {
            case 'if': $this->ifStat(); return false;
            case 'while': $this->whileStat(); return false;
            case 'do':
                $this->takeKw('do');
                $this->pushScope(); $this->parseBlock(); $this->popScope();
                $this->takeKw('end'); return false;
            case 'for': $this->forStat(); return false;
            case 'repeat': $this->repeatStat(); return false;
            case 'function': $this->funcStat(); return false;
            case 'local': $this->localStat(); return false;
            case 'return':
                $this->takeKw('return');
                if (!$this->blockEnded() && !$this->sym(';')) $this->expList();
                if ($this->sym(';')) { $this->take(); $this->emit('symbol', ';'); }
                return true;
            case 'break': $this->takeKw('break'); return false;
            case 'goto':
                $this->takeKw('goto');
                $t = $this->take(); if ($t['t'] !== 'name') throw new LuaObfException('goto target');
                $this->emit('name', $t['s']); return false;
        }
        throw new LuaObfException("unexpected keyword '" . $c['s'] . "'");
    }

    function ifStat() {
        $this->takeKw('if');
        $this->parseExp(0);
        $this->takeKw('then');
        $this->pushScope(); $this->parseBlock(); $this->popScope();
        while ($this->peek('elseif')) {
            $this->takeKw('elseif');
            $this->parseExp(0);
            $this->takeKw('then');
            $this->pushScope(); $this->parseBlock(); $this->popScope();
        }
        if ($this->peek('else')) {
            $this->takeKw('else');
            $this->pushScope(); $this->parseBlock(); $this->popScope();
        }
        $this->takeKw('end');
    }

    function whileStat() {
        $this->takeKw('while');
        $this->parseExp(0);
        $this->takeKw('do');
        $this->pushScope(); $this->parseBlock(); $this->popScope();
        $this->takeKw('end');
    }

    function repeatStat() {
        $this->takeKw('repeat');
        // 5.1 scope rule: locals from the repeat-body ARE visible in the
        // until-condition — keep the block open until after the expression.
        $this->pushScope();
        $this->parseBlock();
        $this->takeKw('until');
        $this->parseExp(0);
        $this->popScope();
    }

    function forStat() {
        $this->takeKw('for');
        // Loop variable(s): reserve bindings now (so emitted tokens can carry
        // the right id) but keep them INACTIVE until the header expressions
        // are parsed — `for i = i, 10` uses the OUTER i on the right.
        $t = $this->take();
        if ($t['t'] !== 'name') throw new LuaObfException('for variable expected');
        $names = [$t['s']];
        if ($this->sym('=')) {
            // numeric for — name comes before '=' in the source: emit it now
            $id = $this->reserveLocal($t['s']);
            $this->emit('name', $t['s'], ['bind' => $id]);
            $this->takeSym('=');
            $this->parseExp(0); $this->takeSym(','); $this->parseExp(0);
            if ($this->sym(',')) { $this->takeSym(','); $this->parseExp(0); }
            $this->takeKw('do');
            $this->pushScope();
            $this->activateLocal($t['s'], $id);
        } else {
            // generic for — namelist comes before 'in': emit names now
            $ids = [$this->reserveLocal($t['s'])];
            $this->emit('name', $t['s'], ['bind' => $ids[0]]);
            while ($this->sym(',')) {
                $this->takeSym(',');
                $t = $this->take();
                if ($t['t'] !== 'name') throw new LuaObfException('for namelist expected');
                $ids[] = $this->reserveLocal($t['s']);
                $this->emit('name', $t['s'], ['bind' => end($ids)]);
                $names[] = $t['s'];
            }
            if (!$this->peek('in')) throw new LuaObfException("expected '=' or 'in' after for-name");
            $this->takeKw('in');
            $this->expList();
            $this->takeKw('do');
            $this->pushScope();
            foreach ($names as $k => $nm) $this->activateLocal($nm, $ids[$k]);
        }
        $this->parseBlock();
        $this->popScope();
        $this->takeKw('end');
    }

    function funcStat() {
        $this->takeKw('function');
        $hasSelf = false;
        $this->funcNameChain($hasSelf);
        $this->funcBody($hasSelf);
    }

    function funcNameChain(&$hasSelf) {
        $t = $this->take();
        if ($t['t'] !== 'name') throw new LuaObfException('function name expected');
        $name = $t['s'];
        $this->srcNames[$name] = true;
        $b = $this->resolve($name);
        $dotted = false;
        // look ahead: is this a plain `function name(` (definition) or
        // `function a.b(...)` / `function a:b(...)` (field assignment)?
        $save = $this->i - 1;
        $j = $this->i;
        while ($j < $this->n - 1 && $this->toks[$j]['t'] === 'symbol' && $this->toks[$j]['s'] === '.') { $j += 2; $dotted = true; }
        if ($j < $this->n - 1 && $this->toks[$j]['t'] === 'symbol' && $this->toks[$j]['s'] === ':') { $dotted = true; $hasSelf = true; }
        if (!$dotted) {
            if ($b !== null) $this->emit('name', $name, ['bind' => $b]);            // assigning into a local
            else { $this->gdefs[$name] = true; $this->emit('name', $name, ['gdef' => true]); }
        } else {
            if ($b !== null) $this->emit('name', $name, ['bind' => $b]);            // root object is a local
            else { $this->unresolved[$name] = true; $this->emit('name', $name, ['glob' => $name]); }
            while ($this->sym('.')) { $this->takeSym('.'); $this->fieldName(); }
            if ($this->sym(':')) { $this->takeSym(':'); $this->fieldName(); }
        }
    }

    function localStat() {
        $this->takeKw('local');
        if ($this->peek('function')) {
            $this->takeKw('function');
            $t = $this->take();
            if ($t['t'] !== 'name') throw new LuaObfException('local function name expected');
            // bound BEFORE the body so the function can call itself (recursion)
            $id = $this->bindLocal($t['s']);
            $this->emit('name', $t['s'], ['bind' => $id]);
            $this->funcBody(false);
            return;
        }
        // local namelist ['=' explist] — initializers see only OUTER bindings,
        // so names are reserved (for emission) but activated afterwards.
        $entries = [];
        while (true) {
            $t = $this->take();
            if ($t['t'] !== 'name') throw new LuaObfException("local name expected, got '" . $t['s'] . "'");
            $id = $this->reserveLocal($t['s']);
            $entries[] = [$t['s'], $id];
            $this->emit('name', $t['s'], ['bind' => $id]);
            if (!$this->sym(',')) break;
            $this->takeSym(',');
        }
        if ($this->sym('=')) { $this->takeSym('='); $this->expList(); }
        foreach ($entries as $e) $this->activateLocal($e[0], $e[1]);
    }

    function exprStat() {
        $bare = $this->suffixedExpSniffBare();
        if ($this->sym(',') || $this->sym('=')) {
            if ($bare !== null) { $this->gdefs[$bare] = true; $this->markLastGlobAsGdef($bare); }
            while ($this->sym(',')) {
                $this->takeSym(',');
                $b2 = $this->suffixedExpSniffBare();
                if ($b2 !== null) { $this->gdefs[$b2] = true; $this->markLastGlobAsGdef($b2); }
            }
            $this->takeSym('=');
            $this->expList();
            return;
        }
        // otherwise: call statement — already emitted
    }
    // If the just-parsed suffixed expression was a single bare global name,
    // upgrade its emitted token from glob-use to global-def.
    function markLastGlobAsGdef($name) {
        for ($k = count($this->out) - 1; $k >= 0; $k--) {
            $tk = $this->out[$k];
            if ($tk['t'] === 'name' && $tk['s'] === $name) {
                if (isset($tk['x']['glob'])) { $this->out[$k]['x'] = ['gdef' => true]; }
                return;
            }
        }
    }
    function suffixedExpSniffBare() {
        // returns the bare global name if the whole expr is a single identifier
        $startOut = count($this->out);
        $this->prefixExp();
        if (count($this->out) === $startOut + 1) {
            $tk = $this->out[$startOut];
            if ($tk['t'] === 'name' && isset($tk['x']['glob'])) return $tk['s'];
        }
        return null;
    }

    function funcBody($hasSelf) {
        $this->pushScope();
        if ($hasSelf) {
            // `function obj:m()` has an implicit `self` parameter whose name
            // is fixed by the language — it must NOT be renamed.
            $id = $this->bindLocal('self');
            $this->forceOrig[$id] = true;
        }
        $this->takeSym('(');
        if (!$this->sym(')')) {
            while (true) {
                if ($this->sym('...')) { $this->takeSym('...'); break; }
                $t = $this->take();
                if ($t['t'] !== 'name') throw new LuaObfException("parameter name expected, got '" . $t['s'] . "'");
                $id = $this->bindLocal($t['s']);
                $this->emit('name', $t['s'], ['bind' => $id]);
                if (!$this->sym(',')) break;
                $this->takeSym(',');
            }
        }
        $this->takeSym(')');
        $this->parseBlock();
        $this->takeKw('end');
        $this->popScope();
    }

    /* ----- expressions ----- */
    function expList() { $this->parseExp(0); while ($this->sym(',')) { $this->takeSym(','); $this->parseExp(0); } }

    static $binprec = [
        'or' => [1, 1], 'and' => [2, 2],
        '<' => [3, 3], '>' => [3, 3], '<=' => [3, 3], '>=' => [3, 3], '~=' => [3, 3], '==' => [3, 3],
        '..' => [5, 4],
        '+' => [6, 6], '-' => [6, 6],
        '*' => [7, 7], '/' => [7, 7], '%' => [7, 7],
        '^' => [10, 9],
    ];
    function binopAtCursor() {
        $c = $this->cur();
        return isset(self::$binprec[$c['s']]) ? $c['s'] : null;
    }
    function parseExp($limit) {
        $c = $this->cur();
        if (($c['t'] === 'kw' && $c['s'] === 'not') || ($c['t'] === 'symbol' && ($c['s'] === '-' || $c['s'] === '#'))) {
            $this->take();
            $this->emit($c['t'], $c['s']);
            $this->parseExp(8); // unary priority sits between * and ^
        } else {
            $this->simpleExp();
        }
        while (($op = $this->binopAtCursor()) !== null) {
            $prec = self::$binprec[$op];
            if ($prec[0] <= $limit) break;
            $tok = $this->take();
            $this->emit($tok['t'], $op);
            $this->parseExp($prec[1]);
        }
    }

    function simpleExp() {
        $c = $this->cur();
        if ($c['t'] === 'kw' && in_array($c['s'], ['nil', 'true', 'false'], true)) { $this->take(); $this->emit('kw', $c['s']); return; }
        if ($c['t'] === 'number') { $this->take(); $this->emit('number', $c['s']); return; }
        if ($c['t'] === 'string') { $this->take(); $this->emit('string', '', ['dec' => $c['dec']]); return; }
        if ($c['t'] === 'symbol' && $c['s'] === '...') { $this->take(); $this->emit('symbol', '...'); return; }
        if ($c['t'] === 'kw' && $c['s'] === 'function') { $this->takeKw('function'); $this->funcBody(false); return; }
        if ($c['t'] === 'symbol' && $c['s'] === '{') { $this->tableCtor(); return; }
        $this->prefixExp();
    }

    function prefixExp() {
        $c = $this->cur();
        if ($c['t'] === 'name') { $this->useName(); }
        elseif ($c['t'] === 'symbol' && $c['s'] === '(') { $this->takeSym('('); $this->parseExp(0); $this->takeSym(')'); }
        else throw new LuaObfException("expression expected, got '" . $c['s'] . "'");
        while (true) {
            if ($this->sym('.')) { $this->takeSym('.'); $this->fieldName(); }
            elseif ($this->sym('[')) { $this->takeSym('['); $this->parseExp(0); $this->takeSym(']'); }
            elseif ($this->sym(':')) { $this->takeSym(':'); $this->fieldName(); $this->callArgs(); }
            elseif ($this->cur()['t'] === 'string' || $this->sym('(') || $this->sym('{')) { $this->callArgs(); }
            else break;
        }
    }

    function callArgs() {
        if ($this->sym('(')) {
            $this->takeSym('(');
            if (!$this->sym(')')) $this->expList();
            $this->takeSym(')');
        } elseif ($this->cur()['t'] === 'string') {
            $c = $this->take();
            $this->emit('string', '', ['dec' => $c['dec']]);
        } elseif ($this->sym('{')) {
            $this->tableCtor();
        } else {
            throw new LuaObfException('bad call args');
        }
    }

    function tableCtor() {
        $this->takeSym('{');
        while (!$this->sym('}')) {
            if ($this->sym('[')) {
                $this->takeSym('[');
                // LuaJIT ctor quirk: an explicit `[num] =` field whose VALUE is
                // not a compile-time constant is stored *after* the positional
                // SETLIST (constants are stored in order) — `{[1]=f(),5,6}`
                // differs from `{[1]="one",5,6}` on LuaJIT. We must therefore
                // keep `[num] = "literal"` fields fully constant: re-emit the
                // string as an escaped literal instead of a decoder call.
                $keyIsPlainNumber = $this->cur()['t'] === 'number';
                $this->parseExp(0);
                $this->takeSym(']');
                $this->takeSym('=');
                if ($keyIsPlainNumber && $this->cur()['t'] === 'string') {
                    $c = $this->take();
                    $this->emit('string', '', ['dec' => $c['dec'], 'plain' => true]);
                } else {
                    $this->parseExp(0);
                }
            } elseif ($this->cur()['t'] === 'name'
                      && $this->toks[$this->i + 1]['t'] === 'symbol' && $this->toks[$this->i + 1]['s'] === '=') {
                $this->fieldName(); $this->takeSym('='); $this->parseExp(0);
            } else {
                $this->parseExp(0);
            }
            if ($this->sym(',') || $this->sym(';')) { $t = $this->take(); $this->emit('symbol', $t['s']); }
            elseif (!$this->sym('}')) throw new LuaObfException("expected '}' in table constructor");
        }
        $this->takeSym('}');
    }
}

/* ---------------- Obfuscation driver ---------------- */

function lua_obf_cipher($plain, $key) {
    // key stream: (k + i*7) % 256 with 1-based i — must match the Lua decoder.
    $n = strlen($plain); $out = '';
    for ($i = 0; $i < $n; $i++) {
        $out .= chr((ord($plain[$i]) + (($key + ($i + 1) * 7) % 256)) % 256);
    }
    return $out;
}
function lua_obf_escape3($bytes) {
    $n = strlen($bytes); $out = '';
    for ($i = 0; $i < $n; $i++) $out .= '\\' . str_pad((string)ord($bytes[$i]), 3, '0', STR_PAD_LEFT);
    return $out;
}

function lua_obfuscate($code, $build_tag = '') {
    $p = new LuaObfParser(lua_tokenize($code));
    $p->parseChunk();

    // Identifier pools that must NEVER be renamed (Lua builtins + the cheat
    // platform API roots visible to the environment).
    static $protected = [
        'assert','collectgarbage','coroutine','debug','dofile','error','gcinfo',
        'getfenv','getmetatable','io','ipairs','jit','load','loadfile','loadstring',
        'math','module','newproxy','next','os','package','pairs','pcall','print',
        'rawequal','rawget','rawset','require','select','setfenv','setmetatable',
        'string','table','tonumber','tostring','type','unpack','xpcall','arg',
        // CS:GO cheat-platform API roots (gamesense/skeet + common libs)
        'client','entity','ui','renderer','panorama','globals','database','plist',
        'materials','bit','ffi','json','websockets','http','base64','md5','pui',
        'webhooks','vector','cvar','engine','inspect','tablex',
    ];
    $prot = array_fill_keys($protected, true);

    // Names that are BOTH locally bound somewhere AND used as a global
    // somewhere (with no in-file global def): renaming either side would
    // break the other — keep these original.
    $mixed = [];
    foreach ($p->bindNames as $name => $_) {
        if (isset($p->unresolved[$name]) && !isset($p->gdefs[$name])) $mixed[$name] = true;
    }

    // junk-name generator
    $usedJunk = [];
    $mkJunk = function () use (&$usedJunk, $p) {
        while (true) {
            $nm = '_' . bin2hex(random_bytes(4));
            if (isset($usedJunk[$nm]) || isset($p->srcNames[$nm])) continue;
            $usedJunk[$nm] = true;
            return $nm;
        }
    };

    // binding-id → output name
    $bindOut = [];
    foreach ($p->bindings as $id => $orig) {
        if (isset($p->forceOrig[$id])) $bindOut[$id] = $orig;
        else $bindOut[$id] = isset($mixed[$orig]) ? $orig : $mkJunk();
    }
    // file-defined global name → output name (uniform rename)
    $globOut = [];
    foreach (array_keys($p->gdefs) as $name) {
        if (isset($prot[$name])) continue;
        $globOut[$name] = $mkJunk();
    }

    /* ---- prelude: string decoder + junk statements ---- */
    $D = $mkJunk();
    $junk = [$mkJunk(), $mkJunk(), $mkJunk()];
    $k0 = random_int(0, 255);
    $tag = $build_tag !== '' ? $build_tag : 'W-TECH';
    $pre = 'local ' . $D . ';'
         . 'do local _b,_c,_t;'
         . '_b=string.byte;_c=string.char;_t=table.concat;'
         . $D . '=function(s,k) local n,r; n=#s; r={};'
         . 'for i=1,n do r[i]=_c((_b(s,i)-(i*7+k)%256+512)%256) end;'
         . 'return _t(r) end;'
         . 'end;'
         . 'local ' . $junk[0] . '=' . $D . '("' . lua_obf_escape3(lua_obf_cipher($tag, $k0)) . '",' . $k0 . ');'
         . 'local ' . $junk[1] . '=' . random_int(1000, 999999) . ';'
         . 'local ' . $junk[2] . '="' . bin2hex(random_bytes(3)) . '";';

    $encString = function ($dec) use ($D) {
        $key = random_int(0, 255);
        // Always parenthesized: the call-sugar forms `require"x"`, `f[[x]]`,
        // `a:b"x"` would otherwise break — `require _D(...)` is not sugar.
        // Parens are safe: a string literal yields exactly one value anyway.
        return '(' . $D . '("' . lua_obf_escape3(lua_obf_cipher($dec, $key)) . '",' . $key . '))';
    };

    /* ---- materialize pieces ---- */
    $pieces = [];
    foreach ($p->out as $tok) {
        $t = $tok['t']; $s = $tok['s'];
        if ($t === 'name' && isset($tok['x'])) {
            if (isset($tok['x']['bind']))            $s = $bindOut[$tok['x']['bind']];
            elseif (isset($tok['x']['gdef']) && isset($globOut[$s])) $s = $globOut[$s];
            elseif (isset($tok['x']['glob']) && isset($globOut[$s])) $s = $globOut[$s];
        }
        if ($t === 'string') {
            if (!empty($tok['x']['plain'])) {
                // constant-preserving emission (see the LuaJIT ctor note)
                $s = '"' . lua_obf_escape3($tok['x']['dec']) . '"';
            } else {
                $s = $encString($tok['x']['dec']);
            }
            $t = 'atom';
        }
        elseif ($t === 'number' && preg_match('/^\d{2,}$/', $s)) { $s = '0x' . dechex((int)$s); }
        $pieces[] = ['t' => $t, 's' => $s];
    }

    /* ---- join with minimal safe spacing ---- */
    $body = ''; $prevT = null;
    foreach ($pieces as $pc) {
        if ($body !== '' && $pc['s'] !== '') {
            $la = substr($body, -1); $fb = $pc['s'][0];
            $sp = false;
            if ((ctype_alnum($la) || $la === '_') && (ctype_alnum($fb) || $fb === '_')) $sp = true;
            elseif ($la === '-' && $fb === '-') $sp = true;                 // would open a comment
            elseif ($la === '.' && $fb === '.') $sp = true;                 // ../... merges
            elseif ($prevT === 'number' && $fb === '.') $sp = true;         // "10..x" must not scan "10."
            if ($sp) $body .= ' ';
        }
        $body .= $pc['s'];
        $prevT = $pc['t'];
    }

    return $pre . ' ' . $body;
}
