-- ============================================================
-- +W.TECH FORUM — полная схема базы данных + сид-данные
-- ============================================================
-- Собрано заново из исходного кода сайта (api.php, functions.php,
-- chat.php, index.php) — покрывает ВСЕ таблицы и колонки, которые
-- использует код. Колонка `hwid` намеренно ОТСУТСТВУЕТ: она вырезана
-- с сайта (см. раздел 8l в ИЗМЕНЕНИЯ.md).
--
-- Импорт: phpMyAdmin → база l43087cr_1337 → вкладка Import → этот файл.
-- Скрипт использует CREATE TABLE IF NOT EXISTS и INSERT IGNORE,
-- поэтому его можно запускать повторно — существующие данные не
-- пострадают.
--
-- Сид создаёт:
--   * 8 категорий форума (announcements, releases, general, lua,
--     configs, support, showcase, offtopic);
--   * 12 стартовых тем с постами: приветствие, правила, гайды
--     и чейнджлоги релизов лоадера (категория Releases, v1.0–v1.3);
--   * аккаунт владельца:
--       логин    owner
--       пароль   ChangeMe123!
--       email    owner@example.com
--       роль     owner
--     !!! После первого входа СРАЗУ смените пароль и email в профиле !!!
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- ------------------------------------------------------------
-- Пользователи
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`       VARCHAR(32)  NOT NULL,
  `email`          VARCHAR(190) NOT NULL,
  `role`           VARCHAR(16)  NOT NULL DEFAULT 'member',   -- member / moderator / admin / owner
  `password_hash`  VARCHAR(255) NOT NULL,
  `remember_token` VARCHAR(64)  NOT NULL DEFAULT '',          -- sha256-хэш cookie «запомнить меня»
  `color`          VARCHAR(7)   NOT NULL DEFAULT '#ff3232',   -- цвет ника #rrggbb
  `status`         VARCHAR(80)  NOT NULL DEFAULT '',
  `bio`            TEXT         NULL,
  `avatar_url`     VARCHAR(255) NOT NULL DEFAULT '',
  `avatar_border`  VARCHAR(16)  NOT NULL DEFAULT '',          -- none/gradient/neon/fire/ocean/gold/purple/emerald/aurora/comet/pulse
  `profile_bg`     VARCHAR(255) NOT NULL DEFAULT '',          -- URL фона профиля
  `link_youtube`   VARCHAR(200) NOT NULL DEFAULT '',
  `link_discord`   VARCHAR(200) NOT NULL DEFAULT '',
  `link_telegram`  VARCHAR(200) NOT NULL DEFAULT '',
  `joined_at`      INT UNSIGNED NOT NULL DEFAULT 0,
  `banned`         TINYINT(1)   NOT NULL DEFAULT 0,
  `ban_reason`     VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `ix_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Категории форума
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
  `id`          VARCHAR(32)  NOT NULL,
  `name`        VARCHAR(80)  NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `icon`        VARCHAR(16)  NOT NULL DEFAULT '',
  `ord`         INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Темы
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `threads` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` VARCHAR(32)  NOT NULL,
  `author_id`   INT UNSIGNED NOT NULL,
  `title`       VARCHAR(190) NOT NULL,
  `pinned`      TINYINT(1)   NOT NULL DEFAULT 0,
  `locked`      TINYINT(1)   NOT NULL DEFAULT 0,
  `views`       INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at`  INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at`  INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_threads_category` (`category_id`, `updated_at`),
  KEY `ix_threads_author` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Сообщения в темах
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `posts` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `thread_id`  INT UNSIGNED NOT NULL,
  `author_id`  INT UNSIGNED NOT NULL,
  `content`    MEDIUMTEXT   NOT NULL,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_posts_thread` (`thread_id`),
  KEY `ix_posts_author` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Вложения к сообщениям
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attachments` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id`    INT UNSIGNED NOT NULL,
  `user_id`    INT UNSIGNED NOT NULL,
  `url`        VARCHAR(255) NOT NULL,
  `name`       VARCHAR(190) NOT NULL DEFAULT '',
  `mime`       VARCHAR(100) NOT NULL DEFAULT '',
  `size`       INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_attach_post` (`post_id`),
  KEY `ix_attach_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Общий чат на главной
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `chat` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `username`   VARCHAR(32)  NOT NULL,
  `role`       VARCHAR(16)  NOT NULL DEFAULT 'member',
  `content`    TEXT         NOT NULL,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_chat_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Кто сейчас онлайн (сердцебиение)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `online` (
  `user_id`   INT UNSIGNED NOT NULL,
  `username`  VARCHAR(32)  NOT NULL,
  `role`      VARCHAR(16)  NOT NULL DEFAULT 'member',
  `last_seen` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  KEY `ix_online_seen` (`last_seen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Индикатор «печатает…» в чате
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `typing` (
  `user_id`    INT UNSIGNED NOT NULL,
  `username`   VARCHAR(32)  NOT NULL,
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`),
  KEY `ix_typing_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Личные переписки: диалоги
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `conversations` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user1_id`   INT UNSIGNED NOT NULL,
  `user2_id`   INT UNSIGNED NOT NULL,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_conv_user1` (`user1_id`),
  KEY `ix_conv_user2` (`user2_id`),
  KEY `ix_conv_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Личные переписки: сообщения
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pm` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `conversation_id` INT UNSIGNED NOT NULL,
  `sender_id`       INT UNSIGNED NOT NULL,
  `content`         TEXT         NOT NULL,
  `created_at`      INT UNSIGNED NOT NULL DEFAULT 0,
  `read_at`         INT UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_pm_conv` (`conversation_id`),
  KEY `ix_pm_sender` (`sender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Тикеты поддержки
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tickets` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `subject`    VARCHAR(190) NOT NULL,
  `category`   VARCHAR(32)  NOT NULL DEFAULT 'general',
  `status`     VARCHAR(16)  NOT NULL DEFAULT 'open',   -- open / answered / closed
  `priority`   VARCHAR(16)  NOT NULL DEFAULT 'normal', -- low / normal / high
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_tickets_user` (`user_id`),
  KEY `ix_tickets_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Ответы в тикетах
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ticket_replies` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket_id`  INT UNSIGNED NOT NULL,
  `user_id`    INT UNSIGNED NOT NULL,
  `content`    TEXT         NOT NULL,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_ticket_replies_ticket` (`ticket_id`),
  KEY `ix_ticket_replies_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- ------------------------------------------------------------
-- Центр уведомлений (колокольчик в шапке)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,                  -- получатель
  `type`       VARCHAR(24)  NOT NULL,                  -- reply_thread/mention/mention_chat/dm/ticket_*
  `actor_name` VARCHAR(32)  NOT NULL DEFAULT '',       -- ник вызвавшего событие (снимок)
  `title`      VARCHAR(190) NOT NULL DEFAULT '',       -- тема / тикет / превью ЛС
  `link`       VARCHAR(190) NOT NULL DEFAULT '',       -- куда вести (#-маршрут без '#')
  `cnt`        INT UNSIGNED NOT NULL DEFAULT 1,        -- одинаковые непрочитанные схлопываются
  `unread`     TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `ix_notif_user` (`user_id`, `unread`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- СИД-ДАННЫЕ
-- ============================================================

INSERT IGNORE INTO `categories` (`id`, `name`, `description`, `icon`, `ord`) VALUES
  ('announcements', 'Announcements', 'News and updates from the +W.TECH team', '📢', 1),
  ('releases', 'Releases', 'Loader releases and changelogs — what is new in every build', '🚀', 2),
  ('general', 'General', 'General discussion about anything', '💬', 3),
  ('lua', 'Lua Scripts', 'Lua scripts: releases, requests and help', '📜', 4),
  ('configs', 'Configs', 'Share your settings and try configs made by others', '⚙️', 5),
  ('support', 'Support', 'Need help with the loader or scripts?', '🛠️', 6),
  ('showcase', 'Showcase', 'Show off your configs, luas and clips', '✨', 7),
  ('offtopic', 'Off-topic', 'Anything not related to cheating', '🍕', 8);

-- Аккаунт владельца. Пароль: ChangeMe123!  — СМЕНИТЕ после первого входа!
INSERT IGNORE INTO `users`
  (`username`, `email`, `role`, `password_hash`, `color`, `bio`, `joined_at`)
VALUES
  ('owner', 'owner@example.com', 'owner',
   '$2y$10$jjFs92T98Z.IBsQnSKbeOuYO20/e8lWDMJpxQoHFdYRe45zow9xIa',
   '#ff3232', '', UNIX_TIMESTAMP());

-- ============================================================
-- STARTER CONTENT: приветственные темы, релизы-чейнджлоги и посты
-- от owner (тот же блок, что и в seed-content.sql — идемпотентный)
-- ============================================================
SET @owner := (SELECT `id` FROM `users` WHERE `role`='owner' ORDER BY `id` LIMIT 1);
SET @owner := IFNULL(@owner, 1);

-- ------------------------------------------------------------
-- Стартовые темы (приветствие + правила + свежий релиз закреплены,
-- правила закрыты для ответов)
-- ------------------------------------------------------------
INSERT IGNORE INTO `threads`
  (`id`, `category_id`, `author_id`, `title`, `pinned`, `locked`, `views`, `created_at`, `updated_at`)
VALUES
  (1, 'announcements', @owner, 'Welcome to +W.TECH FORUM 👋', 1, 0, 64, 1784206800, 1784206800),
  (2, 'announcements', @owner, 'Forum rules 📌', 1, 1, 49, 1784207400, 1784207400),
  (3, 'general', @owner, 'Introduce yourself 🙂', 0, 0, 31, 1784293200, 1784293200),
  (4, 'support', @owner, 'How to download and run the loader (step by step)', 1, 0, 38, 1784386800, 1784386800),
  (5, 'lua', @owner, 'How to install a lua script in GameSense', 0, 0, 22, 1784379600, 1784379600),
  (6, 'configs', @owner, 'Share your configs here 🎯', 0, 0, 27, 1784466000, 1784466000),
  (7, 'showcase', @owner, 'Clips, screenshots & highlights 🎬', 0, 0, 19, 1784552400, 1784552400),
  (8, 'offtopic', @owner, 'Off-topic: talk about anything 🍕', 0, 0, 12, 1784638800, 1784638800),
  (9, 'releases', @owner, '+W.tech-recode v1.0.0 — the first release 🚀', 0, 0, 214, 1781701200, 1781701200),
  (10, 'releases', @owner, '+W.tech-recode v1.1.0 — cloud configs', 0, 0, 156, 1782306000, 1782306000),
  (11, 'releases', @owner, '+W.tech-recode v1.2.0 — modern UI & notifications', 0, 0, 131, 1783515600, 1783515600),
  (12, 'releases', @owner, '+W.tech-recode v1.3.0 — security & stability (current)', 1, 0, 87, 1784466000, 1784466000);

-- ------------------------------------------------------------
-- Открывающие посты к темам
-- ------------------------------------------------------------
INSERT IGNORE INTO `posts`
  (`id`, `thread_id`, `author_id`, `content`, `created_at`)
VALUES
  (1, 1, @owner, 'Welcome to the official +W.TECH community forum!

This is the place to talk about the loader, share configs and lua scripts, get support and show off your highlights.

Quick start:
• Grab the loader on the Downloads page (top menu) — you need an account with access.
• Read the rules on the Rules page — they are short and fair.
• Something broken? Create a thread in Support or open a ticket, we answer fast.

Sections:
Announcements — news and updates from the team.
Releases — loader changelogs: every build, what is new.
General — talk about anything.
Lua Scripts — releases, requests and lua help.
Configs — share your settings, try configs made by others.
Support — loader and script problems get solved here.
Showcase — your clips, screenshots and highlights.
Off-topic — everything else.

Have fun and stay undetected ❤️', 1784206800),
  (2, 2, @owner, 'The short version — common sense wins:

1. No spam, no flooding, no advertising.
2. No scams and no selling anything without the team''s permission.
3. No leaks of private builds, configs or personal data.
4. Respect each other — toxicity and drama earn a timeout.
5. Staff decisions are final. Disagree? Open a ticket and talk calmly.

The full rules live on the Rules page — check the top menu.
Break them and you get muted or banned, depending on the mood of the banhammer. 😉', 1784207400),
  (3, 3, @owner, 'New here? Drop a couple of lines below!

Tell us:
• where you''re from,
• how long you''ve been playing CS:GO,
• what you run in your setup (lua, config),
• what you expect from +W.TECH.

Easiest way to get your first posts in and become a familiar face.', 1784293200),
  (4, 4, @owner, 'Step by step:

1. Log in and make sure your account has loader access.
2. Open the Downloads page and press the button — you will get loader.lua (it comes obfuscated, that is normal).
3. In GameSense open the LUA tab and drop the file into your scripts folder.
4. Enable the script in the list and press Load.
5. Menu didn''t open? Check the console first — 90% of issues are readable right there.

Still stuck? Reply here or open a ticket: add a console screenshot and tell us what you already tried.', 1784386800),
  (5, 5, @owner, 'Quick guide:

1. Download the .lua file.
2. Move it into your GameSense lua folder (the LUA tab shows the exact path).
3. Refresh the script list in GameSense.
4. Enable the script and press Load.

Tips:
• One feature per script — keeps conflicts away.
• Two luas fighting? Disable one and see which menu breaks.
• Script errors out? Ask in this section and attach the console output.', 1784379600),
  (6, 6, @owner, 'Got a config you''re proud of? Share it!

Create a thread with:
• what the config is for (legit / rage / HvH),
• which luas it expects (if any),
• a couple of screenshots or a short clip,
• the config file attached to the post.

Try configs made by others and leave feedback — that''s how the good ones get found.', 1784466000),
  (7, 7, @owner, 'The bragging thread.

Post your best moments: clips, screenies, crazy K/D, funny whiffs — anything worth watching. YouTube links embed automatically, images attach straight to the post.

Keep it safe for work and don''t advertise other projects.', 1784552400),
  (8, 8, @owner, 'Not everything has to be about cheating.

Music, movies, life, memes, what you had for breakfast — go wild, as long as the rules still apply.', 1784638800),
  (9, 9, @owner, 'The first public build of +W.tech-recode is out! 🎉

What is inside:
• Anti-aimbot core: angles, jitter, fake lag, anti-aim indicators.
• Visuals & misc: custom watermark, custom indicators, debug panel, aspect ratio, world modulation.
• Player list & spectator list.
• Theme system with per-element colors.
• Notify engine: hits, misses, damage predictions.

Install: Downloads page → loader.lua → GameSense LUA tab → Load.

This thread starts the changelog history — every next build gets its own post here in Releases.', 1781701200),
  (10, 10, @owner, 'v1.1.0 — the cloud update ☁

New:
• Cloud configs: save, load, delete and share your settings between PCs.
• 6-digit share codes: press «share», send the code, the other side does «import from clipboard code» — done.
• Private and public cloud entries.

Fixes:
• Watermark flickering on resolution change.
• Fake lag slider not saving on map switch.
• Rare crash when loading a config twice in a row.

Small stuff:
• Notify queue limit raised to 8.
• Menu open/close animation is smoother.', 1782306000),
  (11, 11, @owner, 'v1.2.0 — modern UI & notifications ✨

New:
• Modern UI panel: cleaner layout, better tab order, live preview of colors.
• New notification stack with icons and hover-to-pause.
• Config export/import to plain data (backup outside the cloud).

Fixes:
• Indicators could stick after round restart.
• Custom prefix text ignored the color picker.
• Several anti-aim edge cases on fake duck.

Notes:
• Everything from v1.1.0 is untouched — cloud codes keep working.', 1783515600),
  (12, 12, @owner, 'v1.3.0 — security & stability 🔒 (current build)

Security:
• New integrity checks and environment validation.
• Stronger anti-debug and anti-dump guards.
• Harder tampering with the script storage.

Stability:
• Memory usage cut roughly in half on long sessions.
• Fixed the last known reason of "menu is gone after reconnect".
• Cold boot is about 30% faster.

Misc:
• Notify engine rewritten to be flicker-free.
• A bunch of small polish all over the menu.

How to update: just download loader.lua again from the Downloads page and reload the script. Your cloud configs stay as they are.

Feedback and bug reports — in this thread or in Support. ❤️', 1784466000);
