<?php
/* =====================================================================
   security.php — centralized, layered hardening for the +W.TECH forum
   ---------------------------------------------------------------------
   Drop-in protection layer included by BOTH index.php (HTML shell) and
   api.php (JSON API). Self-contained: the parts used by index.php
   (headers) do NOT depend on functions.php / the database.

   Layers (defence in depth)
   -------------------------
   1. sec_session_harden()   stricter session config (call BEFORE session_start)
   2. sec_headers()          security HTTP headers + tuned CSP
   3. sec_method_check()     allow only safe HTTP methods on the API
   4. sec_limit_body()       reject oversized request bodies (anti-DoS)
   5. sec_csrf_init/check()  CSRF: required custom header  +  double-submit
                             token cookie (echoed via X-CSRF-Token header)
   6. sec_rate_check()       per-session global request rate limit
  6b. sec_require_method_for_action() GET allowed for READ-ONLY actions only
                             (writes must POST -> kills CSRF-by-navigation,
                             since SameSite=Lax cookies ride top-level GET links)
   7. sec_firewall()         null-byte / path-traversal / SQLi & XSS signatures
                             on STRUCTURAL params only (never free text)
   8. sec_auth_*()           login / register / forgot brute-force throttle —
                             FILE-BASED per IP+identifier (dropping cookies no
                             longer resets the counter)
  8b. sec_flood_gate()       per-user flood gates for posts/threads/DM/tickets
   9. sec_image_magic()      magic-byte validation of uploaded images
  10. sec_logout_harden()    wipe cookies + storage on logout
  11. helpers                sec_int / sec_str / sec_email / sec_url / ...

   SQL injection note
   ------------------
   The app ALREADY uses PDO prepared statements everywhere (db_val / db_row /
   db_all) — that is the correct, primary defence and it is intact. This file
   adds layers on top so a future mistake can't silently reopen a hole.

   Every layer is toggleable via the SEC_* constants below, so if anything
   ever conflicts with your hosting you can disable it in one line.
   ===================================================================== */

// Block direct web access (this file is only meant to be included).
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(403);
    exit('Forbidden');
}

/* ---------------------------------------------------------------------
   TUNING — flip these to taste.
   --------------------------------------------------------------------- */
if (!defined('SEC_CSP_ENABLE'))        define('SEC_CSP_ENABLE', true);
if (!defined('SEC_EXTRA_HEADERS'))     define('SEC_EXTRA_HEADERS', true);   // CORP / COOP / etc.
if (!defined('SEC_FIREWALL_ENABLE'))   define('SEC_FIREWALL_ENABLE', true);
if (!defined('SEC_METHOD_CHECK'))      define('SEC_METHOD_CHECK', true);    // allow only GET/POST/HEAD/OPTIONS
if (!defined('SEC_CSRF_ENABLE'))       define('SEC_CSRF_ENABLE', true);     // require X-Requested-With
if (!defined('SEC_CSRF_TOKEN_ENFORCE'))define('SEC_CSRF_TOKEN_ENFORCE', true); // + double-submit token
if (!defined('SEC_RATE_ENABLE'))       define('SEC_RATE_ENABLE', true);     // per-session global rate limit
if (!defined('SEC_RATE_WINDOW'))       define('SEC_RATE_WINDOW', 10);       // seconds
if (!defined('SEC_RATE_MAX'))          define('SEC_RATE_MAX', 300);         // max requests per window
if (!defined('SEC_MAX_BODY'))          define('SEC_MAX_BODY', 20 * 1024 * 1024); // bytes (attachments ≤15MB)
if (!defined('SEC_AUTH_MAX'))          define('SEC_AUTH_MAX', 8);
if (!defined('SEC_AUTH_WINDOW'))       define('SEC_AUTH_WINDOW', 300);
if (!defined('SEC_AUTH_BLOCK'))        define('SEC_AUTH_BLOCK', 600);

/* =====================================================================
   1. SESSION HARDENING  (must run BEFORE session_start())
   ===================================================================== */
function sec_session_harden() {
    // Stronger, harder-to-guess / harder-to-fixate session ids. @silences
    // hosts where a directive is locked at a higher level.
    @ini_set('session.use_strict_mode', '1');
    @ini_set('session.use_only_cookies', '1');
    @ini_set('session.use_trans_sid', '0');
    @ini_set('session.sid_length', '48');
    @ini_set('session.sid_bits_per_character', '5');
    @ini_set('session.cookie_httponly', '1');
    @ini_set('session.cookie_samesite', 'Lax');
}

/* =====================================================================
   2. SECURITY HEADERS
   ===================================================================== */
function sec_headers() {
    // These work regardless of scheme (HTTP or HTTPS).
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=(), usb=(), magnetometer=(), gyroscope=(), autoplay=()');
    header('X-XSS-Protection: 1; mode=block');
    header('X-Powered-By: wtech-forum');
    header('X-DNS-Prefetch-Control: off');

    // "Powerful-feature" headers and HSTS only take effect on a secure (HTTPS)
    // origin. Over plain HTTP browsers IGNORE them and spam the console with
    // warnings, so we emit them only when actually served over HTTPS.
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

    if (SEC_EXTRA_HEADERS && $https) {
        header('Cross-Origin-Resource-Policy: same-origin');
        header('Cross-Origin-Opener-Policy: same-origin');
        header('X-Permitted-Cross-Domain-Policies: none');
        header('Origin-Agent-Cluster: ?1');
    }

    if (SEC_CSP_ENABLE) {
        // NOTE: `upgrade-insecure-requests` is only safe when HTTPS actually
        // works. On an HTTP-only site it rewrites every asset URL to a dead
        // HTTPS port and breaks all CSS/JS (ERR_CONNECTION_REFUSED). So we add
        // it only on HTTPS, where it usefully upgrades any stray http asset.
        $csp = "default-src 'self'; "
            . "script-src 'self' 'unsafe-inline'; "
            . "script-src-attr 'none'; "
            . "style-src 'self' 'unsafe-inline'; "
            . "img-src 'self' data: blob: https:; "
            . "media-src 'self' data: blob:; "
            . "font-src 'self' data:; "
            . "frame-src https://www.youtube.com; "
            . "connect-src 'self'; "
            . "worker-src 'none'; "
            . "object-src 'none'; "
            . "base-uri 'self'; "
            . "form-action 'self'; "
            . "frame-ancestors 'none'";
        if ($https) $csp .= "; upgrade-insecure-requests";
        header('Content-Security-Policy: ' . $csp);
    }

    if ($https) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/* =====================================================================
   3. HTTP METHOD CHECK
   ===================================================================== */
function sec_block_request($msg, $code = 403) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $msg]);
    exit;
}
function sec_method_check() {
    if (!SEC_METHOD_CHECK) return;
    $m = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    // The PHP API only ever uses GET (reads) and POST (writes). HEAD/OPTIONS
    // are allowed for tooling / preflight; everything else (TRACE, etc.) is
    // rejected to shrink the attack surface.
    if (!in_array($m, ['GET', 'POST', 'HEAD', 'OPTIONS'], true)) {
        header('Allow: GET, POST, HEAD, OPTIONS');
        sec_block_request('Method not allowed.', 405);
    }
    // Answer OPTIONS (CORS preflight / probes) empty and stop dispatch BEFORE
    // any action runs. No CORS headers are emitted, so a cross-origin page can
    // never pass a real preflight — this keeps the API same-origin only.
    if ($m === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

/* =====================================================================
   4. REQUEST BODY SIZE LIMIT  (anti-DoS)
   ---------------------------------------------------------------------
   Stops a client from pushing a huge body. Works for Content-Length; the
   chunked-transfer case is capped inside param() (functions.php).
   ===================================================================== */
function sec_limit_body() {
    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
    if ($len > SEC_MAX_BODY) sec_block_request('Request too large.', 413);
}

/* =====================================================================
   5. CSRF PROTECTION
   ---------------------------------------------------------------------
   Layer 1 — a custom header (X-Requested-With) that a cross-site attacker
   cannot add (no CORS opt-in is ever granted). Layer 2 — a double-submit
   token: we set a JS-readable cookie and echo the same value in the
   X-CSRF-Token RESPONSE header; the SPA echoes it back as a request header
   and we compare. A cross-site attacker can neither read the cookie nor set
   the custom header. Combined with SameSite=Lax cookies this is robust.
   ===================================================================== */
function sec_csrf_init() {
    if (!SEC_CSRF_ENABLE) return;
    $tok = (string)($_COOKIE['csrf_token'] ?? '');
    if ($tok === '' || strlen($tok) < 32) {
        $tok = bin2hex(random_bytes(32));
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        setcookie('csrf_token', $tok, [
            'expires'  => time() + 60 * 60 * 24 * 30,
            'path'     => '/',
            'secure'   => $secure,
            'httponly' => false,   // JS-readable so the SPA can echo it back
            'samesite' => 'Lax',
        ]);
        $_COOKIE['csrf_token'] = $tok;
    }
    // Expose the token via a response header so same-origin JS can read it
    // even in environments where document.cookie is unavailable.
    header('X-CSRF-Token: ' . $tok);
}
function sec_csrf_check() {
    if (!SEC_CSRF_ENABLE) return;
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (!in_array($method, ['POST', 'PUT', 'DELETE', 'PATCH'], true)) return; // reads are safe

    // Layer 1
    $xhr = (string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');
    if (strcasecmp($xhr, 'XMLHttpRequest') !== 0) {
        sec_block_request('Request rejected (missing API header).', 403);
    }
    // Layer 2 (double-submit) — enforced only once we have issued a cookie.
    if (SEC_CSRF_TOKEN_ENFORCE) {
        $cookieTok = (string)($_COOKIE['csrf_token'] ?? '');
        if ($cookieTok !== '') {
            $hdrTok = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
            if ($hdrTok === '' || !hash_equals($cookieTok, $hdrTok)) {
                sec_block_request('Request rejected (CSRF token mismatch).', 403);
            }
        }
    }
}

/* =====================================================================
   6. PER-SESSION GLOBAL RATE LIMIT  (safety net vs runaway clients)
   ===================================================================== */
function sec_rate_check() {
    if (!SEC_RATE_ENABLE || SEC_RATE_MAX <= 0) return;
    $now = time();
    $w   = SEC_RATE_WINDOW;
    if (!isset($_SESSION['rate']) || !is_array($_SESSION['rate'])) $_SESSION['rate'] = ['times' => [], 'blocked_until' => 0];
    $r = &$_SESSION['rate'];
    if ($now < $r['blocked_until']) sec_block_request('Too many requests. Slow down.', 429);
    $r['times'] = array_values(array_filter($r['times'], function ($t) use ($now, $w) { return $t > $now - $w; }));
    if (count($r['times']) >= SEC_RATE_MAX) {
        $r['blocked_until'] = $now + 30;
        $r['times'] = [];
        sec_block_request('Too many requests. Slow down.', 429);
    }
    $r['times'][] = $now;
}

/* =====================================================================
   6b. READ-ONLY ACTION WHITELIST — GET is for reads, POST for writes
   ---------------------------------------------------------------------
   api.php historically executed EVERY action over GET as well as POST, and
   the CSRF layer only inspects mutating methods. Because session cookies
   are SameSite=Lax, a cross-site TOP-LEVEL navigation (a clicked link or a
   redirect) DOES carry the session cookie — so any state-changing action
   reachable over GET (e.g. /api.php?action=thread_delete&id=5 opened by a
   logged-in admin) was effectively CSRF-able. The bundled SPA already issues
   every write via POST, so limiting GET to the read-only list below changes
   nothing for real users while closing the hole.
   ===================================================================== */
function sec_get_allowed_actions() {
    return [
        // Reads actually used by the SPA (see app.js phpGet) + harmless extras.
        'me', 'categories', 'threads', 'thread', 'profile', 'search', 'stats',
        'chat_history', 'chat_poll', 'quick_login_info',
        'dm_conversations', 'dm_messages', 'dm_unread',
        'admin_users', 'ticket_list', 'ticket_view', 'forgot_check',
        'download_loader',
        'notif_list', 'notif_unread',
    ];
}
function sec_require_method_for_action($action) {
    $m = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($m === 'POST') return;   // writes: good
    if (($m === 'GET' || $m === 'HEAD') && in_array($action, sec_get_allowed_actions(), true)) return;
    header('Allow: POST');
    sec_block_request('This action requires a POST request.', 405);
}

/* =====================================================================
   7. REQUEST FIREWALL (defence in depth)
   ===================================================================== */
function sec_looks_like_injection($s) {
    if (!is_string($s) || $s === '') return false;
    $patterns = [
        '/\bunion\b[\s\S]{0,30}\bselect\b/i',
        '/\b(select|insert|update|delete|drop|alter|create|truncate)\b[\s\S]{0,40}\b(from|into|table|database)\b/i',
        '/;\s*(drop|delete|update|insert|shutdown|exec)\b/i',
        '/\b(or|and)\b\s+\d+\s*=\s*\d+/i',
        '/\b(sleep|benchmark)\s*\(/i',
        '/<\s*script/i',
        '/javascript\s*:/i',
        '/\bon(error|load|click|mouseover|focus)\s*=/i',
        '/\.\.[\/\\\\]|%2e%2e/i',
    ];
    foreach ($patterns as $p) { if (preg_match($p, $s)) return true; }
    return false;
}
function sec_firewall() {
    if (!SEC_FIREWALL_ENABLE) return;
    $scan = array_merge($_GET, is_array($_POST) ? $_POST : []);
    foreach ($scan as $v) {
        if (is_string($v) && strpos($v, "\0") !== false) sec_block_request('Invalid request.');
    }
    $qs = (string)($_SERVER['QUERY_STRING'] ?? '');
    if (preg_match('/\.\.[\/\\\\]|%2e%2e/i', $qs)) sec_block_request('Invalid request.');
    foreach (['action', 'id', 'category', 'page', 'since'] as $key) {
        $v = $_GET[$key] ?? ($_POST[$key] ?? null);
        if (is_string($v) && sec_looks_like_injection($v)) sec_block_request('Suspicious request blocked.');
    }
}

/* =====================================================================
   8. AUTH BRUTE-FORCE THROTTLE  — per IP + identifier, FILE-BASED
   ---------------------------------------------------------------------
   v2 (hardening): the counters used to live in the PHP session — an attacker
   could simply stop sending cookies and get a fresh, unthrottled session on
   every request, i.e. unlimited password guesses. The counters now live in
   data/throttle/ (web access already denied via data/.htaccess), keyed by
   sha1(client IP + identifier), so dropping cookies no longer resets them.
   Same limits, same messages — legitimate users notice no difference.
   ===================================================================== */
function sec__auth_store_file($key) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'cli';
    $d  = __DIR__ . '/data/throttle';
    if (!is_dir($d)) @mkdir($d, 0700, true);
    return $d . '/auth_' . sha1($ip . '|' . strtolower((string)$key)) . '.json';
}
function sec__auth_load($key) {
    $f = sec__auth_store_file($key);
    $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    if (!is_array($j)) $j = [];
    if (!isset($j['times']) || !is_array($j['times'])) $j['times'] = [];
    $j['blocked_until'] = (int)($j['blocked_until'] ?? 0);
    return $j;
}
function sec__auth_save($key, $b) {
    $f = sec__auth_store_file($key);
    @file_put_contents($f, json_encode($b), LOCK_EX);
    @chmod($f, 0600);
}
function sec_auth_check($key) {
    $now = time();
    $b   = sec__auth_load($key);
    if ($now < $b['blocked_until']) {
        return 'Too many attempts. Try again in ' . max(1, $b['blocked_until'] - $now) . 's.';
    }
    $w = SEC_AUTH_WINDOW;
    $b['times'] = array_values(array_filter($b['times'], function ($t) use ($now, $w) { return $t > $now - $w; }));
    if (count($b['times']) >= SEC_AUTH_MAX) {
        $b['blocked_until'] = $now + SEC_AUTH_BLOCK;
        $b['times'] = [];
        sec__auth_save($key, $b);
        return 'Too many attempts. Please wait ' . SEC_AUTH_BLOCK . 's and try again.';
    }
    sec__auth_save($key, $b);
    return null;
}
function sec_auth_record($key) {
    $b = sec__auth_load($key);
    $b['times'][] = time();
    sec__auth_save($key, $b);
}
function sec_auth_reset($key) {
    $f = sec__auth_store_file($key);
    if (is_file($f)) @unlink($f);
}

/* =====================================================================
   8b. PER-USER FLOOD GATES for forum actions (thread / post / dm / ticket)
   ---------------------------------------------------------------------
   The live chat already had layered anti-spam; thread/post/DM/ticket creation
   had none, so any logged-in account could flood the forum via a simple loop.
   Limits are deliberately generous (staff get relaxed limits) so genuine use
   is never affected — only clear abuse trips them. State lives in the PHP
   session keyed by user id, exactly like the chat anti-spam (an abuser would
   have to log out — and thus lose access — to reset it).

   Call AFTER input validation and right BEFORE the INSERT:
     $flood = sec_flood_gate($user, 'post');
     if ($flood) json_out(['error' => $flood['error']], $flood['code']);
   ===================================================================== */
function sec_flood_cfg($bucket, $is_staff) {
    $cfg = [
        'thread' => ['gap' => 30, 'max' => 8,  'window' => 3600, 'label' => 'threads'],
        'post'   => ['gap' => 5,  'max' => 30, 'window' => 600,  'label' => 'posts'],
        'dm'     => ['gap' => 1,  'max' => 40, 'window' => 300,  'label' => 'messages'],
        'ticket' => ['gap' => 30, 'max' => 10, 'window' => 3600, 'label' => 'tickets'],
    ];
    $c = isset($cfg[$bucket]) ? $cfg[$bucket] : ['gap' => 5, 'max' => 30, 'window' => 600, 'label' => 'actions'];
    if ($is_staff) {                 // staff are trusted: relax, don't remove
        $c['gap'] = min($c['gap'], 1);
        $c['max'] = $c['max'] * 6;
    }
    return $c;
}
// Returns ['error'=>..., 'code'=>429] when the action must be rejected, or
// null when it may proceed. A passing call is recorded immediately.
function sec_flood_gate($user, $bucket) {
    if (!$user || !isset($user['id'])) return null;
    $c   = sec_flood_cfg($bucket, is_ticket_staff($user));
    $now = microtime(true);
    $key = $bucket . '|' . (int)$user['id'];
    if (!isset($_SESSION['flood']) || !is_array($_SESSION['flood'])) $_SESSION['flood'] = [];
    $bag = (isset($_SESSION['flood'][$key]) && is_array($_SESSION['flood'][$key]))
         ? $_SESSION['flood'][$key] : ['times' => [], 'last' => 0.0];
    if (!isset($bag['times']) || !is_array($bag['times'])) $bag['times'] = [];
    if (!isset($bag['last'])) $bag['last'] = 0.0;
    // Minimum gap between two actions (anti machine-gun).
    if ($bag['last'] && ($now - $bag['last']) < $c['gap']) {
        $wait = max(1, (int)ceil($c['gap'] - ($now - $bag['last'])));
        return ['error' => "You're posting too fast. Please wait {$wait}s.", 'code' => 429];
    }
    // Sliding window cap.
    $w = $c['window'];
    $times = array_values(array_filter($bag['times'], function ($t) use ($now, $w) { return $t > $now - $w; }));
    if (count($times) >= $c['max']) {
        $oldest = (float)min($times);
        $wait = max(1, (int)ceil(($oldest + $w) - $now));
        $_SESSION['flood'][$key] = ['times' => $times, 'last' => $bag['last']];
        return ['error' => "Too many {$c['label']} in a short time. Try again in {$wait}s.", 'code' => 429];
    }
    $times[] = $now;
    $_SESSION['flood'][$key] = ['times' => $times, 'last' => $now];
    return null;
}

/* =====================================================================
   9. UPLOAD HARDENING HELPERS
   ===================================================================== */
// Verify the file's magic bytes match the expected image extension. Stops
// polyglot / fake-image uploads regardless of the (spoofable) MIME type.
function sec_image_magic($path, $ext) {
    $h = @file_get_contents($path, false, null, 0, 12);
    if ($h === false || strlen($h) < 4) return false;
    $b = array_values(unpack('C*', substr($h, 0, 12)));
    switch (strtolower($ext)) {
        case 'jpg': case 'jpeg': return $b[0] === 0xFF && $b[1] === 0xD8 && $b[2] === 0xFF;
        case 'png':  return count($b) >= 8  && $b[0] === 0x89 && $b[1] === 0x50 && $b[2] === 0x4E && $b[3] === 0x47;
        case 'gif':  return $b[0] === 0x47 && $b[1] === 0x49 && $b[2] === 0x46 && $b[3] === 0x38;
        case 'webp': return count($b) >= 12 && $b[0] === 0x52 && $b[1] === 0x49 && $b[2] === 0x46 && $b[3] === 0x46
                                    && $b[8] === 0x57 && $b[9] === 0x45 && $b[10] === 0x42 && $b[11] === 0x50;
    }
    return false;
}
// Extensions that must never be accepted as uploads (defence in depth).
function sec_dangerous_ext($ext) {
    static $deny = ['php','phtml','php3','php4','php5','php7','php8','phar','phps',
                    'cgi','pl','py','jsp','asp','aspx','sh','exe','htaccess','html',
                    'htm','svg','svgz','js','mjs','xhtml','shtml'];
    return in_array(strtolower((string)$ext), $deny, true);
}

/* =====================================================================
   10. SECURE LOGOUT  (wipe cookies + client storage)
   ===================================================================== */
function sec_logout_harden() {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    header('Clear-Site-Data: "cookies", "storage"');
    if (session_status() === PHP_SESSION_ACTIVE) {
        $p = session_get_cookie_params();
        $opts = [
            'expires'  => 1,
            'path'     => $p['path'] ?: '/',
            'secure'   => $secure,
            'httponly' => $p['httponly'],
            'samesite' => !empty($p['samesite']) ? $p['samesite'] : 'Lax',
        ];
        if (!empty($p['domain'])) $opts['domain'] = $p['domain']; // empty Domain= invalidates the cookie
        setcookie(session_name(), '', $opts);
    }
    if (!empty($_COOKIE['csrf_token']))   setcookie('csrf_token',   '', ['expires' => 1, 'path' => '/', 'secure' => $secure, 'httponly' => false, 'samesite' => 'Lax']);
    if (!empty($_COOKIE['wtech_remember'])) setcookie('wtech_remember', '', ['expires' => 1, 'path' => '/', 'secure' => $secure, 'httponly' => true,  'samesite' => 'Lax']);
    $_SESSION = [];
}

/* =====================================================================
   11. INPUT VALIDATION / SANITIZATION HELPERS
   ===================================================================== */
function sec_int($v, $default = 0) { return is_numeric($v) ? (int)$v : $default; }
function sec_str($v, $max = 500, $default = '') {
    if (!is_string($v)) return $default;
    $v = trim(str_replace("\0", '', $v));
    if ($max > 0 && preg_match('/^(.{' . (int)$max . '})/su', $v, $m)) return $m[1];
    return $v;
}
function sec_trim($v) { return is_string($v) ? trim(str_replace("\0", '', $v)) : ''; }
function sec_email($v) { $v = trim((string)$v); return filter_var($v, FILTER_VALIDATE_EMAIL) ? $v : ''; }
function sec_url($v, $max = 255) {
    $v = trim((string)$v);
    if ($v === '' || strlen($v) > $max) return '';
    return preg_match('#^https?://#i', $v) ? $v : '';
}
// Strict URL for values placed into href="..." or CSS url('...'). On top of
// sec_url it forbids characters that break out of those contexts (quotes,
// parens, angle brackets, backslash, whitespace) — prevents stored
// CSS-injection / attribute-injection via user-supplied URLs.
function sec_safe_url($v, $max = 255) {
    $v = sec_url($v, $max);
    if ($v === '') return '';
    if (strpbrk($v, chr(39).chr(34).'()<> '.chr(92).chr(9).chr(10).chr(13)) !== false) return '';
    return $v;
}
function sec_hexcolor($v) { $v = trim((string)$v); return preg_match('/^#[0-9a-fA-F]{6}$/', $v) ? $v : ''; }
function sec_escape($v) { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8'); }
function sec_whitelist($v, array $allowed, $default = '') { return in_array($v, $allowed, true) ? $v : $default; }

/* =====================================================================
   BOOTSTRAP for the JSON API (api.php). Call AFTER session_start().
   (sec_session_harden() must be called separately, BEFORE session_start.)
   index.php should call only sec_headers().
   ===================================================================== */
function sec_bootstrap_api() {
    sec_error_handler();   // first, so nothing leaks during the checks below
    sec_method_check();
    sec_limit_body();
    sec_headers();
    sec_csrf_init();
    sec_rate_check();
    sec_firewall();
    sec_csrf_check();
}
function sec_error_handler() {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}
