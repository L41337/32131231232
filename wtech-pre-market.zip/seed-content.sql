-- ============================================================
-- +W.TECH FORUM — готовый наполнитель: категории + стартовые темы
-- Запускать в phpMyAdmin ПОСЛЕ schema.sql (или поверх живой базы).
-- Полностью идемпотентный: INSERT IGNORE — повторный запуск
-- ничего не задублирует и не сломает.
-- Посты пишет аккаунт с ролью owner (id подставляется автоматически).
-- ============================================================
SET NAMES utf8mb4;

SET @owner := (SELECT `id` FROM `users` WHERE `role`='owner' ORDER BY `id` LIMIT 1);
SET @owner := IFNULL(@owner, 1);

-- ------------------------------------------------------------
-- Категории (announcements / releases / general / lua / configs /
-- support / showcase / offtopic)
-- ------------------------------------------------------------
INSERT IGNORE INTO `categories` (`id`, `name`, `description`, `icon`, `ord`) VALUES
  ('announcements', 'Announcements', 'News and updates from the +W.TECH team', '📢', 1),
  ('releases', 'Releases', 'Loader releases and changelogs — what is new in every build', '🚀', 2),
  ('general', 'General', 'General discussion about anything', '💬', 3),
  ('lua', 'Lua Scripts', 'Lua scripts: releases, requests and help', '📜', 4),
  ('configs', 'Configs', 'Share your settings and try configs made by others', '⚙️', 5),
  ('support', 'Support', 'Need help with the loader or scripts?', '🛠️', 6),
  ('showcase', 'Showcase', 'Show off your configs, luas and clips', '✨', 7),
  ('offtopic', 'Off-topic', 'Anything not related to cheating', '🍕', 8);

-- ------------------------------------------------------------
-- Стартовые темы (приветствие + правила + свежий релиз закреплены,
-- правила закрыты для ответов)
-- ------------------------------------------------------------
INSERT IGNORE INTO `threads`
  (`id`, `category_id`, `author_id`, `title`, `pinned`, `locked`, `views`, `created_at`, `updated_at`)
VALUES
  (1, 'announcements', @owner, 'Welcome to +W.TECH FORUM 👋', 1, 0, 64, 1784206800, 1784206800),
  (2, 'announcements', @owner, 'Forum rules 📌', 1, 1, 49, 1784207400, 1784207400),
  (3, 'general', @owner, 'Introduce yourself 🙂', 0, 0, 31, 1784293200, 1784293200),
  (4, 'support', @owner, 'How to download and run the loader (step by step)', 1, 0, 38, 1784386800, 1784386800),
  (5, 'lua', @owner, 'How to install a lua script in GameSense', 0, 0, 22, 1784379600, 1784379600),
  (6, 'configs', @owner, 'Share your configs here 🎯', 0, 0, 27, 1784466000, 1784466000),
  (7, 'showcase', @owner, 'Clips, screenshots & highlights 🎬', 0, 0, 19, 1784552400, 1784552400),
  (8, 'offtopic', @owner, 'Off-topic: talk about anything 🍕', 0, 0, 12, 1784638800, 1784638800),
  (9, 'releases', @owner, '+W.tech-recode v1.0.0 — the first release 🚀', 0, 0, 214, 1781701200, 1781701200),
  (10, 'releases', @owner, '+W.tech-recode v1.1.0 — cloud configs', 0, 0, 156, 1782306000, 1782306000),
  (11, 'releases', @owner, '+W.tech-recode v1.2.0 — modern UI & notifications', 0, 0, 131, 1783515600, 1783515600),
  (12, 'releases', @owner, '+W.tech-recode v1.3.0 — security & stability (current)', 1, 0, 87, 1784466000, 1784466000);

-- ------------------------------------------------------------
-- Открывающие посты к темам
-- ------------------------------------------------------------
INSERT IGNORE INTO `posts`
  (`id`, `thread_id`, `author_id`, `content`, `created_at`)
VALUES
  (1, 1, @owner, 'Welcome to the official +W.TECH community forum!

This is the place to talk about the loader, share configs and lua scripts, get support and show off your highlights.

Quick start:
• Grab the loader on the Downloads page (top menu) — you need an account with access.
• Read the rules on the Rules page — they are short and fair.
• Something broken? Create a thread in Support or open a ticket, we answer fast.

Sections:
Announcements — news and updates from the team.
Releases — loader changelogs: every build, what is new.
General — talk about anything.
Lua Scripts — releases, requests and lua help.
Configs — share your settings, try configs made by others.
Support — loader and script problems get solved here.
Showcase — your clips, screenshots and highlights.
Off-topic — everything else.

Have fun and stay undetected ❤️', 1784206800),
  (2, 2, @owner, 'The short version — common sense wins:

1. No spam, no flooding, no advertising.
2. No scams and no selling anything without the team''s permission.
3. No leaks of private builds, configs or personal data.
4. Respect each other — toxicity and drama earn a timeout.
5. Staff decisions are final. Disagree? Open a ticket and talk calmly.

The full rules live on the Rules page — check the top menu.
Break them and you get muted or banned, depending on the mood of the banhammer. 😉', 1784207400),
  (3, 3, @owner, 'New here? Drop a couple of lines below!

Tell us:
• where you''re from,
• how long you''ve been playing CS:GO,
• what you run in your setup (lua, config),
• what you expect from +W.TECH.

Easiest way to get your first posts in and become a familiar face.', 1784293200),
  (4, 4, @owner, 'Step by step:

1. Log in and make sure your account has loader access.
2. Open the Downloads page and press the button — you will get loader.lua (it comes obfuscated, that is normal).
3. In GameSense open the LUA tab and drop the file into your scripts folder.
4. Enable the script in the list and press Load.
5. Menu didn''t open? Check the console first — 90% of issues are readable right there.

Still stuck? Reply here or open a ticket: add a console screenshot and tell us what you already tried.', 1784386800),
  (5, 5, @owner, 'Quick guide:

1. Download the .lua file.
2. Move it into your GameSense lua folder (the LUA tab shows the exact path).
3. Refresh the script list in GameSense.
4. Enable the script and press Load.

Tips:
• One feature per script — keeps conflicts away.
• Two luas fighting? Disable one and see which menu breaks.
• Script errors out? Ask in this section and attach the console output.', 1784379600),
  (6, 6, @owner, 'Got a config you''re proud of? Share it!

Create a thread with:
• what the config is for (legit / rage / HvH),
• which luas it expects (if any),
• a couple of screenshots or a short clip,
• the config file attached to the post.

Try configs made by others and leave feedback — that''s how the good ones get found.', 1784466000),
  (7, 7, @owner, 'The bragging thread.

Post your best moments: clips, screenies, crazy K/D, funny whiffs — anything worth watching. YouTube links embed automatically, images attach straight to the post.

Keep it safe for work and don''t advertise other projects.', 1784552400),
  (8, 8, @owner, 'Not everything has to be about cheating.

Music, movies, life, memes, what you had for breakfast — go wild, as long as the rules still apply.', 1784638800),
  (9, 9, @owner, 'The first public build of +W.tech-recode is out! 🎉

What is inside:
• Anti-aimbot core: angles, jitter, fake lag, anti-aim indicators.
• Visuals & misc: custom watermark, custom indicators, debug panel, aspect ratio, world modulation.
• Player list & spectator list.
• Theme system with per-element colors.
• Notify engine: hits, misses, damage predictions.

Install: Downloads page → loader.lua → GameSense LUA tab → Load.

This thread starts the changelog history — every next build gets its own post here in Releases.', 1781701200),
  (10, 10, @owner, 'v1.1.0 — the cloud update ☁

New:
• Cloud configs: save, load, delete and share your settings between PCs.
• 6-digit share codes: press «share», send the code, the other side does «import from clipboard code» — done.
• Private and public cloud entries.

Fixes:
• Watermark flickering on resolution change.
• Fake lag slider not saving on map switch.
• Rare crash when loading a config twice in a row.

Small stuff:
• Notify queue limit raised to 8.
• Menu open/close animation is smoother.', 1782306000),
  (11, 11, @owner, 'v1.2.0 — modern UI & notifications ✨

New:
• Modern UI panel: cleaner layout, better tab order, live preview of colors.
• New notification stack with icons and hover-to-pause.
• Config export/import to plain data (backup outside the cloud).

Fixes:
• Indicators could stick after round restart.
• Custom prefix text ignored the color picker.
• Several anti-aim edge cases on fake duck.

Notes:
• Everything from v1.1.0 is untouched — cloud codes keep working.', 1783515600),
  (12, 12, @owner, 'v1.3.0 — security & stability 🔒 (current build)

Security:
• New integrity checks and environment validation.
• Stronger anti-debug and anti-dump guards.
• Harder tampering with the script storage.

Stability:
• Memory usage cut roughly in half on long sessions.
• Fixed the last known reason of "menu is gone after reconnect".
• Cold boot is about 30% faster.

Misc:
• Notify engine rewritten to be flicker-free.
• A bunch of small polish all over the menu.

How to update: just download loader.lua again from the Downloads page and reload the script. Your cloud configs stay as they are.

Feedback and bug reports — in this thread or in Support. ❤️', 1784466000);
